/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */

import javax.annotation.PostConstruct;
import java.io.Serializable;
import javax.enterprise.context.RequestScoped;
import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.LineChartModel;
import org.primefaces.model.chart.LineChartSeries;
import javax.inject.Named;

/**
 *
 * @author edwin
 */
@Named(value = "testBean")
@RequestScoped
public class TestBean implements Serializable {

    private LineChartModel lineModel;
    private float corx1, cory1;
    private float corx2, cory2;
    private float corx3, cory3;
    private float corx4, cory4;
    private float corx5, cory5;

    public void submit() {
        System.out.println(corx1 + "-" + cory1);
        System.out.println(corx2 + "-" + cory2);
        System.out.println(corx3 + "-" + cory3);
        System.out.println(corx4 + "-" + cory4);
        System.out.println(corx5 + "-" + cory5);

        LineChartSeries s = new LineChartSeries();

        s.setLabel("Population");

        s.set(corx1, cory1);
        s.set(corx2, cory2);
        s.set(corx3, cory3);
        s.set(corx4, cory4);
        s.set(corx5, cory5);

        lineModel.addSeries(s);
        lineModel.setLegendPosition("e");
        Axis y = lineModel.getAxis(AxisType.Y);
        y.setMin(0.5);
        y.setMax(700);
        y.setLabel("Millions");

        Axis x = lineModel.getAxis(AxisType.X);
        x.setMin(0);
        x.setMax(7);
        x.setTickInterval("1");
        x.setLabel("Number of Years");
    }

    public LineChartModel getLineModel() {
        return lineModel;
    }

    public void setLineModel(LineChartModel lineModel) {
        this.lineModel = lineModel;
    }

    public float getCorx1() {
        return corx1;
    }

    public void setCorx1(float corx1) {
        this.corx1 = corx1;
    }

    public float getCory1() {
        return cory1;
    }

    public void setCory1(float cory1) {
        this.cory1 = cory1;
    }

    public float getCorx2() {
        return corx2;
    }

    public void setCorx2(float corx2) {
        this.corx2 = corx2;
    }

    public float getCory2() {
        return cory2;
    }

    public void setCory2(float cory2) {
        this.cory2 = cory2;
    }

    public float getCorx3() {
        return corx3;
    }

    public void setCorx3(float corx3) {
        this.corx3 = corx3;
    }

    public float getCory3() {
        return cory3;
    }

    public void setCory3(float cory3) {
        this.cory3 = cory3;
    }

    public float getCorx4() {
        return corx4;
    }

    public void setCorx4(float corx4) {
        this.corx4 = corx4;
    }

    public float getCory4() {
        return cory4;
    }

    public void setCory4(float cory4) {
        this.cory4 = cory4;
    }

    public float getCorx5() {
        return corx5;
    }

    public void setCorx5(float corx5) {
        this.corx5 = corx5;
    }

    public float getCory5() {
        return cory5;
    }

    public void setCory5(float cory5) {
        this.cory5 = cory5;
    }

    @PostConstruct
    public void init() {
        lineModel = new LineChartModel();
    }

    public TestBean() {
    }

}
