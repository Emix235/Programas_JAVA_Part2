/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sumaherencia;

/**
 *
 * @author Alejandra
 */
public class SumaHerencia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //para la clase Operacion
        //Operacion valores=new Operacion();
        
        
        //para la clase sumar
        
        sumar sumar1=new sumar();
            sumar1.numero1();
            sumar1.numero2();
            sumar1.opeSuma();
            System.out.print("El resultado de la sumar es:");
             sumar1.mostrarResultado();
            
            
        //para la clase restar
        restar resta1=new restar();
        // de la clase Operacion
        
        resta1.numero1();
        resta1.numero2();
        resta1.opeResta();
        
        System.out.print("El resultado de la resta es:");  
        //la clase  Operacion  y el  metodo mostrarResultado
        resta1.mostrarResultado();
    }
    
}
