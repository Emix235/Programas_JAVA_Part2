/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sumaherencia;

import java.util.Scanner;

/**
 *
 * @author Alejandra
 */
public class Operacion {
    Scanner leer=new Scanner(System.in);
    int valor1;
    int valor2;
    int resultado;
    public Operacion() {
      
    }
    
    public void numero1() {
        System.out.print("Ingrese el primer valor:");
        valor1=leer.nextInt();        
    }
    
    public void numero2() {
        System.out.print("Ingrese el segundo valor:");
        valor2=leer.nextInt();
    }
    
    public void mostrarResultado() {
        System.out.println(resultado);
    }
    
}
