/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 *
 * @author Itzayana
 */
public class Laboratorio3 extends javax.swing.JFrame {
public Laboratorio3() {
        initComponents();
        setLocationRelativeTo(null);
        t= new Timer(10, acciones);
        t1= new Timer(10, acciones2);
        t2= new Timer(10, acciones3); 
         t3= new Timer(10, acciones4);
         t4= new Timer(10, acciones5);
         t5= new Timer(10, acciones6);
         t6= new Timer(10, acciones7);
         t7= new Timer(10, acciones8);
         t8= new Timer(10, acciones9);
         t9= new Timer(10, acciones10);
         t10= new Timer(10, acciones11);
         t11= new Timer(10, acciones12);
         t12= new Timer(10, acciones13);
         t13= new Timer(10, acciones14);
         t14= new Timer(10, acciones15);
         t15= new Timer(10, acciones16);
         t16= new Timer(10, acciones17);
         t17= new Timer(10, acciones18);
         t18= new Timer(10, acciones19);
         t19= new Timer(10, acciones20);
         t20= new Timer(10, acciones21);
         t21= new Timer(10, acciones22);
         t22= new Timer(10, acciones23);
         t23= new Timer(10, acciones24);
    }
private Timer t,t1,t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21, t22, t23, t24;
private String tiempo[]= new String [100];
private int H[]= new int [100];
private int m[]= new int [100];
private int s[]= new int [100];
private int cs[]= new int [100];
private ActionListener acciones = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[1]++;
            if(cs[1]==100){
                cs[1]=0;
                s[1]++;
            }
            if(s[1]==60){
                s[1]=0;
                m[1]++;
            }
            if(m[1]==60){
                m[1]=0;
                H[1]++;
            }
            Actualizar();
        }
    };
private ActionListener acciones2 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[2]++;
            if(cs[2]==100){
                cs[2]=0;
                s[2]++;
            }
            if(s[2]==60){
                s[2]=0;
                m[2]++;
            }
            if(m[2]==60){
                m[2]=0;
                H[2]++;
            }
            Actualizar2();
        }
    };
private ActionListener acciones3 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[3]++;
            if(cs[3]==100){
                cs[3]=0;
                s[3]++;
            }
            if(s[3]==60){
                s[3]=0;
                m[3]++;
            }
            if(m[3]==60){
                m[3]=0;
                H[3]++;
            }
            Actualizar3();
        }
    };
private ActionListener acciones4 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[4]++;
            if(cs[4]==100){
                cs[4]=0;
                s[4]++;
            }
            if(s[4]==60){
                s[4]=0;
                m[4]++;
            }
            if(m[4]==60){
                m[4]=0;
                H[4]++;
            }
            Actualizar4();
        }
    };
private ActionListener acciones5 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[5]++;
            if(cs[5]==100){
                cs[5]=0;
                s[5]++;
            }
            if(s[5]==60){
                s[5]=0;
                m[5]++;
            }
            if(m[5]==60){
                m[5]=0;
                H[5]++;
            }
            Actualizar5();
        }
    };
private ActionListener acciones6 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[6]++;
            if(cs[6]==100){
                cs[6]=0;
                s[6]++;
            }
            if(s[6]==60){
                s[6]=0;
                m[6]++;
            }
            if(m[6]==60){
                m[6]=0;
                H[6]++;
            }
            Actualizar6();
        }
    };
private ActionListener acciones7 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[7]++;
            if(cs[7]==100){
                cs[7]=0;
                s[7]++;
            }
            if(s[7]==60){
                s[7]=0;
                m[7]++;
            }
            if(m[7]==60){
                m[7]=0;
                H[7]++;
            }
            Actualizar7();
        }
    };
private ActionListener acciones8 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[8]++;
            if(cs[8]==100){
                cs[8]=0;
                s[8]++;
            }
            if(s[8]==60){
                s[8]=0;
                m[8]++;
            }
            if(m[8]==60){
                m[8]=0;
                H[8]++;
            }
            Actualizar8();
        }
    };
private ActionListener acciones9 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[9]++;
            if(cs[9]==100){
                cs[9]=0;
                s[9]++;
            }
            if(s[9]==60){
                s[9]=0;
                m[9]++;
            }
            if(m[9]==60){
                m[9]=0;
                H[9]++;
            }
            Actualizar9();
        }
    };
private ActionListener acciones10 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[10]++;
            if(cs[10]==100){
                cs[10]=0;
                s[10]++;
            }
            if(s[10]==60){
                s[10]=0;
                m[10]++;
            }
            if(m[10]==60){
                m[10]=0;
                H[10]++;
            }
            Actualizar10();
        }
    };
private ActionListener acciones11 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[11]++;
            if(cs[11]==100){
                cs[11]=0;
                s[11]++;
            }
            if(s[11]==60){
                s[11]=0;
                m[11]++;
            }
            if(m[11]==60){
                m[11]=0;
                H[11]++;
            }
            Actualizar11();
        }
    };
private ActionListener acciones12 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[12]++;
            if(cs[12]==100){
                cs[12]=0;
                s[12]++;
            }
            if(s[12]==60){
                s[12]=0;
                m[12]++;
            }
            if(m[12]==60){
                m[12]=0;
                H[12]++;
            }
            Actualizar12();
        }
    };
private ActionListener acciones13 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[13]++;
            if(cs[13]==100){
                cs[13]=0;
                s[13]++;
            }
            if(s[13]==60){
                s[13]=0;
                m[13]++;
            }
            if(m[13]==60){
                m[13]=0;
                H[13]++;
            }
            Actualizar13();
        }
    };
private ActionListener acciones14 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[14]++;
            if(cs[14]==100){
                cs[14]=0;
                s[14]++;
            }
            if(s[14]==60){
                s[14]=0;
                m[14]++;
            }
            if(m[14]==60){
                m[14]=0;
                H[14]++;
            }
            Actualizar14();
        }
    };
private ActionListener acciones15 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[15]++;
            if(cs[15]==100){
                cs[15]=0;
                s[15]++;
            }
            if(s[15]==60){
                s[15]=0;
                m[15]++;
            }
            if(m[15]==60){
                m[15]=0;
                H[15]++;
            }
            Actualizar15();
        }
    };
private ActionListener acciones16 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[16]++;
            if(cs[16]==100){
                cs[16]=0;
                s[16]++;
            }
            if(s[16]==60){
                s[16]=0;
                m[16]++;
            }
            if(m[16]==60){
                m[16]=0;
                H[16]++;
            }
            Actualizar16();
        }
    };
private ActionListener acciones17 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[17]++;
            if(cs[17]==100){
                cs[17]=0;
                s[17]++;
            }
            if(s[17]==60){
                s[17]=0;
                m[17]++;
            }
            if(m[17]==60){
                m[17]=0;
                H[17]++;
            }
            Actualizar17();
        }
    };
private ActionListener acciones18 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[18]++;
            if(cs[18]==100){
                cs[18]=0;
                s[18]++;
            }
            if(s[18]==60){
                s[18]=0;
                m[18]++;
            }
            if(m[18]==60){
                m[18]=0;
                H[18]++;
            }
            Actualizar18();
        }
    };
private ActionListener acciones19 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[19]++;
            if(cs[19]==100){
                cs[19]=0;
                s[19]++;
            }
            if(s[19]==60){
                s[19]=0;
                m[19]++;
            }
            if(m[19]==60){
                m[19]=0;
                H[19]++;
            }
            Actualizar19();
        }
    };
private ActionListener acciones20 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[20]++;
            if(cs[20]==100){
                cs[20]=0;
                s[20]++;
            }
            if(s[20]==60){
                s[20]=0;
                m[20]++;
            }
            if(m[20]==60){
                m[20]=0;
                H[20]++;
            }
            Actualizar20();
        }
    };
private ActionListener acciones21 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[21]++;
            if(cs[21]==100){
                cs[21]=0;
                s[21]++;
            }
            if(s[21]==60){
                s[21]=0;
                m[21]++;
            }
            if(m[21]==60){
                m[21]=0;
                H[21]++;
            }
            Actualizar21();
        }
    };
private ActionListener acciones22 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[22]++;
            if(cs[22]==100){
                cs[22]=0;
                s[22]++;
            }
            if(s[22]==60){
                s[22]=0;
                m[22]++;
            }
            if(m[22]==60){
                m[22]=0;
                H[22]++;
            }
            Actualizar22();
        }
    };
private ActionListener acciones23 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[23]++;
            if(cs[23]==100){
                cs[23]=0;
                s[23]++;
            }
            if(s[23]==60){
                s[23]=0;
                m[23]++;
            }
            if(m[23]==60){
                m[23]=0;
                H[23]++;
            }
            Actualizar23();
        }
    };
private ActionListener acciones24 = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            cs[24]++;
            if(cs[24]==100){
                cs[24]=0;
                s[24]++;
            }
            if(s[24]==60){
                s[24]=0;
                m[24]++;
            }
            if(m[24]==60){
                m[24]=0;
                H[24]++;
            }
            Actualizar24();
        }
    };
    public void  Actualizar(){
         tiempo[1]=(H[1]<=9?"0":"")+H[1]+"  :  "+(m[1]<=9?"0":"")+m[1]+"  :  "+(s[1]<=9?"0":"")+s[1]+"  :  "+(cs[1]<=9?"0":"")+cs[1];
         Reloj1.setText(tiempo[1]);
    }
    public void  Actualizar2(){
         tiempo[2]=(H[2]<=9?"0":"")+H[2]+"  :  "+(m[2]<=9?"0":"")+m[2]+"  :  "+(s[2]<=9?"0":"")+s[2]+"  :  "+(cs[2]<=9?"0":"")+cs[2];
         Reloj2.setText(tiempo[2]);
    }
    public void  Actualizar3(){
         tiempo[3]=(H[3]<=9?"0":"")+H[3]+"  :  "+(m[3]<=9?"0":"")+m[3]+"  :  "+(s[3]<=9?"0":"")+s[3]+"  :  "+(cs[3]<=9?"0":"")+cs[3];
         Reloj3.setText(tiempo[3]);
    }
    public void  Actualizar4(){
         tiempo[4]=(H[4]<=9?"0":"")+H[4]+"  :  "+(m[4]<=9?"0":"")+m[4]+"  :  "+(s[4]<=9?"0":"")+s[4]+"  :  "+(cs[4]<=9?"0":"")+cs[4];
         Reloj4.setText(tiempo[4]);
    }
    public void  Actualizar5(){
         tiempo[5]=(H[5]<=9?"0":"")+H[5]+"  :  "+(m[5]<=9?"0":"")+m[5]+"  :  "+(s[5]<=9?"0":"")+s[5]+"  :  "+(cs[5]<=9?"0":"")+cs[5];
         Reloj5.setText(tiempo[5]);
    }
    public void  Actualizar6(){
         tiempo[6]=(H[6]<=9?"0":"")+H[6]+"  :  "+(m[6]<=9?"0":"")+m[6]+"  :  "+(s[6]<=9?"0":"")+s[6]+"  :  "+(cs[6]<=9?"0":"")+cs[6];
         Reloj6.setText(tiempo[6]);
    }
    public void  Actualizar7(){
         tiempo[7]=(H[7]<=9?"0":"")+H[7]+"  :  "+(m[7]<=9?"0":"")+m[7]+"  :  "+(s[7]<=9?"0":"")+s[7]+"  :  "+(cs[7]<=9?"0":"")+cs[7];
         Reloj7.setText(tiempo[7]);
    }
    public void  Actualizar8(){
         tiempo[8]=(H[8]<=9?"0":"")+H[8]+"  :  "+(m[8]<=9?"0":"")+m[8]+"  :  "+(s[8]<=9?"0":"")+s[8]+"  :  "+(cs[8]<=9?"0":"")+cs[8];
         Reloj8.setText(tiempo[8]);
    }
    public void  Actualizar9(){
         tiempo[9]=(H[9]<=9?"0":"")+H[9]+"  :  "+(m[9]<=9?"0":"")+m[9]+"  :  "+(s[9]<=9?"0":"")+s[9]+"  :  "+(cs[9]<=9?"0":"")+cs[9];
         Reloj9.setText(tiempo[9]);
    }
    public void  Actualizar10(){
         tiempo[10]=(H[10]<=9?"0":"")+H[10]+"  :  "+(m[10]<=9?"0":"")+m[10]+"  :  "+(s[10]<=9?"0":"")+s[10]+"  :  "+(cs[10]<=9?"0":"")+cs[10];
         Reloj10.setText(tiempo[10]);
    }
    public void  Actualizar11(){
         tiempo[11]=(H[11]<=9?"0":"")+H[11]+"  :  "+(m[11]<=9?"0":"")+m[11]+"  :  "+(s[11]<=9?"0":"")+s[11]+"  :  "+(cs[11]<=9?"0":"")+cs[11];
         Reloj11.setText(tiempo[11]);
    }
    public void  Actualizar12(){
         tiempo[12]=(H[12]<=9?"0":"")+H[12]+"  :  "+(m[12]<=9?"0":"")+m[12]+"  :  "+(s[12]<=9?"0":"")+s[12]+"  :  "+(cs[12]<=9?"0":"")+cs[12];
         Reloj12.setText(tiempo[12]);
    }
    public void  Actualizar13(){
         tiempo[13]=(H[13]<=9?"0":"")+H[13]+"  :  "+(m[13]<=9?"0":"")+m[13]+"  :  "+(s[13]<=9?"0":"")+s[13]+"  :  "+(cs[13]<=9?"0":"")+cs[13];
         Reloj13.setText(tiempo[13]);
    }
    public void  Actualizar14(){
         tiempo[14]=(H[14]<=9?"0":"")+H[14]+"  :  "+(m[14]<=9?"0":"")+m[14]+"  :  "+(s[14]<=9?"0":"")+s[14]+"  :  "+(cs[14]<=9?"0":"")+cs[14];
         Reloj14.setText(tiempo[14]);
    }
    public void  Actualizar15(){
         tiempo[15]=(H[15]<=9?"0":"")+H[15]+"  :  "+(m[15]<=9?"0":"")+m[15]+"  :  "+(s[15]<=9?"0":"")+s[15]+"  :  "+(cs[15]<=9?"0":"")+cs[15];
         Reloj15.setText(tiempo[15]);
    }
    public void  Actualizar16(){
         tiempo[16]=(H[16]<=9?"0":"")+H[16]+"  :  "+(m[16]<=9?"0":"")+m[16]+"  :  "+(s[16]<=9?"0":"")+s[16]+"  :  "+(cs[16]<=9?"0":"")+cs[16];
         Reloj16.setText(tiempo[16]);
    }
    public void  Actualizar17(){
         tiempo[17]=(H[17]<=9?"0":"")+H[17]+"  :  "+(m[17]<=9?"0":"")+m[17]+"  :  "+(s[17]<=9?"0":"")+s[17]+"  :  "+(cs[17]<=9?"0":"")+cs[17];
         Reloj17.setText(tiempo[17]);
    }
    public void  Actualizar18(){
         tiempo[18]=(H[18]<=9?"0":"")+H[18]+"  :  "+(m[18]<=9?"0":"")+m[18]+"  :  "+(s[18]<=9?"0":"")+s[18]+"  :  "+(cs[18]<=9?"0":"")+cs[18];
         Reloj18.setText(tiempo[18]);
    }
    public void  Actualizar19(){
         tiempo[19]=(H[19]<=9?"0":"")+H[19]+"  :  "+(m[19]<=9?"0":"")+m[19]+"  :  "+(s[19]<=9?"0":"")+s[19]+"  :  "+(cs[19]<=9?"0":"")+cs[19];
         Reloj19.setText(tiempo[19]);
    }
    public void  Actualizar20(){
         tiempo[20]=(H[20]<=9?"0":"")+H[20]+"  :  "+(m[20]<=9?"0":"")+m[20]+"  :  "+(s[20]<=9?"0":"")+s[20]+"  :  "+(cs[20]<=9?"0":"")+cs[20];
         Reloj20.setText(tiempo[20]);
    }
    public void  Actualizar21(){
         tiempo[21]=(H[21]<=9?"0":"")+H[21]+"  :  "+(m[21]<=9?"0":"")+m[21]+"  :  "+(s[21]<=9?"0":"")+s[21]+"  :  "+(cs[21]<=9?"0":"")+cs[21];
         Reloj21.setText(tiempo[21]);
    }
    public void  Actualizar22(){
         tiempo[22]=(H[22]<=9?"0":"")+H[22]+"  :  "+(m[22]<=9?"0":"")+m[22]+"  :  "+(s[22]<=9?"0":"")+s[22]+"  :  "+(cs[22]<=9?"0":"")+cs[22];
         Reloj22.setText(tiempo[22]);
    }
    public void  Actualizar23(){
         tiempo[23]=(H[23]<=9?"0":"")+H[23]+"  :  "+(m[23]<=9?"0":"")+m[23]+"  :  "+(s[23]<=9?"0":"")+s[23]+"  :  "+(cs[23]<=9?"0":"")+cs[23];
         Reloj23.setText(tiempo[23]);
    }
    public void  Actualizar24(){
         tiempo[24]=(H[24]<=9?"0":"")+H[24]+"  :  "+(m[24]<=9?"0":"")+m[24]+"  :  "+(s[24]<=9?"0":"")+s[24]+"  :  "+(cs[24]<=9?"0":"")+cs[24];
         Reloj24.setText(tiempo[24]);
    }
    
    
    /**
     * Creates new form Lab1
     */
   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        Reloj1 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        txtUsuario1 = new javax.swing.JTextField();
        Start1 = new javax.swing.JButton();
        Pause1 = new javax.swing.JButton();
        Stop1 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        Reloj2 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        Start2 = new javax.swing.JButton();
        Pause2 = new javax.swing.JButton();
        Stop2 = new javax.swing.JButton();
        jLabel33 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jLabel39 = new javax.swing.JLabel();
        jTextField12 = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        Reloj3 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jTextField13 = new javax.swing.JTextField();
        Start3 = new javax.swing.JButton();
        Pause3 = new javax.swing.JButton();
        Stop3 = new javax.swing.JButton();
        jLabel46 = new javax.swing.JLabel();
        jTextField14 = new javax.swing.JTextField();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jTextField15 = new javax.swing.JTextField();
        jButton22 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jLabel52 = new javax.swing.JLabel();
        jTextField16 = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        Reloj4 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jTextField17 = new javax.swing.JTextField();
        Start4 = new javax.swing.JButton();
        Pause4 = new javax.swing.JButton();
        Stop4 = new javax.swing.JButton();
        jLabel59 = new javax.swing.JLabel();
        jTextField18 = new javax.swing.JTextField();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jTextField19 = new javax.swing.JTextField();
        jButton28 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        jButton30 = new javax.swing.JButton();
        jLabel65 = new javax.swing.JLabel();
        jTextField20 = new javax.swing.JTextField();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        Reloj5 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jTextField21 = new javax.swing.JTextField();
        Start5 = new javax.swing.JButton();
        Pause5 = new javax.swing.JButton();
        Stop5 = new javax.swing.JButton();
        jLabel72 = new javax.swing.JLabel();
        jTextField22 = new javax.swing.JTextField();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jTextField23 = new javax.swing.JTextField();
        jButton34 = new javax.swing.JButton();
        jButton35 = new javax.swing.JButton();
        jButton36 = new javax.swing.JButton();
        jLabel78 = new javax.swing.JLabel();
        jTextField24 = new javax.swing.JTextField();
        jLabel79 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        Reloj6 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jTextField25 = new javax.swing.JTextField();
        Start6 = new javax.swing.JButton();
        Pause6 = new javax.swing.JButton();
        Stop6 = new javax.swing.JButton();
        jLabel85 = new javax.swing.JLabel();
        jTextField26 = new javax.swing.JTextField();
        jLabel86 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jTextField27 = new javax.swing.JTextField();
        jButton40 = new javax.swing.JButton();
        jButton41 = new javax.swing.JButton();
        jButton42 = new javax.swing.JButton();
        jLabel91 = new javax.swing.JLabel();
        jTextField28 = new javax.swing.JTextField();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        Reloj7 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jTextField29 = new javax.swing.JTextField();
        Start7 = new javax.swing.JButton();
        Pause7 = new javax.swing.JButton();
        Stop7 = new javax.swing.JButton();
        jLabel98 = new javax.swing.JLabel();
        jTextField30 = new javax.swing.JTextField();
        jLabel99 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jLabel101 = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        jLabel103 = new javax.swing.JLabel();
        jTextField31 = new javax.swing.JTextField();
        jButton46 = new javax.swing.JButton();
        jButton47 = new javax.swing.JButton();
        jButton48 = new javax.swing.JButton();
        jLabel104 = new javax.swing.JLabel();
        jTextField32 = new javax.swing.JTextField();
        jLabel105 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jLabel107 = new javax.swing.JLabel();
        Reloj8 = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        jLabel110 = new javax.swing.JLabel();
        jTextField33 = new javax.swing.JTextField();
        Start8 = new javax.swing.JButton();
        Pause8 = new javax.swing.JButton();
        Stop8 = new javax.swing.JButton();
        jLabel111 = new javax.swing.JLabel();
        jTextField34 = new javax.swing.JTextField();
        jLabel112 = new javax.swing.JLabel();
        jLabel113 = new javax.swing.JLabel();
        jLabel114 = new javax.swing.JLabel();
        jLabel115 = new javax.swing.JLabel();
        jLabel116 = new javax.swing.JLabel();
        jTextField35 = new javax.swing.JTextField();
        jButton52 = new javax.swing.JButton();
        jButton53 = new javax.swing.JButton();
        jButton54 = new javax.swing.JButton();
        jLabel117 = new javax.swing.JLabel();
        jTextField36 = new javax.swing.JTextField();
        jLabel118 = new javax.swing.JLabel();
        jLabel119 = new javax.swing.JLabel();
        jLabel120 = new javax.swing.JLabel();
        Reloj9 = new javax.swing.JLabel();
        jLabel122 = new javax.swing.JLabel();
        jLabel123 = new javax.swing.JLabel();
        jTextField37 = new javax.swing.JTextField();
        Start9 = new javax.swing.JButton();
        Pause9 = new javax.swing.JButton();
        Stop9 = new javax.swing.JButton();
        jLabel124 = new javax.swing.JLabel();
        jTextField38 = new javax.swing.JTextField();
        jLabel125 = new javax.swing.JLabel();
        jLabel126 = new javax.swing.JLabel();
        jLabel127 = new javax.swing.JLabel();
        jLabel128 = new javax.swing.JLabel();
        jLabel129 = new javax.swing.JLabel();
        jTextField39 = new javax.swing.JTextField();
        jButton58 = new javax.swing.JButton();
        jButton59 = new javax.swing.JButton();
        jButton60 = new javax.swing.JButton();
        jLabel130 = new javax.swing.JLabel();
        jTextField40 = new javax.swing.JTextField();
        jLabel131 = new javax.swing.JLabel();
        jLabel132 = new javax.swing.JLabel();
        jLabel133 = new javax.swing.JLabel();
        Reloj10 = new javax.swing.JLabel();
        jLabel135 = new javax.swing.JLabel();
        jLabel136 = new javax.swing.JLabel();
        jTextField41 = new javax.swing.JTextField();
        Start10 = new javax.swing.JButton();
        Pause10 = new javax.swing.JButton();
        Stop10 = new javax.swing.JButton();
        jLabel137 = new javax.swing.JLabel();
        jTextField42 = new javax.swing.JTextField();
        jLabel138 = new javax.swing.JLabel();
        jLabel139 = new javax.swing.JLabel();
        jLabel140 = new javax.swing.JLabel();
        jLabel141 = new javax.swing.JLabel();
        jLabel142 = new javax.swing.JLabel();
        jTextField43 = new javax.swing.JTextField();
        jButton64 = new javax.swing.JButton();
        jButton65 = new javax.swing.JButton();
        jButton66 = new javax.swing.JButton();
        jLabel143 = new javax.swing.JLabel();
        jTextField44 = new javax.swing.JTextField();
        jLabel144 = new javax.swing.JLabel();
        jLabel145 = new javax.swing.JLabel();
        jLabel146 = new javax.swing.JLabel();
        Reloj11 = new javax.swing.JLabel();
        jLabel148 = new javax.swing.JLabel();
        jLabel149 = new javax.swing.JLabel();
        jTextField45 = new javax.swing.JTextField();
        Start11 = new javax.swing.JButton();
        Pause11 = new javax.swing.JButton();
        Stop11 = new javax.swing.JButton();
        jLabel150 = new javax.swing.JLabel();
        jTextField46 = new javax.swing.JTextField();
        jLabel151 = new javax.swing.JLabel();
        jLabel152 = new javax.swing.JLabel();
        jLabel153 = new javax.swing.JLabel();
        jLabel154 = new javax.swing.JLabel();
        jLabel155 = new javax.swing.JLabel();
        jTextField47 = new javax.swing.JTextField();
        jButton70 = new javax.swing.JButton();
        jButton71 = new javax.swing.JButton();
        jButton72 = new javax.swing.JButton();
        jLabel156 = new javax.swing.JLabel();
        jTextField48 = new javax.swing.JTextField();
        jLabel157 = new javax.swing.JLabel();
        jLabel158 = new javax.swing.JLabel();
        jLabel159 = new javax.swing.JLabel();
        Reloj12 = new javax.swing.JLabel();
        jLabel161 = new javax.swing.JLabel();
        jLabel162 = new javax.swing.JLabel();
        jTextField49 = new javax.swing.JTextField();
        Start12 = new javax.swing.JButton();
        Pause12 = new javax.swing.JButton();
        Stop12 = new javax.swing.JButton();
        jLabel163 = new javax.swing.JLabel();
        jTextField50 = new javax.swing.JTextField();
        jLabel164 = new javax.swing.JLabel();
        jLabel165 = new javax.swing.JLabel();
        jLabel166 = new javax.swing.JLabel();
        jLabel167 = new javax.swing.JLabel();
        jLabel168 = new javax.swing.JLabel();
        jTextField51 = new javax.swing.JTextField();
        jButton76 = new javax.swing.JButton();
        jButton77 = new javax.swing.JButton();
        jButton78 = new javax.swing.JButton();
        jLabel169 = new javax.swing.JLabel();
        jTextField52 = new javax.swing.JTextField();
        jLabel170 = new javax.swing.JLabel();
        jLabel171 = new javax.swing.JLabel();
        jLabel172 = new javax.swing.JLabel();
        Reloj13 = new javax.swing.JLabel();
        jLabel174 = new javax.swing.JLabel();
        jLabel175 = new javax.swing.JLabel();
        jTextField53 = new javax.swing.JTextField();
        Start13 = new javax.swing.JButton();
        Pause13 = new javax.swing.JButton();
        Stop13 = new javax.swing.JButton();
        jLabel176 = new javax.swing.JLabel();
        jTextField54 = new javax.swing.JTextField();
        jLabel177 = new javax.swing.JLabel();
        jLabel178 = new javax.swing.JLabel();
        jLabel179 = new javax.swing.JLabel();
        jLabel180 = new javax.swing.JLabel();
        jLabel181 = new javax.swing.JLabel();
        jTextField55 = new javax.swing.JTextField();
        jButton82 = new javax.swing.JButton();
        jButton83 = new javax.swing.JButton();
        jButton84 = new javax.swing.JButton();
        jLabel182 = new javax.swing.JLabel();
        jTextField56 = new javax.swing.JTextField();
        jLabel183 = new javax.swing.JLabel();
        jLabel184 = new javax.swing.JLabel();
        jLabel185 = new javax.swing.JLabel();
        Reloj14 = new javax.swing.JLabel();
        jLabel187 = new javax.swing.JLabel();
        jLabel188 = new javax.swing.JLabel();
        jTextField57 = new javax.swing.JTextField();
        Start14 = new javax.swing.JButton();
        Pause14 = new javax.swing.JButton();
        Stop14 = new javax.swing.JButton();
        jLabel189 = new javax.swing.JLabel();
        jTextField58 = new javax.swing.JTextField();
        jLabel190 = new javax.swing.JLabel();
        jLabel191 = new javax.swing.JLabel();
        jLabel192 = new javax.swing.JLabel();
        jLabel193 = new javax.swing.JLabel();
        jLabel194 = new javax.swing.JLabel();
        jTextField59 = new javax.swing.JTextField();
        jButton88 = new javax.swing.JButton();
        jButton89 = new javax.swing.JButton();
        jButton90 = new javax.swing.JButton();
        jLabel195 = new javax.swing.JLabel();
        jTextField60 = new javax.swing.JTextField();
        jLabel196 = new javax.swing.JLabel();
        jLabel197 = new javax.swing.JLabel();
        jLabel198 = new javax.swing.JLabel();
        Reloj15 = new javax.swing.JLabel();
        jLabel200 = new javax.swing.JLabel();
        jLabel201 = new javax.swing.JLabel();
        jTextField61 = new javax.swing.JTextField();
        Start15 = new javax.swing.JButton();
        Pause15 = new javax.swing.JButton();
        Stop15 = new javax.swing.JButton();
        jLabel202 = new javax.swing.JLabel();
        jTextField62 = new javax.swing.JTextField();
        jLabel203 = new javax.swing.JLabel();
        jLabel204 = new javax.swing.JLabel();
        jLabel205 = new javax.swing.JLabel();
        jLabel206 = new javax.swing.JLabel();
        jLabel207 = new javax.swing.JLabel();
        jTextField63 = new javax.swing.JTextField();
        jButton94 = new javax.swing.JButton();
        jButton95 = new javax.swing.JButton();
        jButton96 = new javax.swing.JButton();
        jLabel208 = new javax.swing.JLabel();
        jTextField64 = new javax.swing.JTextField();
        jLabel209 = new javax.swing.JLabel();
        jLabel210 = new javax.swing.JLabel();
        jLabel211 = new javax.swing.JLabel();
        Reloj16 = new javax.swing.JLabel();
        jLabel213 = new javax.swing.JLabel();
        jLabel214 = new javax.swing.JLabel();
        jTextField65 = new javax.swing.JTextField();
        Start16 = new javax.swing.JButton();
        Pause16 = new javax.swing.JButton();
        Stop16 = new javax.swing.JButton();
        jLabel215 = new javax.swing.JLabel();
        jTextField66 = new javax.swing.JTextField();
        jLabel216 = new javax.swing.JLabel();
        jLabel217 = new javax.swing.JLabel();
        jLabel218 = new javax.swing.JLabel();
        jLabel219 = new javax.swing.JLabel();
        jLabel220 = new javax.swing.JLabel();
        jTextField67 = new javax.swing.JTextField();
        jButton100 = new javax.swing.JButton();
        jButton101 = new javax.swing.JButton();
        jButton102 = new javax.swing.JButton();
        jLabel221 = new javax.swing.JLabel();
        jTextField68 = new javax.swing.JTextField();
        jLabel222 = new javax.swing.JLabel();
        jLabel223 = new javax.swing.JLabel();
        jLabel224 = new javax.swing.JLabel();
        Reloj17 = new javax.swing.JLabel();
        jLabel226 = new javax.swing.JLabel();
        jLabel227 = new javax.swing.JLabel();
        jTextField69 = new javax.swing.JTextField();
        Start17 = new javax.swing.JButton();
        Pause17 = new javax.swing.JButton();
        Stop17 = new javax.swing.JButton();
        jLabel228 = new javax.swing.JLabel();
        jTextField70 = new javax.swing.JTextField();
        jLabel229 = new javax.swing.JLabel();
        jLabel230 = new javax.swing.JLabel();
        jLabel231 = new javax.swing.JLabel();
        jLabel232 = new javax.swing.JLabel();
        jLabel233 = new javax.swing.JLabel();
        jTextField71 = new javax.swing.JTextField();
        jButton106 = new javax.swing.JButton();
        jButton107 = new javax.swing.JButton();
        jButton108 = new javax.swing.JButton();
        jLabel234 = new javax.swing.JLabel();
        jTextField72 = new javax.swing.JTextField();
        jLabel235 = new javax.swing.JLabel();
        jLabel236 = new javax.swing.JLabel();
        jLabel237 = new javax.swing.JLabel();
        Reloj18 = new javax.swing.JLabel();
        jLabel239 = new javax.swing.JLabel();
        jLabel240 = new javax.swing.JLabel();
        jTextField73 = new javax.swing.JTextField();
        Start18 = new javax.swing.JButton();
        Pause18 = new javax.swing.JButton();
        Stop18 = new javax.swing.JButton();
        jLabel241 = new javax.swing.JLabel();
        jTextField74 = new javax.swing.JTextField();
        jLabel242 = new javax.swing.JLabel();
        jLabel243 = new javax.swing.JLabel();
        jLabel244 = new javax.swing.JLabel();
        jLabel245 = new javax.swing.JLabel();
        jLabel246 = new javax.swing.JLabel();
        jTextField75 = new javax.swing.JTextField();
        jButton112 = new javax.swing.JButton();
        jButton113 = new javax.swing.JButton();
        jButton114 = new javax.swing.JButton();
        jLabel247 = new javax.swing.JLabel();
        jTextField76 = new javax.swing.JTextField();
        jLabel248 = new javax.swing.JLabel();
        jLabel249 = new javax.swing.JLabel();
        jLabel250 = new javax.swing.JLabel();
        Reloj19 = new javax.swing.JLabel();
        jLabel252 = new javax.swing.JLabel();
        jLabel253 = new javax.swing.JLabel();
        jTextField77 = new javax.swing.JTextField();
        Start19 = new javax.swing.JButton();
        Pause19 = new javax.swing.JButton();
        Stop19 = new javax.swing.JButton();
        jLabel254 = new javax.swing.JLabel();
        jTextField78 = new javax.swing.JTextField();
        jLabel255 = new javax.swing.JLabel();
        jLabel256 = new javax.swing.JLabel();
        jLabel257 = new javax.swing.JLabel();
        jLabel258 = new javax.swing.JLabel();
        jLabel259 = new javax.swing.JLabel();
        jTextField79 = new javax.swing.JTextField();
        jButton118 = new javax.swing.JButton();
        jButton119 = new javax.swing.JButton();
        jButton120 = new javax.swing.JButton();
        jLabel260 = new javax.swing.JLabel();
        jTextField80 = new javax.swing.JTextField();
        jLabel261 = new javax.swing.JLabel();
        jLabel262 = new javax.swing.JLabel();
        jLabel263 = new javax.swing.JLabel();
        Reloj20 = new javax.swing.JLabel();
        jLabel265 = new javax.swing.JLabel();
        jLabel266 = new javax.swing.JLabel();
        jTextField81 = new javax.swing.JTextField();
        Start20 = new javax.swing.JButton();
        Pause20 = new javax.swing.JButton();
        Stop20 = new javax.swing.JButton();
        jLabel267 = new javax.swing.JLabel();
        jTextField82 = new javax.swing.JTextField();
        jLabel268 = new javax.swing.JLabel();
        jLabel269 = new javax.swing.JLabel();
        jLabel270 = new javax.swing.JLabel();
        jLabel271 = new javax.swing.JLabel();
        jLabel272 = new javax.swing.JLabel();
        jTextField83 = new javax.swing.JTextField();
        jButton124 = new javax.swing.JButton();
        jButton125 = new javax.swing.JButton();
        jButton126 = new javax.swing.JButton();
        jLabel273 = new javax.swing.JLabel();
        jTextField84 = new javax.swing.JTextField();
        jLabel274 = new javax.swing.JLabel();
        jLabel275 = new javax.swing.JLabel();
        jLabel276 = new javax.swing.JLabel();
        Reloj21 = new javax.swing.JLabel();
        jLabel278 = new javax.swing.JLabel();
        jLabel279 = new javax.swing.JLabel();
        jTextField85 = new javax.swing.JTextField();
        Start21 = new javax.swing.JButton();
        Pause21 = new javax.swing.JButton();
        Stop21 = new javax.swing.JButton();
        jLabel280 = new javax.swing.JLabel();
        jTextField86 = new javax.swing.JTextField();
        jLabel281 = new javax.swing.JLabel();
        jLabel282 = new javax.swing.JLabel();
        jLabel283 = new javax.swing.JLabel();
        jLabel284 = new javax.swing.JLabel();
        jLabel285 = new javax.swing.JLabel();
        jTextField87 = new javax.swing.JTextField();
        jButton130 = new javax.swing.JButton();
        jButton131 = new javax.swing.JButton();
        jButton132 = new javax.swing.JButton();
        jLabel286 = new javax.swing.JLabel();
        jTextField88 = new javax.swing.JTextField();
        jLabel287 = new javax.swing.JLabel();
        jLabel288 = new javax.swing.JLabel();
        jLabel289 = new javax.swing.JLabel();
        Reloj22 = new javax.swing.JLabel();
        jLabel291 = new javax.swing.JLabel();
        jLabel292 = new javax.swing.JLabel();
        jTextField89 = new javax.swing.JTextField();
        Start22 = new javax.swing.JButton();
        Pause22 = new javax.swing.JButton();
        Stop22 = new javax.swing.JButton();
        jLabel293 = new javax.swing.JLabel();
        jTextField90 = new javax.swing.JTextField();
        jLabel294 = new javax.swing.JLabel();
        jLabel295 = new javax.swing.JLabel();
        jLabel296 = new javax.swing.JLabel();
        jLabel297 = new javax.swing.JLabel();
        jLabel298 = new javax.swing.JLabel();
        jTextField91 = new javax.swing.JTextField();
        jButton136 = new javax.swing.JButton();
        jButton137 = new javax.swing.JButton();
        jButton138 = new javax.swing.JButton();
        jLabel299 = new javax.swing.JLabel();
        jTextField92 = new javax.swing.JTextField();
        jLabel300 = new javax.swing.JLabel();
        jLabel301 = new javax.swing.JLabel();
        jLabel302 = new javax.swing.JLabel();
        Reloj23 = new javax.swing.JLabel();
        jLabel304 = new javax.swing.JLabel();
        jLabel305 = new javax.swing.JLabel();
        jTextField93 = new javax.swing.JTextField();
        Start23 = new javax.swing.JButton();
        Pause23 = new javax.swing.JButton();
        Stop23 = new javax.swing.JButton();
        jLabel306 = new javax.swing.JLabel();
        jTextField94 = new javax.swing.JTextField();
        jLabel307 = new javax.swing.JLabel();
        jLabel308 = new javax.swing.JLabel();
        jLabel309 = new javax.swing.JLabel();
        jLabel310 = new javax.swing.JLabel();
        jLabel311 = new javax.swing.JLabel();
        jTextField95 = new javax.swing.JTextField();
        jButton142 = new javax.swing.JButton();
        jButton143 = new javax.swing.JButton();
        jButton144 = new javax.swing.JButton();
        jLabel312 = new javax.swing.JLabel();
        jTextField96 = new javax.swing.JTextField();
        jLabel313 = new javax.swing.JLabel();
        jLabel314 = new javax.swing.JLabel();
        jLabel315 = new javax.swing.JLabel();
        Reloj24 = new javax.swing.JLabel();
        jLabel317 = new javax.swing.JLabel();
        jLabel318 = new javax.swing.JLabel();
        jTextField97 = new javax.swing.JTextField();
        Start24 = new javax.swing.JButton();
        Pause24 = new javax.swing.JButton();
        Stop24 = new javax.swing.JButton();
        jLabel319 = new javax.swing.JLabel();
        jTextField98 = new javax.swing.JTextField();
        jLabel320 = new javax.swing.JLabel();
        jLabel321 = new javax.swing.JLabel();
        jLabel322 = new javax.swing.JLabel();
        jLabel323 = new javax.swing.JLabel();
        jLabel324 = new javax.swing.JLabel();
        jTextField99 = new javax.swing.JTextField();
        jButton148 = new javax.swing.JButton();
        jButton149 = new javax.swing.JButton();
        jButton150 = new javax.swing.JButton();
        jLabel325 = new javax.swing.JLabel();
        jTextField100 = new javax.swing.JTextField();
        jLabel326 = new javax.swing.JLabel();
        jTextField173 = new javax.swing.JTextField();
        jButton260 = new javax.swing.JButton();
        jTextField174 = new javax.swing.JTextField();
        jTextField175 = new javax.swing.JTextField();
        jButton263 = new javax.swing.JButton();
        jTextField176 = new javax.swing.JTextField();
        jButton265 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jScrollPane1.setPreferredSize(new java.awt.Dimension(1496, 2202));

        jPanel1.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jPanel1.setPreferredSize(new java.awt.Dimension(1496, 2202));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel27.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel27.setText("Equipo 1");
        jPanel1.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 100, 80));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 140, 110));

        Reloj1.setBackground(new java.awt.Color(0, 0, 0));
        Reloj1.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj1.setForeground(new java.awt.Color(0, 255, 0));
        Reloj1.setText("00 : 00 : 00 : 00");
        Reloj1.setOpaque(true);
        jPanel1.add(Reloj1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 240, 150, -1));

        jLabel16.setBackground(new java.awt.Color(0, 0, 153));
        jLabel16.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(51, 255, 0));
        jLabel16.setText("H       :Min      :Seg    :CS");
        jLabel16.setOpaque(true);
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 220, 150, 20));

        jLabel17.setBackground(new java.awt.Color(255, 0, 153));
        jLabel17.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Nom.de Usuario ;");
        jLabel17.setOpaque(true);
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 270, 100, 20));

        txtUsuario1.setBackground(new java.awt.Color(153, 255, 255));
        txtUsuario1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(txtUsuario1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 270, 170, -1));

        Start1.setBackground(new java.awt.Color(0, 255, 255));
        Start1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start1.setForeground(new java.awt.Color(0, 0, 102));
        Start1.setText("Comenzar");
        Start1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start1MouseClicked(evt);
            }
        });
        Start1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start1ActionPerformed(evt);
            }
        });
        jPanel1.add(Start1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 330, 100, -1));

        Pause1.setBackground(new java.awt.Color(204, 0, 0));
        Pause1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause1.setForeground(new java.awt.Color(255, 255, 0));
        Pause1.setText("Pausar");
        Pause1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause1MouseClicked(evt);
            }
        });
        jPanel1.add(Pause1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 330, 100, -1));

        Stop1.setBackground(new java.awt.Color(255, 255, 51));
        Stop1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop1.setText("Finalizado y desocupado");
        Stop1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop1MouseClicked(evt);
            }
        });
        jPanel1.add(Stop1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 350, 270, 30));

        jLabel18.setBackground(new java.awt.Color(0, 255, 255));
        jLabel18.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel18.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel18.setOpaque(true);
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 300, 200, 20));
        jPanel1.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 300, 70, 20));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel19.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 440, 180));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 140, 110));

        jLabel21.setBackground(new java.awt.Color(0, 0, 0));
        jLabel21.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 255, 0));
        jLabel21.setText("00 : 00 : 00 : 00");
        jLabel21.setOpaque(true);
        jPanel1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 240, 150, -1));

        jLabel22.setBackground(new java.awt.Color(0, 0, 153));
        jLabel22.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(51, 255, 0));
        jLabel22.setText("H       :Min      :Seg    :CS");
        jLabel22.setOpaque(true);
        jPanel1.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 220, 150, 20));

        jLabel23.setBackground(new java.awt.Color(255, 0, 153));
        jLabel23.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Nom.de Usuario ;");
        jLabel23.setOpaque(true);
        jPanel1.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 270, 100, 20));

        jTextField7.setBackground(new java.awt.Color(153, 255, 255));
        jTextField7.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 270, 170, -1));

        jButton10.setBackground(new java.awt.Color(0, 255, 255));
        jButton10.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton10.setForeground(new java.awt.Color(0, 0, 102));
        jButton10.setText("Comenzar");
        jButton10.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 330, 100, -1));

        jButton11.setBackground(new java.awt.Color(204, 0, 0));
        jButton11.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 255, 0));
        jButton11.setText("Pausar");
        jButton11.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 330, 100, -1));

        jButton12.setBackground(new java.awt.Color(255, 255, 51));
        jButton12.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton12.setText("Finalizado y desocupado");
        jButton12.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 350, 270, 30));

        jLabel24.setBackground(new java.awt.Color(0, 255, 255));
        jLabel24.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel24.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel24.setOpaque(true);
        jPanel1.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 300, 200, 20));
        jPanel1.add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 300, 70, 20));

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel25.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 440, 180));

        jLabel28.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel28.setText("Equipo 2");
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 420, 100, 80));

        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 420, 140, 110));

        Reloj2.setBackground(new java.awt.Color(0, 0, 0));
        Reloj2.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj2.setForeground(new java.awt.Color(0, 255, 0));
        Reloj2.setText("00 : 00 : 00 : 00");
        Reloj2.setOpaque(true);
        jPanel1.add(Reloj2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 430, 150, -1));

        jLabel31.setBackground(new java.awt.Color(0, 0, 153));
        jLabel31.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(51, 255, 0));
        jLabel31.setText("H       :Min      :Seg    :CS");
        jLabel31.setOpaque(true);
        jPanel1.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 410, 150, 20));

        jLabel32.setBackground(new java.awt.Color(255, 0, 153));
        jLabel32.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("Nom.de Usuario ;");
        jLabel32.setOpaque(true);
        jPanel1.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 460, 100, 20));

        jTextField9.setBackground(new java.awt.Color(153, 255, 255));
        jTextField9.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField9, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 460, 170, -1));

        Start2.setBackground(new java.awt.Color(0, 255, 255));
        Start2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start2.setForeground(new java.awt.Color(0, 0, 102));
        Start2.setText("Comenzar");
        Start2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start2MouseClicked(evt);
            }
        });
        Start2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start2ActionPerformed(evt);
            }
        });
        jPanel1.add(Start2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 520, 100, -1));

        Pause2.setBackground(new java.awt.Color(204, 0, 0));
        Pause2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause2.setForeground(new java.awt.Color(255, 255, 0));
        Pause2.setText("Pausar");
        Pause2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause2MouseClicked(evt);
            }
        });
        jPanel1.add(Pause2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 520, 100, -1));

        Stop2.setBackground(new java.awt.Color(255, 255, 51));
        Stop2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop2.setText("Finalizado y desocupado");
        Stop2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop2MouseClicked(evt);
            }
        });
        jPanel1.add(Stop2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 540, 270, 30));

        jLabel33.setBackground(new java.awt.Color(0, 255, 255));
        jLabel33.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel33.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel33.setOpaque(true);
        jPanel1.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 490, 200, 20));
        jPanel1.add(jTextField10, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 490, 70, 20));

        jLabel34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel34.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 440, 180));

        jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 420, 140, 110));

        jLabel36.setBackground(new java.awt.Color(0, 0, 0));
        jLabel36.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(0, 255, 0));
        jLabel36.setText("00 : 00 : 00 : 00");
        jLabel36.setOpaque(true);
        jPanel1.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 430, 150, -1));

        jLabel37.setBackground(new java.awt.Color(0, 0, 153));
        jLabel37.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(51, 255, 0));
        jLabel37.setText("H       :Min      :Seg    :CS");
        jLabel37.setOpaque(true);
        jPanel1.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 410, 150, 20));

        jLabel38.setBackground(new java.awt.Color(255, 0, 153));
        jLabel38.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("Nom.de Usuario ;");
        jLabel38.setOpaque(true);
        jPanel1.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 460, 100, 20));

        jTextField11.setBackground(new java.awt.Color(153, 255, 255));
        jTextField11.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField11, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 460, 170, -1));

        jButton16.setBackground(new java.awt.Color(0, 255, 255));
        jButton16.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton16.setForeground(new java.awt.Color(0, 0, 102));
        jButton16.setText("Comenzar");
        jButton16.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 520, 100, -1));

        jButton17.setBackground(new java.awt.Color(204, 0, 0));
        jButton17.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton17.setForeground(new java.awt.Color(255, 255, 0));
        jButton17.setText("Pausar");
        jButton17.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton17, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 520, 100, -1));

        jButton18.setBackground(new java.awt.Color(255, 255, 51));
        jButton18.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton18.setText("Finalizado y desocupado");
        jButton18.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton18, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 540, 270, 30));

        jLabel39.setBackground(new java.awt.Color(0, 255, 255));
        jLabel39.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel39.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel39.setOpaque(true);
        jPanel1.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 490, 200, 20));
        jPanel1.add(jTextField12, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 490, 70, 20));

        jLabel40.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel40.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 440, 180));

        jLabel41.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel41.setText("Equipo 3");
        jPanel1.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 610, 100, 80));

        jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 610, 140, 110));

        Reloj3.setBackground(new java.awt.Color(0, 0, 0));
        Reloj3.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj3.setForeground(new java.awt.Color(0, 255, 0));
        Reloj3.setText("00 : 00 : 00 : 00");
        Reloj3.setOpaque(true);
        jPanel1.add(Reloj3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 620, 150, -1));

        jLabel44.setBackground(new java.awt.Color(0, 0, 153));
        jLabel44.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(51, 255, 0));
        jLabel44.setText("H       :Min      :Seg    :CS");
        jLabel44.setOpaque(true);
        jPanel1.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 600, 150, 20));

        jLabel45.setBackground(new java.awt.Color(255, 0, 153));
        jLabel45.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(255, 255, 255));
        jLabel45.setText("Nom.de Usuario ;");
        jLabel45.setOpaque(true);
        jPanel1.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 650, 100, 20));

        jTextField13.setBackground(new java.awt.Color(153, 255, 255));
        jTextField13.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField13, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 650, 170, -1));

        Start3.setBackground(new java.awt.Color(0, 255, 255));
        Start3.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start3.setForeground(new java.awt.Color(0, 0, 102));
        Start3.setText("Comenzar");
        Start3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start3MouseClicked(evt);
            }
        });
        Start3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start3ActionPerformed(evt);
            }
        });
        jPanel1.add(Start3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 710, 100, -1));

        Pause3.setBackground(new java.awt.Color(204, 0, 0));
        Pause3.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause3.setForeground(new java.awt.Color(255, 255, 0));
        Pause3.setText("Pausar");
        Pause3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause3MouseClicked(evt);
            }
        });
        jPanel1.add(Pause3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 710, 100, -1));

        Stop3.setBackground(new java.awt.Color(255, 255, 51));
        Stop3.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop3.setText("Finalizado y desocupado");
        Stop3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop3MouseClicked(evt);
            }
        });
        jPanel1.add(Stop3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 730, 270, 30));

        jLabel46.setBackground(new java.awt.Color(0, 255, 255));
        jLabel46.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel46.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel46.setOpaque(true);
        jPanel1.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 680, 200, 20));
        jPanel1.add(jTextField14, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 680, 70, 20));

        jLabel47.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel47.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 590, 440, 180));

        jLabel48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 610, 140, 110));

        jLabel49.setBackground(new java.awt.Color(0, 0, 0));
        jLabel49.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(0, 255, 0));
        jLabel49.setText("00 : 00 : 00 : 00");
        jLabel49.setOpaque(true);
        jPanel1.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 620, 150, -1));

        jLabel50.setBackground(new java.awt.Color(0, 0, 153));
        jLabel50.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel50.setForeground(new java.awt.Color(51, 255, 0));
        jLabel50.setText("H       :Min      :Seg    :CS");
        jLabel50.setOpaque(true);
        jPanel1.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 600, 150, 20));

        jLabel51.setBackground(new java.awt.Color(255, 0, 153));
        jLabel51.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(255, 255, 255));
        jLabel51.setText("Nom.de Usuario ;");
        jLabel51.setOpaque(true);
        jPanel1.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 650, 100, 20));

        jTextField15.setBackground(new java.awt.Color(153, 255, 255));
        jTextField15.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField15, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 650, 170, -1));

        jButton22.setBackground(new java.awt.Color(0, 255, 255));
        jButton22.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton22.setForeground(new java.awt.Color(0, 0, 102));
        jButton22.setText("Comenzar");
        jButton22.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton22, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 710, 100, -1));

        jButton23.setBackground(new java.awt.Color(204, 0, 0));
        jButton23.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton23.setForeground(new java.awt.Color(255, 255, 0));
        jButton23.setText("Pausar");
        jButton23.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton23, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 710, 100, -1));

        jButton24.setBackground(new java.awt.Color(255, 255, 51));
        jButton24.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton24.setText("Finalizado y desocupado");
        jButton24.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton24, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 730, 270, 30));

        jLabel52.setBackground(new java.awt.Color(0, 255, 255));
        jLabel52.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel52.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel52.setOpaque(true);
        jPanel1.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 680, 200, 20));
        jPanel1.add(jTextField16, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 680, 70, 20));

        jLabel53.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel53.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 590, 440, 180));

        jLabel54.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel54.setText("Equipo 4");
        jPanel1.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 800, 100, 80));

        jLabel55.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 800, 140, 110));

        Reloj4.setBackground(new java.awt.Color(0, 0, 0));
        Reloj4.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj4.setForeground(new java.awt.Color(0, 255, 0));
        Reloj4.setText("00 : 00 : 00 : 00");
        Reloj4.setOpaque(true);
        jPanel1.add(Reloj4, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 810, 150, -1));

        jLabel57.setBackground(new java.awt.Color(0, 0, 153));
        jLabel57.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(51, 255, 0));
        jLabel57.setText("H       :Min      :Seg    :CS");
        jLabel57.setOpaque(true);
        jPanel1.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 790, 150, 20));

        jLabel58.setBackground(new java.awt.Color(255, 0, 153));
        jLabel58.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(255, 255, 255));
        jLabel58.setText("Nom.de Usuario ;");
        jLabel58.setOpaque(true);
        jPanel1.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 840, 100, 20));

        jTextField17.setBackground(new java.awt.Color(153, 255, 255));
        jTextField17.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField17, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 840, 170, -1));

        Start4.setBackground(new java.awt.Color(0, 255, 255));
        Start4.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start4.setForeground(new java.awt.Color(0, 0, 102));
        Start4.setText("Comenzar");
        Start4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start4MouseClicked(evt);
            }
        });
        Start4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start4ActionPerformed(evt);
            }
        });
        jPanel1.add(Start4, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 900, 100, -1));

        Pause4.setBackground(new java.awt.Color(204, 0, 0));
        Pause4.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause4.setForeground(new java.awt.Color(255, 255, 0));
        Pause4.setText("Pausar");
        Pause4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause4MouseClicked(evt);
            }
        });
        jPanel1.add(Pause4, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 900, 100, -1));

        Stop4.setBackground(new java.awt.Color(255, 255, 51));
        Stop4.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop4.setText("Finalizado y desocupado");
        Stop4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop4MouseClicked(evt);
            }
        });
        jPanel1.add(Stop4, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 920, 270, 30));

        jLabel59.setBackground(new java.awt.Color(0, 255, 255));
        jLabel59.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel59.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel59.setOpaque(true);
        jPanel1.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 870, 200, 20));
        jPanel1.add(jTextField18, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 870, 70, 20));

        jLabel60.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel60.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 780, 440, 180));

        jLabel61.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 800, 140, 110));

        jLabel62.setBackground(new java.awt.Color(0, 0, 0));
        jLabel62.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel62.setForeground(new java.awt.Color(0, 255, 0));
        jLabel62.setText("00 : 00 : 00 : 00");
        jLabel62.setOpaque(true);
        jPanel1.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 810, 150, -1));

        jLabel63.setBackground(new java.awt.Color(0, 0, 153));
        jLabel63.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel63.setForeground(new java.awt.Color(51, 255, 0));
        jLabel63.setText("H       :Min      :Seg    :CS");
        jLabel63.setOpaque(true);
        jPanel1.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 790, 150, 20));

        jLabel64.setBackground(new java.awt.Color(255, 0, 153));
        jLabel64.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(255, 255, 255));
        jLabel64.setText("Nom.de Usuario ;");
        jLabel64.setOpaque(true);
        jPanel1.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 840, 100, 20));

        jTextField19.setBackground(new java.awt.Color(153, 255, 255));
        jTextField19.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField19, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 840, 170, -1));

        jButton28.setBackground(new java.awt.Color(0, 255, 255));
        jButton28.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton28.setForeground(new java.awt.Color(0, 0, 102));
        jButton28.setText("Comenzar");
        jButton28.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton28, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 900, 100, -1));

        jButton29.setBackground(new java.awt.Color(204, 0, 0));
        jButton29.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton29.setForeground(new java.awt.Color(255, 255, 0));
        jButton29.setText("Pausar");
        jButton29.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton29, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 900, 100, -1));

        jButton30.setBackground(new java.awt.Color(255, 255, 51));
        jButton30.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton30.setText("Finalizado y desocupado");
        jButton30.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton30, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 920, 270, 30));

        jLabel65.setBackground(new java.awt.Color(0, 255, 255));
        jLabel65.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel65.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel65.setOpaque(true);
        jPanel1.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 870, 200, 20));
        jPanel1.add(jTextField20, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 870, 70, 20));

        jLabel66.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel66.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 780, 440, 180));

        jLabel67.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel67.setText("Equipo 5");
        jPanel1.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 990, 100, 80));

        jLabel68.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 990, 140, 110));

        Reloj5.setBackground(new java.awt.Color(0, 0, 0));
        Reloj5.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj5.setForeground(new java.awt.Color(0, 255, 0));
        Reloj5.setText("00 : 00 : 00 : 00");
        Reloj5.setOpaque(true);
        jPanel1.add(Reloj5, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1000, 150, -1));

        jLabel70.setBackground(new java.awt.Color(0, 0, 153));
        jLabel70.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel70.setForeground(new java.awt.Color(51, 255, 0));
        jLabel70.setText("H       :Min      :Seg    :CS");
        jLabel70.setOpaque(true);
        jPanel1.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 980, 150, 20));

        jLabel71.setBackground(new java.awt.Color(255, 0, 153));
        jLabel71.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel71.setForeground(new java.awt.Color(255, 255, 255));
        jLabel71.setText("Nom.de Usuario ;");
        jLabel71.setOpaque(true);
        jPanel1.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1030, 100, 20));

        jTextField21.setBackground(new java.awt.Color(153, 255, 255));
        jTextField21.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField21, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1030, 170, -1));

        Start5.setBackground(new java.awt.Color(0, 255, 255));
        Start5.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start5.setForeground(new java.awt.Color(0, 0, 102));
        Start5.setText("Comenzar");
        Start5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start5MouseClicked(evt);
            }
        });
        Start5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start5ActionPerformed(evt);
            }
        });
        jPanel1.add(Start5, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1090, 100, -1));

        Pause5.setBackground(new java.awt.Color(204, 0, 0));
        Pause5.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause5.setForeground(new java.awt.Color(255, 255, 0));
        Pause5.setText("Pausar");
        Pause5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause5MouseClicked(evt);
            }
        });
        jPanel1.add(Pause5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1090, 100, -1));

        Stop5.setBackground(new java.awt.Color(255, 255, 51));
        Stop5.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop5.setText("Finalizado y desocupado");
        Stop5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop5MouseClicked(evt);
            }
        });
        jPanel1.add(Stop5, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1110, 270, 30));

        jLabel72.setBackground(new java.awt.Color(0, 255, 255));
        jLabel72.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel72.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel72.setOpaque(true);
        jPanel1.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1060, 200, 20));
        jPanel1.add(jTextField22, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 1060, 70, 20));

        jLabel73.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel73.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 970, 440, 180));

        jLabel74.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 990, 140, 110));

        jLabel75.setBackground(new java.awt.Color(0, 0, 0));
        jLabel75.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel75.setForeground(new java.awt.Color(0, 255, 0));
        jLabel75.setText("00 : 00 : 00 : 00");
        jLabel75.setOpaque(true);
        jPanel1.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1000, 150, -1));

        jLabel76.setBackground(new java.awt.Color(0, 0, 153));
        jLabel76.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel76.setForeground(new java.awt.Color(51, 255, 0));
        jLabel76.setText("H       :Min      :Seg    :CS");
        jLabel76.setOpaque(true);
        jPanel1.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 980, 150, 20));

        jLabel77.setBackground(new java.awt.Color(255, 0, 153));
        jLabel77.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel77.setForeground(new java.awt.Color(255, 255, 255));
        jLabel77.setText("Nom.de Usuario ;");
        jLabel77.setOpaque(true);
        jPanel1.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1030, 100, 20));

        jTextField23.setBackground(new java.awt.Color(153, 255, 255));
        jTextField23.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField23, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1030, 170, -1));

        jButton34.setBackground(new java.awt.Color(0, 255, 255));
        jButton34.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton34.setForeground(new java.awt.Color(0, 0, 102));
        jButton34.setText("Comenzar");
        jButton34.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton34ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton34, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1090, 100, -1));

        jButton35.setBackground(new java.awt.Color(204, 0, 0));
        jButton35.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton35.setForeground(new java.awt.Color(255, 255, 0));
        jButton35.setText("Pausar");
        jButton35.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton35, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1090, 100, -1));

        jButton36.setBackground(new java.awt.Color(255, 255, 51));
        jButton36.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton36.setText("Finalizado y desocupado");
        jButton36.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton36, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1110, 270, 30));

        jLabel78.setBackground(new java.awt.Color(0, 255, 255));
        jLabel78.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel78.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel78.setOpaque(true);
        jPanel1.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1060, 200, 20));
        jPanel1.add(jTextField24, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 1060, 70, 20));

        jLabel79.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel79.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 970, 440, 180));

        jLabel80.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel80.setText("Equipo 6");
        jPanel1.add(jLabel80, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 1180, 100, 80));

        jLabel81.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 1180, 140, 110));

        Reloj6.setBackground(new java.awt.Color(0, 0, 0));
        Reloj6.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj6.setForeground(new java.awt.Color(0, 255, 0));
        Reloj6.setText("00 : 00 : 00 : 00");
        Reloj6.setOpaque(true);
        jPanel1.add(Reloj6, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1190, 150, -1));

        jLabel83.setBackground(new java.awt.Color(0, 0, 153));
        jLabel83.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel83.setForeground(new java.awt.Color(51, 255, 0));
        jLabel83.setText("H       :Min      :Seg    :CS");
        jLabel83.setOpaque(true);
        jPanel1.add(jLabel83, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1170, 150, 20));

        jLabel84.setBackground(new java.awt.Color(255, 0, 153));
        jLabel84.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel84.setForeground(new java.awt.Color(255, 255, 255));
        jLabel84.setText("Nom.de Usuario ;");
        jLabel84.setOpaque(true);
        jPanel1.add(jLabel84, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1220, 100, 20));

        jTextField25.setBackground(new java.awt.Color(153, 255, 255));
        jTextField25.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField25, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1220, 170, -1));

        Start6.setBackground(new java.awt.Color(0, 255, 255));
        Start6.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start6.setForeground(new java.awt.Color(0, 0, 102));
        Start6.setText("Comenzar");
        Start6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start6MouseClicked(evt);
            }
        });
        Start6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start6ActionPerformed(evt);
            }
        });
        jPanel1.add(Start6, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1280, 100, -1));

        Pause6.setBackground(new java.awt.Color(204, 0, 0));
        Pause6.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause6.setForeground(new java.awt.Color(255, 255, 0));
        Pause6.setText("Pausar");
        Pause6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause6MouseClicked(evt);
            }
        });
        jPanel1.add(Pause6, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1280, 100, -1));

        Stop6.setBackground(new java.awt.Color(255, 255, 51));
        Stop6.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop6.setText("Finalizado y desocupado");
        Stop6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop6MouseClicked(evt);
            }
        });
        jPanel1.add(Stop6, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1300, 270, 30));

        jLabel85.setBackground(new java.awt.Color(0, 255, 255));
        jLabel85.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel85.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel85.setOpaque(true);
        jPanel1.add(jLabel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1250, 200, 20));
        jPanel1.add(jTextField26, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 1250, 70, 20));

        jLabel86.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel86.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel86, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 1160, 440, 180));

        jLabel87.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel87, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 1180, 140, 110));

        jLabel88.setBackground(new java.awt.Color(0, 0, 0));
        jLabel88.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel88.setForeground(new java.awt.Color(0, 255, 0));
        jLabel88.setText("00 : 00 : 00 : 00");
        jLabel88.setOpaque(true);
        jPanel1.add(jLabel88, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1190, 150, -1));

        jLabel89.setBackground(new java.awt.Color(0, 0, 153));
        jLabel89.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel89.setForeground(new java.awt.Color(51, 255, 0));
        jLabel89.setText("H       :Min      :Seg    :CS");
        jLabel89.setOpaque(true);
        jPanel1.add(jLabel89, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1170, 150, 20));

        jLabel90.setBackground(new java.awt.Color(255, 0, 153));
        jLabel90.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel90.setForeground(new java.awt.Color(255, 255, 255));
        jLabel90.setText("Nom.de Usuario ;");
        jLabel90.setOpaque(true);
        jPanel1.add(jLabel90, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1220, 100, 20));

        jTextField27.setBackground(new java.awt.Color(153, 255, 255));
        jTextField27.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField27, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1220, 170, -1));

        jButton40.setBackground(new java.awt.Color(0, 255, 255));
        jButton40.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton40.setForeground(new java.awt.Color(0, 0, 102));
        jButton40.setText("Comenzar");
        jButton40.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton40ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton40, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1280, 100, -1));

        jButton41.setBackground(new java.awt.Color(204, 0, 0));
        jButton41.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton41.setForeground(new java.awt.Color(255, 255, 0));
        jButton41.setText("Pausar");
        jButton41.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton41, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1280, 100, -1));

        jButton42.setBackground(new java.awt.Color(255, 255, 51));
        jButton42.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton42.setText("Finalizado y desocupado");
        jButton42.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton42, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1300, 270, 30));

        jLabel91.setBackground(new java.awt.Color(0, 255, 255));
        jLabel91.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel91.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel91.setOpaque(true);
        jPanel1.add(jLabel91, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1250, 200, 20));
        jPanel1.add(jTextField28, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 1250, 70, 20));

        jLabel92.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel92.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel92, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 1160, 440, 180));

        jLabel93.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel93.setText("Equipo 7");
        jPanel1.add(jLabel93, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 1370, 100, 80));

        jLabel94.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel94, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 1370, 140, 110));

        Reloj7.setBackground(new java.awt.Color(0, 0, 0));
        Reloj7.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj7.setForeground(new java.awt.Color(0, 255, 0));
        Reloj7.setText("00 : 00 : 00 : 00");
        Reloj7.setOpaque(true);
        jPanel1.add(Reloj7, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1380, 150, -1));

        jLabel96.setBackground(new java.awt.Color(0, 0, 153));
        jLabel96.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel96.setForeground(new java.awt.Color(51, 255, 0));
        jLabel96.setText("H       :Min      :Seg    :CS");
        jLabel96.setOpaque(true);
        jPanel1.add(jLabel96, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1360, 150, 20));

        jLabel97.setBackground(new java.awt.Color(255, 0, 153));
        jLabel97.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel97.setForeground(new java.awt.Color(255, 255, 255));
        jLabel97.setText("Nom.de Usuario ;");
        jLabel97.setOpaque(true);
        jPanel1.add(jLabel97, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1410, 100, 20));

        jTextField29.setBackground(new java.awt.Color(153, 255, 255));
        jTextField29.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField29, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1410, 170, -1));

        Start7.setBackground(new java.awt.Color(0, 255, 255));
        Start7.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start7.setForeground(new java.awt.Color(0, 0, 102));
        Start7.setText("Comenzar");
        Start7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start7MouseClicked(evt);
            }
        });
        Start7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start7ActionPerformed(evt);
            }
        });
        jPanel1.add(Start7, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1470, 100, -1));

        Pause7.setBackground(new java.awt.Color(204, 0, 0));
        Pause7.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause7.setForeground(new java.awt.Color(255, 255, 0));
        Pause7.setText("Pausar");
        Pause7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause7MouseClicked(evt);
            }
        });
        jPanel1.add(Pause7, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1470, 100, -1));

        Stop7.setBackground(new java.awt.Color(255, 255, 51));
        Stop7.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop7.setText("Finalizado y desocupado");
        Stop7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop7MouseClicked(evt);
            }
        });
        jPanel1.add(Stop7, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1490, 270, 30));

        jLabel98.setBackground(new java.awt.Color(0, 255, 255));
        jLabel98.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel98.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel98.setOpaque(true);
        jPanel1.add(jLabel98, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1440, 200, 20));
        jPanel1.add(jTextField30, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 1440, 70, 20));

        jLabel99.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel99.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel99, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 1350, 440, 180));

        jLabel100.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel100, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 1370, 140, 110));

        jLabel101.setBackground(new java.awt.Color(0, 0, 0));
        jLabel101.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel101.setForeground(new java.awt.Color(0, 255, 0));
        jLabel101.setText("00 : 00 : 00 : 00");
        jLabel101.setOpaque(true);
        jPanel1.add(jLabel101, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1380, 150, -1));

        jLabel102.setBackground(new java.awt.Color(0, 0, 153));
        jLabel102.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel102.setForeground(new java.awt.Color(51, 255, 0));
        jLabel102.setText("H       :Min      :Seg    :CS");
        jLabel102.setOpaque(true);
        jPanel1.add(jLabel102, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1360, 150, 20));

        jLabel103.setBackground(new java.awt.Color(255, 0, 153));
        jLabel103.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel103.setForeground(new java.awt.Color(255, 255, 255));
        jLabel103.setText("Nom.de Usuario ;");
        jLabel103.setOpaque(true);
        jPanel1.add(jLabel103, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1410, 100, 20));

        jTextField31.setBackground(new java.awt.Color(153, 255, 255));
        jTextField31.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField31, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1410, 170, -1));

        jButton46.setBackground(new java.awt.Color(0, 255, 255));
        jButton46.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton46.setForeground(new java.awt.Color(0, 0, 102));
        jButton46.setText("Comenzar");
        jButton46.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton46ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton46, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1470, 100, -1));

        jButton47.setBackground(new java.awt.Color(204, 0, 0));
        jButton47.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton47.setForeground(new java.awt.Color(255, 255, 0));
        jButton47.setText("Pausar");
        jButton47.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton47, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1470, 100, -1));

        jButton48.setBackground(new java.awt.Color(255, 255, 51));
        jButton48.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton48.setText("Finalizado y desocupado");
        jButton48.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton48, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1490, 270, 30));

        jLabel104.setBackground(new java.awt.Color(0, 255, 255));
        jLabel104.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel104.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel104.setOpaque(true);
        jPanel1.add(jLabel104, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1440, 200, 20));
        jPanel1.add(jTextField32, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 1440, 70, 20));

        jLabel105.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel105.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel105, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 1350, 440, 180));

        jLabel106.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel106.setText("Equipo 8");
        jPanel1.add(jLabel106, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 1560, 100, 80));

        jLabel107.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel107, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 1560, 140, 110));

        Reloj8.setBackground(new java.awt.Color(0, 0, 0));
        Reloj8.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj8.setForeground(new java.awt.Color(0, 255, 0));
        Reloj8.setText("00 : 00 : 00 : 00");
        Reloj8.setOpaque(true);
        jPanel1.add(Reloj8, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1570, 150, -1));

        jLabel109.setBackground(new java.awt.Color(0, 0, 153));
        jLabel109.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel109.setForeground(new java.awt.Color(51, 255, 0));
        jLabel109.setText("H       :Min      :Seg    :CS");
        jLabel109.setOpaque(true);
        jPanel1.add(jLabel109, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1550, 150, 20));

        jLabel110.setBackground(new java.awt.Color(255, 0, 153));
        jLabel110.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel110.setForeground(new java.awt.Color(255, 255, 255));
        jLabel110.setText("Nom.de Usuario ;");
        jLabel110.setOpaque(true);
        jPanel1.add(jLabel110, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1600, 100, 20));

        jTextField33.setBackground(new java.awt.Color(153, 255, 255));
        jTextField33.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField33, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1600, 170, -1));

        Start8.setBackground(new java.awt.Color(0, 255, 255));
        Start8.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start8.setForeground(new java.awt.Color(0, 0, 102));
        Start8.setText("Comenzar");
        Start8.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start8MouseClicked(evt);
            }
        });
        Start8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start8ActionPerformed(evt);
            }
        });
        jPanel1.add(Start8, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1660, 100, -1));

        Pause8.setBackground(new java.awt.Color(204, 0, 0));
        Pause8.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause8.setForeground(new java.awt.Color(255, 255, 0));
        Pause8.setText("Pausar");
        Pause8.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause8MouseClicked(evt);
            }
        });
        jPanel1.add(Pause8, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1660, 100, -1));

        Stop8.setBackground(new java.awt.Color(255, 255, 51));
        Stop8.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop8.setText("Finalizado y desocupado");
        Stop8.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop8MouseClicked(evt);
            }
        });
        jPanel1.add(Stop8, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1680, 270, 30));

        jLabel111.setBackground(new java.awt.Color(0, 255, 255));
        jLabel111.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel111.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel111.setOpaque(true);
        jPanel1.add(jLabel111, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1630, 200, 20));
        jPanel1.add(jTextField34, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 1630, 70, 20));

        jLabel112.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel112.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel112, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 1540, 440, 180));

        jLabel113.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel113, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 1560, 140, 110));

        jLabel114.setBackground(new java.awt.Color(0, 0, 0));
        jLabel114.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel114.setForeground(new java.awt.Color(0, 255, 0));
        jLabel114.setText("00 : 00 : 00 : 00");
        jLabel114.setOpaque(true);
        jPanel1.add(jLabel114, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1570, 150, -1));

        jLabel115.setBackground(new java.awt.Color(0, 0, 153));
        jLabel115.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel115.setForeground(new java.awt.Color(51, 255, 0));
        jLabel115.setText("H       :Min      :Seg    :CS");
        jLabel115.setOpaque(true);
        jPanel1.add(jLabel115, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1550, 150, 20));

        jLabel116.setBackground(new java.awt.Color(255, 0, 153));
        jLabel116.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel116.setForeground(new java.awt.Color(255, 255, 255));
        jLabel116.setText("Nom.de Usuario ;");
        jLabel116.setOpaque(true);
        jPanel1.add(jLabel116, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1600, 100, 20));

        jTextField35.setBackground(new java.awt.Color(153, 255, 255));
        jTextField35.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField35, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1600, 170, -1));

        jButton52.setBackground(new java.awt.Color(0, 255, 255));
        jButton52.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton52.setForeground(new java.awt.Color(0, 0, 102));
        jButton52.setText("Comenzar");
        jButton52.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton52ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton52, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1660, 100, -1));

        jButton53.setBackground(new java.awt.Color(204, 0, 0));
        jButton53.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton53.setForeground(new java.awt.Color(255, 255, 0));
        jButton53.setText("Pausar");
        jButton53.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton53, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1660, 100, -1));

        jButton54.setBackground(new java.awt.Color(255, 255, 51));
        jButton54.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton54.setText("Finalizado y desocupado");
        jButton54.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton54, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1680, 270, 30));

        jLabel117.setBackground(new java.awt.Color(0, 255, 255));
        jLabel117.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel117.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel117.setOpaque(true);
        jPanel1.add(jLabel117, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1630, 200, 20));
        jPanel1.add(jTextField36, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 1630, 70, 20));

        jLabel118.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel118.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel118, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 1540, 440, 180));

        jLabel119.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel119.setText("Equipo 9");
        jPanel1.add(jLabel119, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 1750, 100, 80));

        jLabel120.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel120, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 1750, 140, 110));

        Reloj9.setBackground(new java.awt.Color(0, 0, 0));
        Reloj9.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj9.setForeground(new java.awt.Color(0, 255, 0));
        Reloj9.setText("00 : 00 : 00 : 00");
        Reloj9.setOpaque(true);
        jPanel1.add(Reloj9, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1760, 150, -1));

        jLabel122.setBackground(new java.awt.Color(0, 0, 153));
        jLabel122.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel122.setForeground(new java.awt.Color(51, 255, 0));
        jLabel122.setText("H       :Min      :Seg    :CS");
        jLabel122.setOpaque(true);
        jPanel1.add(jLabel122, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1740, 150, 20));

        jLabel123.setBackground(new java.awt.Color(255, 0, 153));
        jLabel123.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel123.setForeground(new java.awt.Color(255, 255, 255));
        jLabel123.setText("Nom.de Usuario ;");
        jLabel123.setOpaque(true);
        jPanel1.add(jLabel123, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1790, 100, 20));

        jTextField37.setBackground(new java.awt.Color(153, 255, 255));
        jTextField37.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField37, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1790, 170, -1));

        Start9.setBackground(new java.awt.Color(0, 255, 255));
        Start9.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start9.setForeground(new java.awt.Color(0, 0, 102));
        Start9.setText("Comenzar");
        Start9.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start9MouseClicked(evt);
            }
        });
        Start9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start9ActionPerformed(evt);
            }
        });
        jPanel1.add(Start9, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1850, 100, -1));

        Pause9.setBackground(new java.awt.Color(204, 0, 0));
        Pause9.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause9.setForeground(new java.awt.Color(255, 255, 0));
        Pause9.setText("Pausar");
        Pause9.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause9MouseClicked(evt);
            }
        });
        jPanel1.add(Pause9, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1850, 100, -1));

        Stop9.setBackground(new java.awt.Color(255, 255, 51));
        Stop9.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop9.setText("Finalizado y desocupado");
        Stop9.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop9MouseClicked(evt);
            }
        });
        jPanel1.add(Stop9, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1870, 270, 30));

        jLabel124.setBackground(new java.awt.Color(0, 255, 255));
        jLabel124.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel124.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel124.setOpaque(true);
        jPanel1.add(jLabel124, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1820, 200, 20));
        jPanel1.add(jTextField38, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 1820, 70, 20));

        jLabel125.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel125.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel125, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 1730, 440, 180));

        jLabel126.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel126, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 1750, 140, 110));

        jLabel127.setBackground(new java.awt.Color(0, 0, 0));
        jLabel127.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel127.setForeground(new java.awt.Color(0, 255, 0));
        jLabel127.setText("00 : 00 : 00 : 00");
        jLabel127.setOpaque(true);
        jPanel1.add(jLabel127, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1760, 150, -1));

        jLabel128.setBackground(new java.awt.Color(0, 0, 153));
        jLabel128.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel128.setForeground(new java.awt.Color(51, 255, 0));
        jLabel128.setText("H       :Min      :Seg    :CS");
        jLabel128.setOpaque(true);
        jPanel1.add(jLabel128, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1740, 150, 20));

        jLabel129.setBackground(new java.awt.Color(255, 0, 153));
        jLabel129.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel129.setForeground(new java.awt.Color(255, 255, 255));
        jLabel129.setText("Nom.de Usuario ;");
        jLabel129.setOpaque(true);
        jPanel1.add(jLabel129, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1790, 100, 20));

        jTextField39.setBackground(new java.awt.Color(153, 255, 255));
        jTextField39.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField39, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1790, 170, -1));

        jButton58.setBackground(new java.awt.Color(0, 255, 255));
        jButton58.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton58.setForeground(new java.awt.Color(0, 0, 102));
        jButton58.setText("Comenzar");
        jButton58.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton58.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton58ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton58, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1850, 100, -1));

        jButton59.setBackground(new java.awt.Color(204, 0, 0));
        jButton59.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton59.setForeground(new java.awt.Color(255, 255, 0));
        jButton59.setText("Pausar");
        jButton59.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton59, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1850, 100, -1));

        jButton60.setBackground(new java.awt.Color(255, 255, 51));
        jButton60.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton60.setText("Finalizado y desocupado");
        jButton60.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton60, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1870, 270, 30));

        jLabel130.setBackground(new java.awt.Color(0, 255, 255));
        jLabel130.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel130.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel130.setOpaque(true);
        jPanel1.add(jLabel130, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1820, 200, 20));
        jPanel1.add(jTextField40, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 1820, 70, 20));

        jLabel131.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel131.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel131, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 1730, 440, 180));

        jLabel132.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel132.setText("Equipo 10");
        jPanel1.add(jLabel132, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 1940, 100, 80));

        jLabel133.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel133, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 1940, 140, 110));

        Reloj10.setBackground(new java.awt.Color(0, 0, 0));
        Reloj10.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj10.setForeground(new java.awt.Color(0, 255, 0));
        Reloj10.setText("00 : 00 : 00 : 00");
        Reloj10.setOpaque(true);
        jPanel1.add(Reloj10, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1950, 150, -1));

        jLabel135.setBackground(new java.awt.Color(0, 0, 153));
        jLabel135.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel135.setForeground(new java.awt.Color(51, 255, 0));
        jLabel135.setText("H       :Min      :Seg    :CS");
        jLabel135.setOpaque(true);
        jPanel1.add(jLabel135, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1930, 150, 20));

        jLabel136.setBackground(new java.awt.Color(255, 0, 153));
        jLabel136.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel136.setForeground(new java.awt.Color(255, 255, 255));
        jLabel136.setText("Nom.de Usuario ;");
        jLabel136.setOpaque(true);
        jPanel1.add(jLabel136, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1980, 100, 20));

        jTextField41.setBackground(new java.awt.Color(153, 255, 255));
        jTextField41.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField41, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1980, 170, -1));

        Start10.setBackground(new java.awt.Color(0, 255, 255));
        Start10.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start10.setForeground(new java.awt.Color(0, 0, 102));
        Start10.setText("Comenzar");
        Start10.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start10MouseClicked(evt);
            }
        });
        Start10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start10ActionPerformed(evt);
            }
        });
        jPanel1.add(Start10, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 2040, 100, -1));

        Pause10.setBackground(new java.awt.Color(204, 0, 0));
        Pause10.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause10.setForeground(new java.awt.Color(255, 255, 0));
        Pause10.setText("Pausar");
        Pause10.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause10MouseClicked(evt);
            }
        });
        jPanel1.add(Pause10, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 2040, 100, -1));

        Stop10.setBackground(new java.awt.Color(255, 255, 51));
        Stop10.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop10.setText("Finalizado y desocupado");
        Stop10.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop10MouseClicked(evt);
            }
        });
        jPanel1.add(Stop10, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 2060, 270, 30));

        jLabel137.setBackground(new java.awt.Color(0, 255, 255));
        jLabel137.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel137.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel137.setOpaque(true);
        jPanel1.add(jLabel137, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 2010, 200, 20));
        jPanel1.add(jTextField42, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 2010, 70, 20));

        jLabel138.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel138.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel138, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 1920, 440, 180));

        jLabel139.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel139, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 1940, 140, 110));

        jLabel140.setBackground(new java.awt.Color(0, 0, 0));
        jLabel140.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel140.setForeground(new java.awt.Color(0, 255, 0));
        jLabel140.setText("00 : 00 : 00 : 00");
        jLabel140.setOpaque(true);
        jPanel1.add(jLabel140, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1950, 150, -1));

        jLabel141.setBackground(new java.awt.Color(0, 0, 153));
        jLabel141.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel141.setForeground(new java.awt.Color(51, 255, 0));
        jLabel141.setText("H       :Min      :Seg    :CS");
        jLabel141.setOpaque(true);
        jPanel1.add(jLabel141, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1930, 150, 20));

        jLabel142.setBackground(new java.awt.Color(255, 0, 153));
        jLabel142.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel142.setForeground(new java.awt.Color(255, 255, 255));
        jLabel142.setText("Nom.de Usuario ;");
        jLabel142.setOpaque(true);
        jPanel1.add(jLabel142, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1980, 100, 20));

        jTextField43.setBackground(new java.awt.Color(153, 255, 255));
        jTextField43.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField43, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 1980, 170, -1));

        jButton64.setBackground(new java.awt.Color(0, 255, 255));
        jButton64.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton64.setForeground(new java.awt.Color(0, 0, 102));
        jButton64.setText("Comenzar");
        jButton64.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton64.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton64ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton64, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 2040, 100, -1));

        jButton65.setBackground(new java.awt.Color(204, 0, 0));
        jButton65.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton65.setForeground(new java.awt.Color(255, 255, 0));
        jButton65.setText("Pausar");
        jButton65.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton65, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 2040, 100, -1));

        jButton66.setBackground(new java.awt.Color(255, 255, 51));
        jButton66.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton66.setText("Finalizado y desocupado");
        jButton66.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton66, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 2060, 270, 30));

        jLabel143.setBackground(new java.awt.Color(0, 255, 255));
        jLabel143.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel143.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel143.setOpaque(true);
        jPanel1.add(jLabel143, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 2010, 200, 20));
        jPanel1.add(jTextField44, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 2010, 70, 20));

        jLabel144.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel144.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel144, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 1920, 440, 180));

        jLabel145.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel145.setText("Equipo 11");
        jPanel1.add(jLabel145, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 230, 100, 80));

        jLabel146.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel146, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 230, 140, 110));

        Reloj11.setBackground(new java.awt.Color(0, 0, 0));
        Reloj11.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj11.setForeground(new java.awt.Color(0, 255, 0));
        Reloj11.setText("00 : 00 : 00 : 00");
        Reloj11.setOpaque(true);
        jPanel1.add(Reloj11, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 240, 150, -1));

        jLabel148.setBackground(new java.awt.Color(0, 0, 153));
        jLabel148.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel148.setForeground(new java.awt.Color(51, 255, 0));
        jLabel148.setText("H       :Min      :Seg    :CS");
        jLabel148.setOpaque(true);
        jPanel1.add(jLabel148, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 220, 150, 20));

        jLabel149.setBackground(new java.awt.Color(255, 0, 153));
        jLabel149.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel149.setForeground(new java.awt.Color(255, 255, 255));
        jLabel149.setText("Nom.de Usuario ;");
        jLabel149.setOpaque(true);
        jPanel1.add(jLabel149, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 270, 100, 20));

        jTextField45.setBackground(new java.awt.Color(153, 255, 255));
        jTextField45.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField45, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 270, 170, -1));

        Start11.setBackground(new java.awt.Color(0, 255, 255));
        Start11.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start11.setForeground(new java.awt.Color(0, 0, 102));
        Start11.setText("Comenzar");
        Start11.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start11MouseClicked(evt);
            }
        });
        Start11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start11ActionPerformed(evt);
            }
        });
        jPanel1.add(Start11, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 330, 100, -1));

        Pause11.setBackground(new java.awt.Color(204, 0, 0));
        Pause11.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause11.setForeground(new java.awt.Color(255, 255, 0));
        Pause11.setText("Pausar");
        Pause11.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause11MouseClicked(evt);
            }
        });
        jPanel1.add(Pause11, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 330, 100, -1));

        Stop11.setBackground(new java.awt.Color(255, 255, 51));
        Stop11.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop11.setText("Finalizado y desocupado");
        Stop11.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop11MouseClicked(evt);
            }
        });
        jPanel1.add(Stop11, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 350, 270, 30));

        jLabel150.setBackground(new java.awt.Color(0, 255, 255));
        jLabel150.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel150.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel150.setOpaque(true);
        jPanel1.add(jLabel150, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 300, 200, 20));
        jPanel1.add(jTextField46, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 300, 70, 20));

        jLabel151.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel151.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel151, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 210, 440, 180));

        jLabel152.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel152, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 230, 140, 110));

        jLabel153.setBackground(new java.awt.Color(0, 0, 0));
        jLabel153.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel153.setForeground(new java.awt.Color(0, 255, 0));
        jLabel153.setText("00 : 00 : 00 : 00");
        jLabel153.setOpaque(true);
        jPanel1.add(jLabel153, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 240, 150, -1));

        jLabel154.setBackground(new java.awt.Color(0, 0, 153));
        jLabel154.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel154.setForeground(new java.awt.Color(51, 255, 0));
        jLabel154.setText("H       :Min      :Seg    :CS");
        jLabel154.setOpaque(true);
        jPanel1.add(jLabel154, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 220, 150, 20));

        jLabel155.setBackground(new java.awt.Color(255, 0, 153));
        jLabel155.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel155.setForeground(new java.awt.Color(255, 255, 255));
        jLabel155.setText("Nom.de Usuario ;");
        jLabel155.setOpaque(true);
        jPanel1.add(jLabel155, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 270, 100, 20));

        jTextField47.setBackground(new java.awt.Color(153, 255, 255));
        jTextField47.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField47, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 270, 170, -1));

        jButton70.setBackground(new java.awt.Color(0, 255, 255));
        jButton70.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton70.setForeground(new java.awt.Color(0, 0, 102));
        jButton70.setText("Comenzar");
        jButton70.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton70.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton70ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton70, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 330, 100, -1));

        jButton71.setBackground(new java.awt.Color(204, 0, 0));
        jButton71.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton71.setForeground(new java.awt.Color(255, 255, 0));
        jButton71.setText("Pausar");
        jButton71.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton71, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 330, 100, -1));

        jButton72.setBackground(new java.awt.Color(255, 255, 51));
        jButton72.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton72.setText("Finalizado y desocupado");
        jButton72.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton72, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 350, 270, 30));

        jLabel156.setBackground(new java.awt.Color(0, 255, 255));
        jLabel156.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel156.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel156.setOpaque(true);
        jPanel1.add(jLabel156, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 300, 200, 20));
        jPanel1.add(jTextField48, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 300, 70, 20));

        jLabel157.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel157.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel157, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 210, 440, 180));

        jLabel158.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel158.setText("Equipo 12");
        jPanel1.add(jLabel158, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 420, 100, 80));

        jLabel159.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel159, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 420, 140, 110));

        Reloj12.setBackground(new java.awt.Color(0, 0, 0));
        Reloj12.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj12.setForeground(new java.awt.Color(0, 255, 0));
        Reloj12.setText("00 : 00 : 00 : 00");
        Reloj12.setOpaque(true);
        jPanel1.add(Reloj12, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 430, 150, -1));

        jLabel161.setBackground(new java.awt.Color(0, 0, 153));
        jLabel161.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel161.setForeground(new java.awt.Color(51, 255, 0));
        jLabel161.setText("H       :Min      :Seg    :CS");
        jLabel161.setOpaque(true);
        jPanel1.add(jLabel161, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 410, 150, 20));

        jLabel162.setBackground(new java.awt.Color(255, 0, 153));
        jLabel162.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel162.setForeground(new java.awt.Color(255, 255, 255));
        jLabel162.setText("Nom.de Usuario ;");
        jLabel162.setOpaque(true);
        jPanel1.add(jLabel162, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 460, 100, 20));

        jTextField49.setBackground(new java.awt.Color(153, 255, 255));
        jTextField49.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField49, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 460, 170, -1));

        Start12.setBackground(new java.awt.Color(0, 255, 255));
        Start12.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start12.setForeground(new java.awt.Color(0, 0, 102));
        Start12.setText("Comenzar");
        Start12.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start12MouseClicked(evt);
            }
        });
        Start12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start12ActionPerformed(evt);
            }
        });
        jPanel1.add(Start12, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 520, 100, -1));

        Pause12.setBackground(new java.awt.Color(204, 0, 0));
        Pause12.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause12.setForeground(new java.awt.Color(255, 255, 0));
        Pause12.setText("Pausar");
        Pause12.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause12MouseClicked(evt);
            }
        });
        jPanel1.add(Pause12, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 520, 100, -1));

        Stop12.setBackground(new java.awt.Color(255, 255, 51));
        Stop12.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop12.setText("Finalizado y desocupado");
        Stop12.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop12MouseClicked(evt);
            }
        });
        jPanel1.add(Stop12, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 540, 270, 30));

        jLabel163.setBackground(new java.awt.Color(0, 255, 255));
        jLabel163.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel163.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel163.setOpaque(true);
        jPanel1.add(jLabel163, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 490, 200, 20));
        jPanel1.add(jTextField50, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 490, 70, 20));

        jLabel164.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel164.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel164, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 400, 440, 180));

        jLabel165.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel165, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 420, 140, 110));

        jLabel166.setBackground(new java.awt.Color(0, 0, 0));
        jLabel166.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel166.setForeground(new java.awt.Color(0, 255, 0));
        jLabel166.setText("00 : 00 : 00 : 00");
        jLabel166.setOpaque(true);
        jPanel1.add(jLabel166, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 430, 150, -1));

        jLabel167.setBackground(new java.awt.Color(0, 0, 153));
        jLabel167.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel167.setForeground(new java.awt.Color(51, 255, 0));
        jLabel167.setText("H       :Min      :Seg    :CS");
        jLabel167.setOpaque(true);
        jPanel1.add(jLabel167, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 410, 150, 20));

        jLabel168.setBackground(new java.awt.Color(255, 0, 153));
        jLabel168.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel168.setForeground(new java.awt.Color(255, 255, 255));
        jLabel168.setText("Nom.de Usuario ;");
        jLabel168.setOpaque(true);
        jPanel1.add(jLabel168, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 460, 100, 20));

        jTextField51.setBackground(new java.awt.Color(153, 255, 255));
        jTextField51.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField51, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 460, 170, -1));

        jButton76.setBackground(new java.awt.Color(0, 255, 255));
        jButton76.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton76.setForeground(new java.awt.Color(0, 0, 102));
        jButton76.setText("Comenzar");
        jButton76.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton76.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton76ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton76, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 520, 100, -1));

        jButton77.setBackground(new java.awt.Color(204, 0, 0));
        jButton77.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton77.setForeground(new java.awt.Color(255, 255, 0));
        jButton77.setText("Pausar");
        jButton77.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton77, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 520, 100, -1));

        jButton78.setBackground(new java.awt.Color(255, 255, 51));
        jButton78.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton78.setText("Finalizado y desocupado");
        jButton78.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton78, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 540, 270, 30));

        jLabel169.setBackground(new java.awt.Color(0, 255, 255));
        jLabel169.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel169.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel169.setOpaque(true);
        jPanel1.add(jLabel169, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 490, 200, 20));
        jPanel1.add(jTextField52, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 490, 70, 20));

        jLabel170.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel170.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel170, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 400, 440, 180));

        jLabel171.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel171.setText("Equipo 13");
        jPanel1.add(jLabel171, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 610, 100, 80));

        jLabel172.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel172, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 610, 140, 110));

        Reloj13.setBackground(new java.awt.Color(0, 0, 0));
        Reloj13.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj13.setForeground(new java.awt.Color(0, 255, 0));
        Reloj13.setText("00 : 00 : 00 : 00");
        Reloj13.setOpaque(true);
        jPanel1.add(Reloj13, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 620, 150, -1));

        jLabel174.setBackground(new java.awt.Color(0, 0, 153));
        jLabel174.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel174.setForeground(new java.awt.Color(51, 255, 0));
        jLabel174.setText("H       :Min      :Seg    :CS");
        jLabel174.setOpaque(true);
        jPanel1.add(jLabel174, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 600, 150, 20));

        jLabel175.setBackground(new java.awt.Color(255, 0, 153));
        jLabel175.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel175.setForeground(new java.awt.Color(255, 255, 255));
        jLabel175.setText("Nom.de Usuario ;");
        jLabel175.setOpaque(true);
        jPanel1.add(jLabel175, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 650, 100, 20));

        jTextField53.setBackground(new java.awt.Color(153, 255, 255));
        jTextField53.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField53, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 650, 170, -1));

        Start13.setBackground(new java.awt.Color(0, 255, 255));
        Start13.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start13.setForeground(new java.awt.Color(0, 0, 102));
        Start13.setText("Comenzar");
        Start13.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start13MouseClicked(evt);
            }
        });
        Start13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start13ActionPerformed(evt);
            }
        });
        jPanel1.add(Start13, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 710, 100, -1));

        Pause13.setBackground(new java.awt.Color(204, 0, 0));
        Pause13.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause13.setForeground(new java.awt.Color(255, 255, 0));
        Pause13.setText("Pausar");
        Pause13.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause13MouseClicked(evt);
            }
        });
        jPanel1.add(Pause13, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 710, 100, -1));

        Stop13.setBackground(new java.awt.Color(255, 255, 51));
        Stop13.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop13.setText("Finalizado y desocupado");
        Stop13.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop13MouseClicked(evt);
            }
        });
        jPanel1.add(Stop13, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 730, 270, 30));

        jLabel176.setBackground(new java.awt.Color(0, 255, 255));
        jLabel176.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel176.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel176.setOpaque(true);
        jPanel1.add(jLabel176, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 680, -1, 20));
        jPanel1.add(jTextField54, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 680, 70, 20));

        jLabel177.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel177.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel177, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 590, 440, 180));

        jLabel178.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel178, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 610, 140, 110));

        jLabel179.setBackground(new java.awt.Color(0, 0, 0));
        jLabel179.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel179.setForeground(new java.awt.Color(0, 255, 0));
        jLabel179.setText("00 : 00 : 00 : 00");
        jLabel179.setOpaque(true);
        jPanel1.add(jLabel179, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 620, 150, -1));

        jLabel180.setBackground(new java.awt.Color(0, 0, 153));
        jLabel180.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel180.setForeground(new java.awt.Color(51, 255, 0));
        jLabel180.setText("H       :Min      :Seg    :CS");
        jLabel180.setOpaque(true);
        jPanel1.add(jLabel180, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 600, 150, 20));

        jLabel181.setBackground(new java.awt.Color(255, 0, 153));
        jLabel181.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel181.setForeground(new java.awt.Color(255, 255, 255));
        jLabel181.setText("Nom.de Usuario ;");
        jLabel181.setOpaque(true);
        jPanel1.add(jLabel181, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 650, 100, 20));

        jTextField55.setBackground(new java.awt.Color(153, 255, 255));
        jTextField55.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField55, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 650, 170, -1));

        jButton82.setBackground(new java.awt.Color(0, 255, 255));
        jButton82.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton82.setForeground(new java.awt.Color(0, 0, 102));
        jButton82.setText("Comenzar");
        jButton82.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton82.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton82ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton82, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 710, 100, -1));

        jButton83.setBackground(new java.awt.Color(204, 0, 0));
        jButton83.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton83.setForeground(new java.awt.Color(255, 255, 0));
        jButton83.setText("Pausar");
        jButton83.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton83, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 710, 100, -1));

        jButton84.setBackground(new java.awt.Color(255, 255, 51));
        jButton84.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton84.setText("Finalizado y desocupado");
        jButton84.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton84, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 730, 270, 30));

        jLabel182.setBackground(new java.awt.Color(0, 255, 255));
        jLabel182.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel182.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel182.setOpaque(true);
        jPanel1.add(jLabel182, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 680, 200, 20));
        jPanel1.add(jTextField56, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 680, 70, 20));

        jLabel183.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel183.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel183, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 590, 440, 180));

        jLabel184.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel184.setText("Equipo 14");
        jPanel1.add(jLabel184, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 800, 100, 80));

        jLabel185.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel185, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 800, 140, 110));

        Reloj14.setBackground(new java.awt.Color(0, 0, 0));
        Reloj14.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj14.setForeground(new java.awt.Color(0, 255, 0));
        Reloj14.setText("00 : 00 : 00 : 00");
        Reloj14.setOpaque(true);
        jPanel1.add(Reloj14, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 810, 150, -1));

        jLabel187.setBackground(new java.awt.Color(0, 0, 153));
        jLabel187.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel187.setForeground(new java.awt.Color(51, 255, 0));
        jLabel187.setText("H       :Min      :Seg    :CS");
        jLabel187.setOpaque(true);
        jPanel1.add(jLabel187, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 790, 150, 20));

        jLabel188.setBackground(new java.awt.Color(255, 0, 153));
        jLabel188.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel188.setForeground(new java.awt.Color(255, 255, 255));
        jLabel188.setText("Nom.de Usuario ;");
        jLabel188.setOpaque(true);
        jPanel1.add(jLabel188, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 840, 100, 20));

        jTextField57.setBackground(new java.awt.Color(153, 255, 255));
        jTextField57.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField57, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 840, 170, -1));

        Start14.setBackground(new java.awt.Color(0, 255, 255));
        Start14.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start14.setForeground(new java.awt.Color(0, 0, 102));
        Start14.setText("Comenzar");
        Start14.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start14MouseClicked(evt);
            }
        });
        Start14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start14ActionPerformed(evt);
            }
        });
        jPanel1.add(Start14, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 900, 100, -1));

        Pause14.setBackground(new java.awt.Color(204, 0, 0));
        Pause14.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause14.setForeground(new java.awt.Color(255, 255, 0));
        Pause14.setText("Pausar");
        Pause14.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause14MouseClicked(evt);
            }
        });
        jPanel1.add(Pause14, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 900, 100, -1));

        Stop14.setBackground(new java.awt.Color(255, 255, 51));
        Stop14.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop14.setText("Finalizado y desocupado");
        Stop14.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop14MouseClicked(evt);
            }
        });
        jPanel1.add(Stop14, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 920, 270, 30));

        jLabel189.setBackground(new java.awt.Color(0, 255, 255));
        jLabel189.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel189.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel189.setOpaque(true);
        jPanel1.add(jLabel189, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 870, -1, 20));
        jPanel1.add(jTextField58, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 870, 70, 20));

        jLabel190.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel190.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel190, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 780, 440, 180));

        jLabel191.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel191, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 800, 140, 110));

        jLabel192.setBackground(new java.awt.Color(0, 0, 0));
        jLabel192.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel192.setForeground(new java.awt.Color(0, 255, 0));
        jLabel192.setText("00 : 00 : 00 : 00");
        jLabel192.setOpaque(true);
        jPanel1.add(jLabel192, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 810, 150, -1));

        jLabel193.setBackground(new java.awt.Color(0, 0, 153));
        jLabel193.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel193.setForeground(new java.awt.Color(51, 255, 0));
        jLabel193.setText("H       :Min      :Seg    :CS");
        jLabel193.setOpaque(true);
        jPanel1.add(jLabel193, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 790, 150, 20));

        jLabel194.setBackground(new java.awt.Color(255, 0, 153));
        jLabel194.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel194.setForeground(new java.awt.Color(255, 255, 255));
        jLabel194.setText("Nom.de Usuario ;");
        jLabel194.setOpaque(true);
        jPanel1.add(jLabel194, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 840, 100, 20));

        jTextField59.setBackground(new java.awt.Color(153, 255, 255));
        jTextField59.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField59, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 840, 170, -1));

        jButton88.setBackground(new java.awt.Color(0, 255, 255));
        jButton88.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton88.setForeground(new java.awt.Color(0, 0, 102));
        jButton88.setText("Comenzar");
        jButton88.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton88.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton88ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton88, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 900, 100, -1));

        jButton89.setBackground(new java.awt.Color(204, 0, 0));
        jButton89.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton89.setForeground(new java.awt.Color(255, 255, 0));
        jButton89.setText("Pausar");
        jButton89.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton89, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 900, 100, -1));

        jButton90.setBackground(new java.awt.Color(255, 255, 51));
        jButton90.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton90.setText("Finalizado y desocupado");
        jButton90.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton90, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 920, 270, 30));

        jLabel195.setBackground(new java.awt.Color(0, 255, 255));
        jLabel195.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel195.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel195.setOpaque(true);
        jPanel1.add(jLabel195, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 870, 200, 20));
        jPanel1.add(jTextField60, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 870, 70, 20));

        jLabel196.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel196.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel196, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 780, 440, 180));

        jLabel197.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel197.setText("Equipo 15");
        jPanel1.add(jLabel197, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 990, 100, 80));

        jLabel198.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel198, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 990, 140, 110));

        Reloj15.setBackground(new java.awt.Color(0, 0, 0));
        Reloj15.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj15.setForeground(new java.awt.Color(0, 255, 0));
        Reloj15.setText("00 : 00 : 00 : 00");
        Reloj15.setOpaque(true);
        jPanel1.add(Reloj15, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1000, 150, -1));

        jLabel200.setBackground(new java.awt.Color(0, 0, 153));
        jLabel200.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel200.setForeground(new java.awt.Color(51, 255, 0));
        jLabel200.setText("H       :Min      :Seg    :CS");
        jLabel200.setOpaque(true);
        jPanel1.add(jLabel200, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 980, 150, 20));

        jLabel201.setBackground(new java.awt.Color(255, 0, 153));
        jLabel201.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel201.setForeground(new java.awt.Color(255, 255, 255));
        jLabel201.setText("Nom.de Usuario ;");
        jLabel201.setOpaque(true);
        jPanel1.add(jLabel201, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1030, 100, 20));

        jTextField61.setBackground(new java.awt.Color(153, 255, 255));
        jTextField61.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField61, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1030, 170, -1));

        Start15.setBackground(new java.awt.Color(0, 255, 255));
        Start15.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start15.setForeground(new java.awt.Color(0, 0, 102));
        Start15.setText("Comenzar");
        Start15.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start15MouseClicked(evt);
            }
        });
        Start15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start15ActionPerformed(evt);
            }
        });
        jPanel1.add(Start15, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1090, 100, -1));

        Pause15.setBackground(new java.awt.Color(204, 0, 0));
        Pause15.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause15.setForeground(new java.awt.Color(255, 255, 0));
        Pause15.setText("Pausar");
        Pause15.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause15MouseClicked(evt);
            }
        });
        jPanel1.add(Pause15, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1090, 100, -1));

        Stop15.setBackground(new java.awt.Color(255, 255, 51));
        Stop15.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop15.setText("Finalizado y desocupado");
        Stop15.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop15MouseClicked(evt);
            }
        });
        jPanel1.add(Stop15, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1110, 270, 30));

        jLabel202.setBackground(new java.awt.Color(0, 255, 255));
        jLabel202.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel202.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel202.setOpaque(true);
        jPanel1.add(jLabel202, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1060, -1, 20));
        jPanel1.add(jTextField62, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 1060, 70, 20));

        jLabel203.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel203.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel203, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 970, 440, 180));

        jLabel204.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel204, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 990, 140, 110));

        jLabel205.setBackground(new java.awt.Color(0, 0, 0));
        jLabel205.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel205.setForeground(new java.awt.Color(0, 255, 0));
        jLabel205.setText("00 : 00 : 00 : 00");
        jLabel205.setOpaque(true);
        jPanel1.add(jLabel205, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1000, 150, -1));

        jLabel206.setBackground(new java.awt.Color(0, 0, 153));
        jLabel206.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel206.setForeground(new java.awt.Color(51, 255, 0));
        jLabel206.setText("H       :Min      :Seg    :CS");
        jLabel206.setOpaque(true);
        jPanel1.add(jLabel206, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 980, 150, 20));

        jLabel207.setBackground(new java.awt.Color(255, 0, 153));
        jLabel207.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel207.setForeground(new java.awt.Color(255, 255, 255));
        jLabel207.setText("Nom.de Usuario ;");
        jLabel207.setOpaque(true);
        jPanel1.add(jLabel207, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1030, 100, 20));

        jTextField63.setBackground(new java.awt.Color(153, 255, 255));
        jTextField63.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField63, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1030, 170, -1));

        jButton94.setBackground(new java.awt.Color(0, 255, 255));
        jButton94.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton94.setForeground(new java.awt.Color(0, 0, 102));
        jButton94.setText("Comenzar");
        jButton94.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton94.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton94ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton94, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1090, 100, -1));

        jButton95.setBackground(new java.awt.Color(204, 0, 0));
        jButton95.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton95.setForeground(new java.awt.Color(255, 255, 0));
        jButton95.setText("Pausar");
        jButton95.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton95, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1090, 100, -1));

        jButton96.setBackground(new java.awt.Color(255, 255, 51));
        jButton96.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton96.setText("Finalizado y desocupado");
        jButton96.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton96, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1110, 270, 30));

        jLabel208.setBackground(new java.awt.Color(0, 255, 255));
        jLabel208.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel208.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel208.setOpaque(true);
        jPanel1.add(jLabel208, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1060, 200, 20));
        jPanel1.add(jTextField64, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 1060, 70, 20));

        jLabel209.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel209.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel209, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 970, 440, 180));

        jLabel210.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel210.setText("Equipo 16");
        jPanel1.add(jLabel210, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 1180, 100, 80));

        jLabel211.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel211, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1180, 140, 110));

        Reloj16.setBackground(new java.awt.Color(0, 0, 0));
        Reloj16.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj16.setForeground(new java.awt.Color(0, 255, 0));
        Reloj16.setText("00 : 00 : 00 : 00");
        Reloj16.setOpaque(true);
        jPanel1.add(Reloj16, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1190, 150, -1));

        jLabel213.setBackground(new java.awt.Color(0, 0, 153));
        jLabel213.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel213.setForeground(new java.awt.Color(51, 255, 0));
        jLabel213.setText("H       :Min      :Seg    :CS");
        jLabel213.setOpaque(true);
        jPanel1.add(jLabel213, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1170, 150, 20));

        jLabel214.setBackground(new java.awt.Color(255, 0, 153));
        jLabel214.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel214.setForeground(new java.awt.Color(255, 255, 255));
        jLabel214.setText("Nom.de Usuario ;");
        jLabel214.setOpaque(true);
        jPanel1.add(jLabel214, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1220, 100, 20));

        jTextField65.setBackground(new java.awt.Color(153, 255, 255));
        jTextField65.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField65, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1220, 170, -1));

        Start16.setBackground(new java.awt.Color(0, 255, 255));
        Start16.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start16.setForeground(new java.awt.Color(0, 0, 102));
        Start16.setText("Comenzar");
        Start16.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start16MouseClicked(evt);
            }
        });
        Start16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start16ActionPerformed(evt);
            }
        });
        jPanel1.add(Start16, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1280, 100, -1));

        Pause16.setBackground(new java.awt.Color(204, 0, 0));
        Pause16.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause16.setForeground(new java.awt.Color(255, 255, 0));
        Pause16.setText("Pausar");
        Pause16.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause16MouseClicked(evt);
            }
        });
        jPanel1.add(Pause16, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1280, 100, -1));

        Stop16.setBackground(new java.awt.Color(255, 255, 51));
        Stop16.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop16.setText("Finalizado y desocupado");
        Stop16.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop16MouseClicked(evt);
            }
        });
        jPanel1.add(Stop16, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1300, 270, 30));

        jLabel215.setBackground(new java.awt.Color(0, 255, 255));
        jLabel215.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel215.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel215.setOpaque(true);
        jPanel1.add(jLabel215, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1250, -1, 20));
        jPanel1.add(jTextField66, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 1250, 70, 20));

        jLabel216.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel216.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel216, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 1160, 440, 180));

        jLabel217.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel217, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1180, 140, 110));

        jLabel218.setBackground(new java.awt.Color(0, 0, 0));
        jLabel218.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel218.setForeground(new java.awt.Color(0, 255, 0));
        jLabel218.setText("00 : 00 : 00 : 00");
        jLabel218.setOpaque(true);
        jPanel1.add(jLabel218, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1190, 150, -1));

        jLabel219.setBackground(new java.awt.Color(0, 0, 153));
        jLabel219.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel219.setForeground(new java.awt.Color(51, 255, 0));
        jLabel219.setText("H       :Min      :Seg    :CS");
        jLabel219.setOpaque(true);
        jPanel1.add(jLabel219, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1170, 150, 20));

        jLabel220.setBackground(new java.awt.Color(255, 0, 153));
        jLabel220.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel220.setForeground(new java.awt.Color(255, 255, 255));
        jLabel220.setText("Nom.de Usuario ;");
        jLabel220.setOpaque(true);
        jPanel1.add(jLabel220, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1220, 100, 20));

        jTextField67.setBackground(new java.awt.Color(153, 255, 255));
        jTextField67.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField67, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1220, 170, -1));

        jButton100.setBackground(new java.awt.Color(0, 255, 255));
        jButton100.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton100.setForeground(new java.awt.Color(0, 0, 102));
        jButton100.setText("Comenzar");
        jButton100.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton100.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton100ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton100, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1280, 100, -1));

        jButton101.setBackground(new java.awt.Color(204, 0, 0));
        jButton101.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton101.setForeground(new java.awt.Color(255, 255, 0));
        jButton101.setText("Pausar");
        jButton101.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton101, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1280, 100, -1));

        jButton102.setBackground(new java.awt.Color(255, 255, 51));
        jButton102.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton102.setText("Finalizado y desocupado");
        jButton102.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton102, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1300, 270, 30));

        jLabel221.setBackground(new java.awt.Color(0, 255, 255));
        jLabel221.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel221.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel221.setOpaque(true);
        jPanel1.add(jLabel221, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1250, 200, 20));
        jPanel1.add(jTextField68, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 1250, 70, 20));

        jLabel222.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel222.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel222, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 1160, 440, 180));

        jLabel223.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel223.setText("Equipo 17");
        jPanel1.add(jLabel223, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 1370, 100, 80));

        jLabel224.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel224, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1370, 140, 110));

        Reloj17.setBackground(new java.awt.Color(0, 0, 0));
        Reloj17.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj17.setForeground(new java.awt.Color(0, 255, 0));
        Reloj17.setText("00 : 00 : 00 : 00");
        Reloj17.setOpaque(true);
        jPanel1.add(Reloj17, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1380, 150, -1));

        jLabel226.setBackground(new java.awt.Color(0, 0, 153));
        jLabel226.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel226.setForeground(new java.awt.Color(51, 255, 0));
        jLabel226.setText("H       :Min      :Seg    :CS");
        jLabel226.setOpaque(true);
        jPanel1.add(jLabel226, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1360, 150, 20));

        jLabel227.setBackground(new java.awt.Color(255, 0, 153));
        jLabel227.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel227.setForeground(new java.awt.Color(255, 255, 255));
        jLabel227.setText("Nom.de Usuario ;");
        jLabel227.setOpaque(true);
        jPanel1.add(jLabel227, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1410, 100, 20));

        jTextField69.setBackground(new java.awt.Color(153, 255, 255));
        jTextField69.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField69, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1410, 170, -1));

        Start17.setBackground(new java.awt.Color(0, 255, 255));
        Start17.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start17.setForeground(new java.awt.Color(0, 0, 102));
        Start17.setText("Comenzar");
        Start17.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start17MouseClicked(evt);
            }
        });
        Start17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start17ActionPerformed(evt);
            }
        });
        jPanel1.add(Start17, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1470, 100, -1));

        Pause17.setBackground(new java.awt.Color(204, 0, 0));
        Pause17.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause17.setForeground(new java.awt.Color(255, 255, 0));
        Pause17.setText("Pausar");
        Pause17.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause17MouseClicked(evt);
            }
        });
        jPanel1.add(Pause17, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1470, 100, -1));

        Stop17.setBackground(new java.awt.Color(255, 255, 51));
        Stop17.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop17.setText("Finalizado y desocupado");
        Stop17.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop17MouseClicked(evt);
            }
        });
        jPanel1.add(Stop17, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1490, 270, 30));

        jLabel228.setBackground(new java.awt.Color(0, 255, 255));
        jLabel228.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel228.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel228.setOpaque(true);
        jPanel1.add(jLabel228, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1440, -1, 20));
        jPanel1.add(jTextField70, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 1440, 70, 20));

        jLabel229.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel229.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel229, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 1350, 440, 180));

        jLabel230.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel230, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1370, 140, 110));

        jLabel231.setBackground(new java.awt.Color(0, 0, 0));
        jLabel231.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel231.setForeground(new java.awt.Color(0, 255, 0));
        jLabel231.setText("00 : 00 : 00 : 00");
        jLabel231.setOpaque(true);
        jPanel1.add(jLabel231, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1380, 150, -1));

        jLabel232.setBackground(new java.awt.Color(0, 0, 153));
        jLabel232.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel232.setForeground(new java.awt.Color(51, 255, 0));
        jLabel232.setText("H       :Min      :Seg    :CS");
        jLabel232.setOpaque(true);
        jPanel1.add(jLabel232, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1360, 150, 20));

        jLabel233.setBackground(new java.awt.Color(255, 0, 153));
        jLabel233.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel233.setForeground(new java.awt.Color(255, 255, 255));
        jLabel233.setText("Nom.de Usuario ;");
        jLabel233.setOpaque(true);
        jPanel1.add(jLabel233, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1410, 100, 20));

        jTextField71.setBackground(new java.awt.Color(153, 255, 255));
        jTextField71.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField71, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1410, 170, -1));

        jButton106.setBackground(new java.awt.Color(0, 255, 255));
        jButton106.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton106.setForeground(new java.awt.Color(0, 0, 102));
        jButton106.setText("Comenzar");
        jButton106.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton106.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton106ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton106, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1470, 100, -1));

        jButton107.setBackground(new java.awt.Color(204, 0, 0));
        jButton107.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton107.setForeground(new java.awt.Color(255, 255, 0));
        jButton107.setText("Pausar");
        jButton107.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton107, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1470, 100, -1));

        jButton108.setBackground(new java.awt.Color(255, 255, 51));
        jButton108.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton108.setText("Finalizado y desocupado");
        jButton108.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton108, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1490, 270, 30));

        jLabel234.setBackground(new java.awt.Color(0, 255, 255));
        jLabel234.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel234.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel234.setOpaque(true);
        jPanel1.add(jLabel234, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1440, 200, 20));
        jPanel1.add(jTextField72, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 1440, 70, 20));

        jLabel235.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel235.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel235, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 1350, 440, 180));

        jLabel236.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel236.setText("Equipo 18");
        jPanel1.add(jLabel236, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 1560, 100, 80));

        jLabel237.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel237, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1560, 140, 110));

        Reloj18.setBackground(new java.awt.Color(0, 0, 0));
        Reloj18.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj18.setForeground(new java.awt.Color(0, 255, 0));
        Reloj18.setText("00 : 00 : 00 : 00");
        Reloj18.setOpaque(true);
        jPanel1.add(Reloj18, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1570, 150, -1));

        jLabel239.setBackground(new java.awt.Color(0, 0, 153));
        jLabel239.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel239.setForeground(new java.awt.Color(51, 255, 0));
        jLabel239.setText("H       :Min      :Seg    :CS");
        jLabel239.setOpaque(true);
        jPanel1.add(jLabel239, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1550, 150, 20));

        jLabel240.setBackground(new java.awt.Color(255, 0, 153));
        jLabel240.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel240.setForeground(new java.awt.Color(255, 255, 255));
        jLabel240.setText("Nom.de Usuario ;");
        jLabel240.setOpaque(true);
        jPanel1.add(jLabel240, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1600, 100, 20));

        jTextField73.setBackground(new java.awt.Color(153, 255, 255));
        jTextField73.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField73, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1600, 170, -1));

        Start18.setBackground(new java.awt.Color(0, 255, 255));
        Start18.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start18.setForeground(new java.awt.Color(0, 0, 102));
        Start18.setText("Comenzar");
        Start18.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start18MouseClicked(evt);
            }
        });
        Start18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start18ActionPerformed(evt);
            }
        });
        jPanel1.add(Start18, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1660, 100, -1));

        Pause18.setBackground(new java.awt.Color(204, 0, 0));
        Pause18.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause18.setForeground(new java.awt.Color(255, 255, 0));
        Pause18.setText("Pausar");
        Pause18.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause18MouseClicked(evt);
            }
        });
        jPanel1.add(Pause18, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1660, 100, -1));

        Stop18.setBackground(new java.awt.Color(255, 255, 51));
        Stop18.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop18.setText("Finalizado y desocupado");
        Stop18.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop18MouseClicked(evt);
            }
        });
        jPanel1.add(Stop18, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1680, 270, 30));

        jLabel241.setBackground(new java.awt.Color(0, 255, 255));
        jLabel241.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel241.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel241.setOpaque(true);
        jPanel1.add(jLabel241, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1630, -1, 20));
        jPanel1.add(jTextField74, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 1630, 70, 20));

        jLabel242.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel242.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel242, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 1540, 440, 180));

        jLabel243.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel243, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1560, 140, 110));

        jLabel244.setBackground(new java.awt.Color(0, 0, 0));
        jLabel244.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel244.setForeground(new java.awt.Color(0, 255, 0));
        jLabel244.setText("00 : 00 : 00 : 00");
        jLabel244.setOpaque(true);
        jPanel1.add(jLabel244, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1570, 150, -1));

        jLabel245.setBackground(new java.awt.Color(0, 0, 153));
        jLabel245.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel245.setForeground(new java.awt.Color(51, 255, 0));
        jLabel245.setText("H       :Min      :Seg    :CS");
        jLabel245.setOpaque(true);
        jPanel1.add(jLabel245, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1550, 150, 20));

        jLabel246.setBackground(new java.awt.Color(255, 0, 153));
        jLabel246.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel246.setForeground(new java.awt.Color(255, 255, 255));
        jLabel246.setText("Nom.de Usuario ;");
        jLabel246.setOpaque(true);
        jPanel1.add(jLabel246, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1600, 100, 20));

        jTextField75.setBackground(new java.awt.Color(153, 255, 255));
        jTextField75.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField75, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1600, 170, -1));

        jButton112.setBackground(new java.awt.Color(0, 255, 255));
        jButton112.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton112.setForeground(new java.awt.Color(0, 0, 102));
        jButton112.setText("Comenzar");
        jButton112.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton112.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton112ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton112, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1660, 100, -1));

        jButton113.setBackground(new java.awt.Color(204, 0, 0));
        jButton113.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton113.setForeground(new java.awt.Color(255, 255, 0));
        jButton113.setText("Pausar");
        jButton113.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton113, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1660, 100, -1));

        jButton114.setBackground(new java.awt.Color(255, 255, 51));
        jButton114.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton114.setText("Finalizado y desocupado");
        jButton114.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton114, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1680, 270, 30));

        jLabel247.setBackground(new java.awt.Color(0, 255, 255));
        jLabel247.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel247.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel247.setOpaque(true);
        jPanel1.add(jLabel247, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1630, 200, 20));
        jPanel1.add(jTextField76, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 1630, 70, 20));

        jLabel248.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel248.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel248, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 1540, 440, 180));

        jLabel249.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel249.setText("Equipo 19");
        jPanel1.add(jLabel249, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 1750, 100, 80));

        jLabel250.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel250, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1750, 140, 110));

        Reloj19.setBackground(new java.awt.Color(0, 0, 0));
        Reloj19.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj19.setForeground(new java.awt.Color(0, 255, 0));
        Reloj19.setText("00 : 00 : 00 : 00");
        Reloj19.setOpaque(true);
        jPanel1.add(Reloj19, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1760, 150, -1));

        jLabel252.setBackground(new java.awt.Color(0, 0, 153));
        jLabel252.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel252.setForeground(new java.awt.Color(51, 255, 0));
        jLabel252.setText("H       :Min      :Seg    :CS");
        jLabel252.setOpaque(true);
        jPanel1.add(jLabel252, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1740, 150, 20));

        jLabel253.setBackground(new java.awt.Color(255, 0, 153));
        jLabel253.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel253.setForeground(new java.awt.Color(255, 255, 255));
        jLabel253.setText("Nom.de Usuario ;");
        jLabel253.setOpaque(true);
        jPanel1.add(jLabel253, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1790, 100, 20));

        jTextField77.setBackground(new java.awt.Color(153, 255, 255));
        jTextField77.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField77, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1790, 170, -1));

        Start19.setBackground(new java.awt.Color(0, 255, 255));
        Start19.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start19.setForeground(new java.awt.Color(0, 0, 102));
        Start19.setText("Comenzar");
        Start19.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start19MouseClicked(evt);
            }
        });
        Start19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start19ActionPerformed(evt);
            }
        });
        jPanel1.add(Start19, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1850, 100, -1));

        Pause19.setBackground(new java.awt.Color(204, 0, 0));
        Pause19.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause19.setForeground(new java.awt.Color(255, 255, 0));
        Pause19.setText("Pausar");
        Pause19.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause19MouseClicked(evt);
            }
        });
        jPanel1.add(Pause19, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1850, 100, -1));

        Stop19.setBackground(new java.awt.Color(255, 255, 51));
        Stop19.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop19.setText("Finalizado y desocupado");
        Stop19.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop19MouseClicked(evt);
            }
        });
        jPanel1.add(Stop19, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1870, 270, 30));

        jLabel254.setBackground(new java.awt.Color(0, 255, 255));
        jLabel254.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel254.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel254.setOpaque(true);
        jPanel1.add(jLabel254, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1820, -1, 20));
        jPanel1.add(jTextField78, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 1820, 70, 20));

        jLabel255.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel255.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel255, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 1730, 440, 180));

        jLabel256.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel256, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1750, 140, 110));

        jLabel257.setBackground(new java.awt.Color(0, 0, 0));
        jLabel257.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel257.setForeground(new java.awt.Color(0, 255, 0));
        jLabel257.setText("00 : 00 : 00 : 00");
        jLabel257.setOpaque(true);
        jPanel1.add(jLabel257, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1760, 150, -1));

        jLabel258.setBackground(new java.awt.Color(0, 0, 153));
        jLabel258.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel258.setForeground(new java.awt.Color(51, 255, 0));
        jLabel258.setText("H       :Min      :Seg    :CS");
        jLabel258.setOpaque(true);
        jPanel1.add(jLabel258, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1740, 150, 20));

        jLabel259.setBackground(new java.awt.Color(255, 0, 153));
        jLabel259.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel259.setForeground(new java.awt.Color(255, 255, 255));
        jLabel259.setText("Nom.de Usuario ;");
        jLabel259.setOpaque(true);
        jPanel1.add(jLabel259, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1790, 100, 20));

        jTextField79.setBackground(new java.awt.Color(153, 255, 255));
        jTextField79.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField79, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1790, 170, -1));

        jButton118.setBackground(new java.awt.Color(0, 255, 255));
        jButton118.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton118.setForeground(new java.awt.Color(0, 0, 102));
        jButton118.setText("Comenzar");
        jButton118.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton118.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton118ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton118, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1850, 100, -1));

        jButton119.setBackground(new java.awt.Color(204, 0, 0));
        jButton119.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton119.setForeground(new java.awt.Color(255, 255, 0));
        jButton119.setText("Pausar");
        jButton119.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton119, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1850, 100, -1));

        jButton120.setBackground(new java.awt.Color(255, 255, 51));
        jButton120.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton120.setText("Finalizado y desocupado");
        jButton120.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton120, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1870, 270, 30));

        jLabel260.setBackground(new java.awt.Color(0, 255, 255));
        jLabel260.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel260.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel260.setOpaque(true);
        jPanel1.add(jLabel260, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1820, 200, 20));
        jPanel1.add(jTextField80, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 1820, 70, 20));

        jLabel261.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel261.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel261, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 1730, 440, 180));

        jLabel262.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel262.setText("Equipo 20");
        jPanel1.add(jLabel262, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 1940, 100, 80));

        jLabel263.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel263, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1940, 140, 110));

        Reloj20.setBackground(new java.awt.Color(0, 0, 0));
        Reloj20.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj20.setForeground(new java.awt.Color(0, 255, 0));
        Reloj20.setText("00 : 00 : 00 : 00");
        Reloj20.setOpaque(true);
        jPanel1.add(Reloj20, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1950, 150, -1));

        jLabel265.setBackground(new java.awt.Color(0, 0, 153));
        jLabel265.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel265.setForeground(new java.awt.Color(51, 255, 0));
        jLabel265.setText("H       :Min      :Seg    :CS");
        jLabel265.setOpaque(true);
        jPanel1.add(jLabel265, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1930, 150, 20));

        jLabel266.setBackground(new java.awt.Color(255, 0, 153));
        jLabel266.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel266.setForeground(new java.awt.Color(255, 255, 255));
        jLabel266.setText("Nom.de Usuario ;");
        jLabel266.setOpaque(true);
        jPanel1.add(jLabel266, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1980, 100, 20));

        jTextField81.setBackground(new java.awt.Color(153, 255, 255));
        jTextField81.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField81, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1980, 170, -1));

        Start20.setBackground(new java.awt.Color(0, 255, 255));
        Start20.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start20.setForeground(new java.awt.Color(0, 0, 102));
        Start20.setText("Comenzar");
        Start20.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start20MouseClicked(evt);
            }
        });
        Start20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start20ActionPerformed(evt);
            }
        });
        jPanel1.add(Start20, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 2040, 100, -1));

        Pause20.setBackground(new java.awt.Color(204, 0, 0));
        Pause20.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause20.setForeground(new java.awt.Color(255, 255, 0));
        Pause20.setText("Pausar");
        Pause20.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause20MouseClicked(evt);
            }
        });
        jPanel1.add(Pause20, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 2040, 100, -1));

        Stop20.setBackground(new java.awt.Color(255, 255, 51));
        Stop20.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop20.setText("Finalizado y desocupado");
        Stop20.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop20MouseClicked(evt);
            }
        });
        jPanel1.add(Stop20, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 2060, 270, 30));

        jLabel267.setBackground(new java.awt.Color(0, 255, 255));
        jLabel267.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel267.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel267.setOpaque(true);
        jPanel1.add(jLabel267, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 2010, -1, 20));
        jPanel1.add(jTextField82, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 2010, 70, 20));

        jLabel268.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel268.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel268, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 1920, 440, 180));

        jLabel269.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel269, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1940, 140, 110));

        jLabel270.setBackground(new java.awt.Color(0, 0, 0));
        jLabel270.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel270.setForeground(new java.awt.Color(0, 255, 0));
        jLabel270.setText("00 : 00 : 00 : 00");
        jLabel270.setOpaque(true);
        jPanel1.add(jLabel270, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1950, 150, -1));

        jLabel271.setBackground(new java.awt.Color(0, 0, 153));
        jLabel271.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel271.setForeground(new java.awt.Color(51, 255, 0));
        jLabel271.setText("H       :Min      :Seg    :CS");
        jLabel271.setOpaque(true);
        jPanel1.add(jLabel271, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1930, 150, 20));

        jLabel272.setBackground(new java.awt.Color(255, 0, 153));
        jLabel272.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel272.setForeground(new java.awt.Color(255, 255, 255));
        jLabel272.setText("Nom.de Usuario ;");
        jLabel272.setOpaque(true);
        jPanel1.add(jLabel272, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 1980, 100, 20));

        jTextField83.setBackground(new java.awt.Color(153, 255, 255));
        jTextField83.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField83, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1980, 170, -1));

        jButton124.setBackground(new java.awt.Color(0, 255, 255));
        jButton124.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton124.setForeground(new java.awt.Color(0, 0, 102));
        jButton124.setText("Comenzar");
        jButton124.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton124.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton124ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton124, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 2040, 100, -1));

        jButton125.setBackground(new java.awt.Color(204, 0, 0));
        jButton125.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton125.setForeground(new java.awt.Color(255, 255, 0));
        jButton125.setText("Pausar");
        jButton125.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton125, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 2040, 100, -1));

        jButton126.setBackground(new java.awt.Color(255, 255, 51));
        jButton126.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton126.setText("Finalizado y desocupado");
        jButton126.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton126, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 2060, 270, 30));

        jLabel273.setBackground(new java.awt.Color(0, 255, 255));
        jLabel273.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel273.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel273.setOpaque(true);
        jPanel1.add(jLabel273, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 2010, 200, 20));
        jPanel1.add(jTextField84, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 2010, 70, 20));

        jLabel274.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel274.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel274, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 1920, 440, 180));

        jLabel275.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel275.setText("Equipo 21");
        jPanel1.add(jLabel275, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 230, 100, 80));

        jLabel276.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel276, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 230, 140, 110));

        Reloj21.setBackground(new java.awt.Color(0, 0, 0));
        Reloj21.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj21.setForeground(new java.awt.Color(0, 255, 0));
        Reloj21.setText("00 : 00 : 00 : 00");
        Reloj21.setOpaque(true);
        jPanel1.add(Reloj21, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 240, 150, -1));

        jLabel278.setBackground(new java.awt.Color(0, 0, 153));
        jLabel278.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel278.setForeground(new java.awt.Color(51, 255, 0));
        jLabel278.setText("H       :Min      :Seg    :CS");
        jLabel278.setOpaque(true);
        jPanel1.add(jLabel278, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 220, 150, 20));

        jLabel279.setBackground(new java.awt.Color(255, 0, 153));
        jLabel279.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel279.setForeground(new java.awt.Color(255, 255, 255));
        jLabel279.setText("Nom.de Usuario ;");
        jLabel279.setOpaque(true);
        jPanel1.add(jLabel279, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 270, 100, 20));

        jTextField85.setBackground(new java.awt.Color(153, 255, 255));
        jTextField85.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField85, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 270, 170, -1));

        Start21.setBackground(new java.awt.Color(0, 255, 255));
        Start21.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start21.setForeground(new java.awt.Color(0, 0, 102));
        Start21.setText("Comenzar");
        Start21.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start21MouseClicked(evt);
            }
        });
        Start21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start21ActionPerformed(evt);
            }
        });
        jPanel1.add(Start21, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 330, 100, -1));

        Pause21.setBackground(new java.awt.Color(204, 0, 0));
        Pause21.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause21.setForeground(new java.awt.Color(255, 255, 0));
        Pause21.setText("Pausar");
        Pause21.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause21MouseClicked(evt);
            }
        });
        jPanel1.add(Pause21, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 330, 100, -1));

        Stop21.setBackground(new java.awt.Color(255, 255, 51));
        Stop21.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop21.setText("Finalizado y desocupado");
        Stop21.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop21MouseClicked(evt);
            }
        });
        jPanel1.add(Stop21, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 350, 270, 30));

        jLabel280.setBackground(new java.awt.Color(0, 255, 255));
        jLabel280.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel280.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel280.setOpaque(true);
        jPanel1.add(jLabel280, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 300, 200, 20));
        jPanel1.add(jTextField86, new org.netbeans.lib.awtextra.AbsoluteConstraints(1380, 300, 70, 20));

        jLabel281.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel281.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel281, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 210, 440, 180));

        jLabel282.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel282, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 230, 140, 110));

        jLabel283.setBackground(new java.awt.Color(0, 0, 0));
        jLabel283.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel283.setForeground(new java.awt.Color(0, 255, 0));
        jLabel283.setText("00 : 00 : 00 : 00");
        jLabel283.setOpaque(true);
        jPanel1.add(jLabel283, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 240, 150, -1));

        jLabel284.setBackground(new java.awt.Color(0, 0, 153));
        jLabel284.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel284.setForeground(new java.awt.Color(51, 255, 0));
        jLabel284.setText("H       :Min      :Seg    :CS");
        jLabel284.setOpaque(true);
        jPanel1.add(jLabel284, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 220, 150, 20));

        jLabel285.setBackground(new java.awt.Color(255, 0, 153));
        jLabel285.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel285.setForeground(new java.awt.Color(255, 255, 255));
        jLabel285.setText("Nom.de Usuario ;");
        jLabel285.setOpaque(true);
        jPanel1.add(jLabel285, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 270, 100, 20));

        jTextField87.setBackground(new java.awt.Color(153, 255, 255));
        jTextField87.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField87, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 270, 170, -1));

        jButton130.setBackground(new java.awt.Color(0, 255, 255));
        jButton130.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton130.setForeground(new java.awt.Color(0, 0, 102));
        jButton130.setText("Comenzar");
        jButton130.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton130.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton130ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton130, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 330, 100, -1));

        jButton131.setBackground(new java.awt.Color(204, 0, 0));
        jButton131.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton131.setForeground(new java.awt.Color(255, 255, 0));
        jButton131.setText("Pausar");
        jButton131.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton131, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 330, 100, -1));

        jButton132.setBackground(new java.awt.Color(255, 255, 51));
        jButton132.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton132.setText("Finalizado y desocupado");
        jButton132.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton132, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 350, 270, 30));

        jLabel286.setBackground(new java.awt.Color(0, 255, 255));
        jLabel286.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel286.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel286.setOpaque(true);
        jPanel1.add(jLabel286, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 300, 200, 20));
        jPanel1.add(jTextField88, new org.netbeans.lib.awtextra.AbsoluteConstraints(1330, 300, 70, 20));

        jLabel287.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel287.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel287, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 210, 440, 180));

        jLabel288.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel288.setText("Equipo 22");
        jPanel1.add(jLabel288, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 420, 100, 80));

        jLabel289.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel289, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 420, 140, 110));

        Reloj22.setBackground(new java.awt.Color(0, 0, 0));
        Reloj22.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj22.setForeground(new java.awt.Color(0, 255, 0));
        Reloj22.setText("00 : 00 : 00 : 00");
        Reloj22.setOpaque(true);
        jPanel1.add(Reloj22, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 430, 150, -1));

        jLabel291.setBackground(new java.awt.Color(0, 0, 153));
        jLabel291.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel291.setForeground(new java.awt.Color(51, 255, 0));
        jLabel291.setText("H       :Min      :Seg    :CS");
        jLabel291.setOpaque(true);
        jPanel1.add(jLabel291, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 410, 150, 20));

        jLabel292.setBackground(new java.awt.Color(255, 0, 153));
        jLabel292.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel292.setForeground(new java.awt.Color(255, 255, 255));
        jLabel292.setText("Nom.de Usuario ;");
        jLabel292.setOpaque(true);
        jPanel1.add(jLabel292, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 460, 100, 20));

        jTextField89.setBackground(new java.awt.Color(153, 255, 255));
        jTextField89.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField89, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 460, 170, -1));

        Start22.setBackground(new java.awt.Color(0, 255, 255));
        Start22.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start22.setForeground(new java.awt.Color(0, 0, 102));
        Start22.setText("Comenzar");
        Start22.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start22MouseClicked(evt);
            }
        });
        Start22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start22ActionPerformed(evt);
            }
        });
        jPanel1.add(Start22, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 520, 100, -1));

        Pause22.setBackground(new java.awt.Color(204, 0, 0));
        Pause22.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause22.setForeground(new java.awt.Color(255, 255, 0));
        Pause22.setText("Pausar");
        Pause22.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause22MouseClicked(evt);
            }
        });
        jPanel1.add(Pause22, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 520, 100, -1));

        Stop22.setBackground(new java.awt.Color(255, 255, 51));
        Stop22.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop22.setText("Finalizado y desocupado");
        Stop22.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop22MouseClicked(evt);
            }
        });
        jPanel1.add(Stop22, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 540, 270, 30));

        jLabel293.setBackground(new java.awt.Color(0, 255, 255));
        jLabel293.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel293.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel293.setOpaque(true);
        jPanel1.add(jLabel293, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 490, 200, 20));
        jPanel1.add(jTextField90, new org.netbeans.lib.awtextra.AbsoluteConstraints(1380, 490, 70, 20));

        jLabel294.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel294.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel294, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 400, 440, 180));

        jLabel295.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel295, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 420, 140, 110));

        jLabel296.setBackground(new java.awt.Color(0, 0, 0));
        jLabel296.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel296.setForeground(new java.awt.Color(0, 255, 0));
        jLabel296.setText("00 : 00 : 00 : 00");
        jLabel296.setOpaque(true);
        jPanel1.add(jLabel296, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 430, 150, -1));

        jLabel297.setBackground(new java.awt.Color(0, 0, 153));
        jLabel297.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel297.setForeground(new java.awt.Color(51, 255, 0));
        jLabel297.setText("H       :Min      :Seg    :CS");
        jLabel297.setOpaque(true);
        jPanel1.add(jLabel297, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 410, 150, 20));

        jLabel298.setBackground(new java.awt.Color(255, 0, 153));
        jLabel298.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel298.setForeground(new java.awt.Color(255, 255, 255));
        jLabel298.setText("Nom.de Usuario ;");
        jLabel298.setOpaque(true);
        jPanel1.add(jLabel298, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 460, 100, 20));

        jTextField91.setBackground(new java.awt.Color(153, 255, 255));
        jTextField91.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField91, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 460, 170, -1));

        jButton136.setBackground(new java.awt.Color(0, 255, 255));
        jButton136.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton136.setForeground(new java.awt.Color(0, 0, 102));
        jButton136.setText("Comenzar");
        jButton136.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton136.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton136ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton136, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 520, 100, -1));

        jButton137.setBackground(new java.awt.Color(204, 0, 0));
        jButton137.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton137.setForeground(new java.awt.Color(255, 255, 0));
        jButton137.setText("Pausar");
        jButton137.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton137, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 520, 100, -1));

        jButton138.setBackground(new java.awt.Color(255, 255, 51));
        jButton138.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton138.setText("Finalizado y desocupado");
        jButton138.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton138, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 540, 270, 30));

        jLabel299.setBackground(new java.awt.Color(0, 255, 255));
        jLabel299.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel299.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel299.setOpaque(true);
        jPanel1.add(jLabel299, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 490, 200, 20));
        jPanel1.add(jTextField92, new org.netbeans.lib.awtextra.AbsoluteConstraints(1330, 490, 70, 20));

        jLabel300.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel300.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel300, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 400, 440, 180));

        jLabel301.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel301.setText("Equipo 23");
        jPanel1.add(jLabel301, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 610, 100, 80));

        jLabel302.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel302, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 610, 140, 110));

        Reloj23.setBackground(new java.awt.Color(0, 0, 0));
        Reloj23.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj23.setForeground(new java.awt.Color(0, 255, 0));
        Reloj23.setText("00 : 00 : 00 : 00");
        Reloj23.setOpaque(true);
        jPanel1.add(Reloj23, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 620, 150, -1));

        jLabel304.setBackground(new java.awt.Color(0, 0, 153));
        jLabel304.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel304.setForeground(new java.awt.Color(51, 255, 0));
        jLabel304.setText("H       :Min      :Seg    :CS");
        jLabel304.setOpaque(true);
        jPanel1.add(jLabel304, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 600, 150, 20));

        jLabel305.setBackground(new java.awt.Color(255, 0, 153));
        jLabel305.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel305.setForeground(new java.awt.Color(255, 255, 255));
        jLabel305.setText("Nom.de Usuario ;");
        jLabel305.setOpaque(true);
        jPanel1.add(jLabel305, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 650, 100, 20));

        jTextField93.setBackground(new java.awt.Color(153, 255, 255));
        jTextField93.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField93, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 650, 170, -1));

        Start23.setBackground(new java.awt.Color(0, 255, 255));
        Start23.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start23.setForeground(new java.awt.Color(0, 0, 102));
        Start23.setText("Comenzar");
        Start23.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start23MouseClicked(evt);
            }
        });
        Start23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start23ActionPerformed(evt);
            }
        });
        jPanel1.add(Start23, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 710, 100, -1));

        Pause23.setBackground(new java.awt.Color(204, 0, 0));
        Pause23.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause23.setForeground(new java.awt.Color(255, 255, 0));
        Pause23.setText("Pausar");
        Pause23.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause23MouseClicked(evt);
            }
        });
        jPanel1.add(Pause23, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 710, 100, -1));

        Stop23.setBackground(new java.awt.Color(255, 255, 51));
        Stop23.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop23.setText("Finalizado y desocupado");
        Stop23.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop23MouseClicked(evt);
            }
        });
        jPanel1.add(Stop23, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 730, 270, 30));

        jLabel306.setBackground(new java.awt.Color(0, 255, 255));
        jLabel306.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel306.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel306.setOpaque(true);
        jPanel1.add(jLabel306, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 680, 200, 20));
        jPanel1.add(jTextField94, new org.netbeans.lib.awtextra.AbsoluteConstraints(1380, 680, 70, 20));

        jLabel307.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel307.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel307, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 590, 440, 180));

        jLabel308.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel308, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 610, 140, 110));

        jLabel309.setBackground(new java.awt.Color(0, 0, 0));
        jLabel309.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel309.setForeground(new java.awt.Color(0, 255, 0));
        jLabel309.setText("00 : 00 : 00 : 00");
        jLabel309.setOpaque(true);
        jPanel1.add(jLabel309, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 620, 150, -1));

        jLabel310.setBackground(new java.awt.Color(0, 0, 153));
        jLabel310.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel310.setForeground(new java.awt.Color(51, 255, 0));
        jLabel310.setText("H       :Min      :Seg    :CS");
        jLabel310.setOpaque(true);
        jPanel1.add(jLabel310, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 600, 150, 20));

        jLabel311.setBackground(new java.awt.Color(255, 0, 153));
        jLabel311.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel311.setForeground(new java.awt.Color(255, 255, 255));
        jLabel311.setText("Nom.de Usuario ;");
        jLabel311.setOpaque(true);
        jPanel1.add(jLabel311, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 650, 100, 20));

        jTextField95.setBackground(new java.awt.Color(153, 255, 255));
        jTextField95.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField95, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 650, 170, -1));

        jButton142.setBackground(new java.awt.Color(0, 255, 255));
        jButton142.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton142.setForeground(new java.awt.Color(0, 0, 102));
        jButton142.setText("Comenzar");
        jButton142.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton142.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton142ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton142, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 710, 100, -1));

        jButton143.setBackground(new java.awt.Color(204, 0, 0));
        jButton143.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton143.setForeground(new java.awt.Color(255, 255, 0));
        jButton143.setText("Pausar");
        jButton143.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton143, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 710, 100, -1));

        jButton144.setBackground(new java.awt.Color(255, 255, 51));
        jButton144.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton144.setText("Finalizado y desocupado");
        jButton144.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton144, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 730, 270, 30));

        jLabel312.setBackground(new java.awt.Color(0, 255, 255));
        jLabel312.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel312.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel312.setOpaque(true);
        jPanel1.add(jLabel312, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 680, 200, 20));
        jPanel1.add(jTextField96, new org.netbeans.lib.awtextra.AbsoluteConstraints(1330, 680, 70, 20));

        jLabel313.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel313.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel313, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 590, 440, 180));

        jLabel314.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jLabel314.setText("Equipo 24");
        jPanel1.add(jLabel314, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 800, 100, 80));

        jLabel315.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel315, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 800, 140, 110));

        Reloj24.setBackground(new java.awt.Color(0, 0, 0));
        Reloj24.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Reloj24.setForeground(new java.awt.Color(0, 255, 0));
        Reloj24.setText("00 : 00 : 00 : 00");
        Reloj24.setOpaque(true);
        jPanel1.add(Reloj24, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 810, 150, -1));

        jLabel317.setBackground(new java.awt.Color(0, 0, 153));
        jLabel317.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel317.setForeground(new java.awt.Color(51, 255, 0));
        jLabel317.setText("H       :Min      :Seg    :CS");
        jLabel317.setOpaque(true);
        jPanel1.add(jLabel317, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 790, 150, 20));

        jLabel318.setBackground(new java.awt.Color(255, 0, 153));
        jLabel318.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel318.setForeground(new java.awt.Color(255, 255, 255));
        jLabel318.setText("Nom.de Usuario ;");
        jLabel318.setOpaque(true);
        jPanel1.add(jLabel318, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 840, 100, 20));

        jTextField97.setBackground(new java.awt.Color(153, 255, 255));
        jTextField97.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField97, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 840, 170, -1));

        Start24.setBackground(new java.awt.Color(0, 255, 255));
        Start24.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Start24.setForeground(new java.awt.Color(0, 0, 102));
        Start24.setText("Comenzar");
        Start24.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Start24MouseClicked(evt);
            }
        });
        Start24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Start24ActionPerformed(evt);
            }
        });
        jPanel1.add(Start24, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 900, 100, -1));

        Pause24.setBackground(new java.awt.Color(204, 0, 0));
        Pause24.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Pause24.setForeground(new java.awt.Color(255, 255, 0));
        Pause24.setText("Pausar");
        Pause24.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Pause24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Pause24MouseClicked(evt);
            }
        });
        jPanel1.add(Pause24, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 900, 100, -1));

        Stop24.setBackground(new java.awt.Color(255, 255, 51));
        Stop24.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        Stop24.setText("Finalizado y desocupado");
        Stop24.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Stop24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Stop24MouseClicked(evt);
            }
        });
        jPanel1.add(Stop24, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 920, 270, 30));

        jLabel319.setBackground(new java.awt.Color(0, 255, 255));
        jLabel319.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel319.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel319.setOpaque(true);
        jPanel1.add(jLabel319, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 870, 200, 20));
        jPanel1.add(jTextField98, new org.netbeans.lib.awtextra.AbsoluteConstraints(1380, 870, 70, 20));

        jLabel320.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel320.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel320, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 780, 440, 180));

        jLabel321.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/monitor-2455524__340.png"))); // NOI18N
        jPanel1.add(jLabel321, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 800, 140, 110));

        jLabel322.setBackground(new java.awt.Color(0, 0, 0));
        jLabel322.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        jLabel322.setForeground(new java.awt.Color(0, 255, 0));
        jLabel322.setText("00 : 00 : 00 : 00");
        jLabel322.setOpaque(true);
        jPanel1.add(jLabel322, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 810, 150, -1));

        jLabel323.setBackground(new java.awt.Color(0, 0, 153));
        jLabel323.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel323.setForeground(new java.awt.Color(51, 255, 0));
        jLabel323.setText("H       :Min      :Seg    :CS");
        jLabel323.setOpaque(true);
        jPanel1.add(jLabel323, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 790, 150, 20));

        jLabel324.setBackground(new java.awt.Color(255, 0, 153));
        jLabel324.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel324.setForeground(new java.awt.Color(255, 255, 255));
        jLabel324.setText("Nom.de Usuario ;");
        jLabel324.setOpaque(true);
        jPanel1.add(jLabel324, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 840, 100, 20));

        jTextField99.setBackground(new java.awt.Color(153, 255, 255));
        jTextField99.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField99, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 840, 170, -1));

        jButton148.setBackground(new java.awt.Color(0, 255, 255));
        jButton148.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton148.setForeground(new java.awt.Color(0, 0, 102));
        jButton148.setText("Comenzar");
        jButton148.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton148.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton148ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton148, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 900, 100, -1));

        jButton149.setBackground(new java.awt.Color(204, 0, 0));
        jButton149.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton149.setForeground(new java.awt.Color(255, 255, 0));
        jButton149.setText("Pausar");
        jButton149.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton149, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 900, 100, -1));

        jButton150.setBackground(new java.awt.Color(255, 255, 51));
        jButton150.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton150.setText("Finalizado y desocupado");
        jButton150.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton150, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 920, 270, 30));

        jLabel325.setBackground(new java.awt.Color(0, 255, 255));
        jLabel325.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel325.setText("Grado,Grupo,Turno y Especialidad; ");
        jLabel325.setOpaque(true);
        jPanel1.add(jLabel325, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 870, 200, 20));
        jPanel1.add(jTextField100, new org.netbeans.lib.awtextra.AbsoluteConstraints(1330, 870, 70, 20));

        jLabel326.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto/Imagenes/depositphotos_96987410-stock-illustration-realistic-work-desk-organization-top.jpg"))); // NOI18N
        jLabel326.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 51, 0), new java.awt.Color(153, 51, 0), new java.awt.Color(204, 51, 0), new java.awt.Color(204, 51, 0)));
        jPanel1.add(jLabel326, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 780, 440, 180));

        jTextField173.setBackground(new java.awt.Color(153, 255, 255));
        jTextField173.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField173, new org.netbeans.lib.awtextra.AbsoluteConstraints(2280, 650, 170, -1));

        jButton260.setBackground(new java.awt.Color(204, 0, 0));
        jButton260.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton260.setForeground(new java.awt.Color(255, 255, 0));
        jButton260.setText("Pausar");
        jButton260.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton260, new org.netbeans.lib.awtextra.AbsoluteConstraints(2280, 710, 100, -1));
        jPanel1.add(jTextField174, new org.netbeans.lib.awtextra.AbsoluteConstraints(2380, 680, 70, 20));

        jTextField175.setBackground(new java.awt.Color(153, 255, 255));
        jTextField175.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jPanel1.add(jTextField175, new org.netbeans.lib.awtextra.AbsoluteConstraints(2280, 650, 170, -1));

        jButton263.setBackground(new java.awt.Color(204, 0, 0));
        jButton263.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jButton263.setForeground(new java.awt.Color(255, 255, 0));
        jButton263.setText("Pausar");
        jButton263.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jButton263, new org.netbeans.lib.awtextra.AbsoluteConstraints(2280, 710, 100, -1));
        jPanel1.add(jTextField176, new org.netbeans.lib.awtextra.AbsoluteConstraints(2330, 680, 70, 20));

        jButton265.setBackground(new java.awt.Color(102, 255, 204));
        jButton265.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jButton265.setText("Estados de los Equipos ");
        jButton265.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(51, 255, 51), new java.awt.Color(0, 255, 102), new java.awt.Color(51, 255, 204), new java.awt.Color(0, 153, 153)));
        jPanel1.add(jButton265, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, 230, 50));

        jLabel2.setBackground(new java.awt.Color(153, 255, 255));
        jLabel2.setFont(new java.awt.Font("Arial", 3, 36)); // NOI18N
        jLabel2.setText("Laboratorio de Computo 1");
        jLabel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 255), 4, true));
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 40, 490, 90));

        jButton2.setBackground(new java.awt.Color(255, 102, 255));
        jButton2.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jButton2.setText("Salir");
        jButton2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 102, 204), new java.awt.Color(255, 153, 204), new java.awt.Color(204, 0, 204), new java.awt.Color(255, 0, 255)));
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(2120, 20, 120, 70));

        jButton1.setBackground(new java.awt.Color(0, 204, 255));
        jButton1.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        jButton1.setText("Datos Obtenidos");
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(51, 255, 255), new java.awt.Color(102, 255, 255), new java.awt.Color(0, 204, 204), new java.awt.Color(0, 255, 255)));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(258, 258, 258)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(1022, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(711, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1470, 790));

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1465, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 2202, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton148ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton148ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton148ActionPerformed

    private void Start24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start24ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start24ActionPerformed

    private void jButton142ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton142ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton142ActionPerformed

    private void Start23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start23ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start23ActionPerformed

    private void jButton136ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton136ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton136ActionPerformed

    private void Start22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start22ActionPerformed

    private void jButton130ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton130ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton130ActionPerformed

    private void Start21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start21ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start21ActionPerformed

    private void jButton124ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton124ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton124ActionPerformed

    private void Start20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start20ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start20ActionPerformed

    private void jButton118ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton118ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton118ActionPerformed

    private void Start19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start19ActionPerformed

    private void jButton112ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton112ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton112ActionPerformed

    private void Start18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start18ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start18ActionPerformed

    private void jButton106ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton106ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton106ActionPerformed

    private void Start17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start17ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start17ActionPerformed

    private void jButton100ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton100ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton100ActionPerformed

    private void Start16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start16ActionPerformed

    private void jButton94ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton94ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton94ActionPerformed

    private void Start15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start15ActionPerformed

    private void jButton88ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton88ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton88ActionPerformed

    private void Start14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start14ActionPerformed

    private void jButton82ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton82ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton82ActionPerformed

    private void Start13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start13ActionPerformed

    private void jButton76ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton76ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton76ActionPerformed

    private void Start12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start12ActionPerformed

    private void jButton70ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton70ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton70ActionPerformed

    private void Start11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start11ActionPerformed

    private void jButton64ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton64ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton64ActionPerformed

    private void Start10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start10ActionPerformed

    private void jButton58ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton58ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton58ActionPerformed

    private void Start9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start9ActionPerformed

    private void jButton52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton52ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton52ActionPerformed

    private void Start8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start8ActionPerformed

    private void jButton46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton46ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton46ActionPerformed

    private void Start7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start7ActionPerformed

    private void jButton40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton40ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton40ActionPerformed

    private void Start6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start6ActionPerformed

    private void jButton34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton34ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton34ActionPerformed

    private void Start5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start5ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton28ActionPerformed

    private void Start4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start4ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton22ActionPerformed

    private void Start3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start3ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton16ActionPerformed

    private void Start2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Start2ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed

    private void Start1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Start1ActionPerformed
       
    }//GEN-LAST:event_Start1ActionPerformed

    private void Start1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start1MouseClicked
        t.start();
        Start1.setEnabled(false);
        Start1.setText("Reanudar ");
        Pause1.setEnabled(true);
        Stop1.setEnabled(true);
    }//GEN-LAST:event_Start1MouseClicked

    private void Pause1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause1MouseClicked
         t.stop();
        Start1.setEnabled(true);
        Pause1.setEnabled(false);
    }//GEN-LAST:event_Pause1MouseClicked

    private void Stop1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop1MouseClicked
               if(t.isRunning()){
            t.stop();
            Start1.setEnabled(true);
        }
        Start1.setText("Iniciar");
        Pause1.setEnabled(false);
            Stop1.setEnabled(false);
            H[1]=0;m[1]=0;s[1]=0;cs[1]=0;
            Actualizar();
    }//GEN-LAST:event_Stop1MouseClicked

    private void Start2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start2MouseClicked
       t1.start();
        Start2.setEnabled(false);
        Start2.setText("Reanudar ");
        Pause2.setEnabled(true);
        Stop2.setEnabled(true);
    }//GEN-LAST:event_Start2MouseClicked

    private void Pause2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause2MouseClicked
        // TODO add your handling code here:
         t1.stop();
        Start2.setEnabled(true);
        Pause2.setEnabled(false);
    }//GEN-LAST:event_Pause2MouseClicked

    private void Stop2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop2MouseClicked
        // TODO add your handling code here:
        if(t1.isRunning()){
            t1.stop();
            Start2.setEnabled(true);
        }
        Start2.setText("Iniciar");
        Pause2.setEnabled(false);
            Stop2.setEnabled(false);
            H[2]=0;m[2]=0;s[2]=0;cs[2]=0;
            Actualizar2();
    }//GEN-LAST:event_Stop2MouseClicked

    private void Start3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start3MouseClicked
      t2.start();
        Start3.setEnabled(false);
        Start3.setText("Reanudar ");
        Pause3.setEnabled(true);
        Stop3.setEnabled(true);
    }//GEN-LAST:event_Start3MouseClicked

    private void Start4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start4MouseClicked
      t3.start();
        Start4.setEnabled(false);
        Start4.setText("Reanudar ");
        Pause4.setEnabled(true);
        Stop4.setEnabled(true);
    }//GEN-LAST:event_Start4MouseClicked

    private void Start5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start5MouseClicked
t4.start();
        Start5.setEnabled(false);
        Start5.setText("Reanudar ");
        Pause5.setEnabled(true);
        Stop5.setEnabled(true);        // TODO add your handling code here:
    }//GEN-LAST:event_Start5MouseClicked

    private void Start6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start6MouseClicked
        t5.start();
        Start6.setEnabled(false);
        Start6.setText("Reanudar ");
        Pause6.setEnabled(true);
        Stop6.setEnabled(true);
    }//GEN-LAST:event_Start6MouseClicked

    private void Start7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start7MouseClicked
       t6.start();
        Start7.setEnabled(false);
        Start7.setText("Reanudar ");
        Pause7.setEnabled(true);
        Stop7.setEnabled(true);
    }//GEN-LAST:event_Start7MouseClicked

    private void Start8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start8MouseClicked
      t7.start();
        Start8.setEnabled(false);
        Start8.setText("Reanudar ");
        Pause8.setEnabled(true);
        Stop8.setEnabled(true);
    }//GEN-LAST:event_Start8MouseClicked

    private void Start9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start9MouseClicked
        t8.start();
        Start9.setEnabled(false);
        Start9.setText("Reanudar ");
        Pause9.setEnabled(true);
        Stop9.setEnabled(true);
    }//GEN-LAST:event_Start9MouseClicked

    private void Start10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start10MouseClicked
      t9.start();
        Start10.setEnabled(false);
        Start10.setText("Reanudar ");
        Pause10.setEnabled(true);
        Stop10.setEnabled(true);
    }//GEN-LAST:event_Start10MouseClicked

    private void Start11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start11MouseClicked
        t10.start();
        Start11.setEnabled(false);
        Start11.setText("Reanudar ");
        Pause11.setEnabled(true);
        Stop11.setEnabled(true);
    }//GEN-LAST:event_Start11MouseClicked

    private void Start12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start12MouseClicked
        t11.start();
        Start12.setEnabled(false);
        Start12.setText("Reanudar ");
        Pause12.setEnabled(true);
        Stop12.setEnabled(true);
    }//GEN-LAST:event_Start12MouseClicked

    private void Start13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start13MouseClicked
        t12.start();
        Start13.setEnabled(false);
        Start13.setText("Reanudar ");
        Pause13.setEnabled(true);
        Stop13.setEnabled(true);
    }//GEN-LAST:event_Start13MouseClicked

    private void Start14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start14MouseClicked
        t13.start();
        Start14.setEnabled(false);
        Start14.setText("Reanudar ");
        Pause14.setEnabled(true);
        Stop14.setEnabled(true);
    }//GEN-LAST:event_Start14MouseClicked

    private void Start15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start15MouseClicked
       t14.start();
        Start15.setEnabled(false);
        Start15.setText("Reanudar ");
        Pause15.setEnabled(true);
        Stop15.setEnabled(true);
    }//GEN-LAST:event_Start15MouseClicked

    private void Start16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start16MouseClicked
        t15.start();
        Start16.setEnabled(false);
        Start16.setText("Reanudar ");
        Pause16.setEnabled(true);
        Stop16.setEnabled(true);
    }//GEN-LAST:event_Start16MouseClicked

    private void Start17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start17MouseClicked
        t16.start();
        Start17.setEnabled(false);
        Start17.setText("Reanudar ");
        Pause17.setEnabled(true);
        Stop17.setEnabled(true);
    }//GEN-LAST:event_Start17MouseClicked

    private void Start18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start18MouseClicked
       t17.start();
        Start18.setEnabled(false);
        Start18.setText("Reanudar ");
        Pause18.setEnabled(true);
        Stop18.setEnabled(true);
    }//GEN-LAST:event_Start18MouseClicked

    private void Start19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start19MouseClicked
        t18.start();
        Start19.setEnabled(false);
        Start19.setText("Reanudar ");
        Pause19.setEnabled(true);
        Stop19.setEnabled(true);
    }//GEN-LAST:event_Start19MouseClicked

    private void Start20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start20MouseClicked
        t19.start();
        Start20.setEnabled(false);
        Start20.setText("Reanudar ");
        Pause20.setEnabled(true);
        Stop20.setEnabled(true);
    }//GEN-LAST:event_Start20MouseClicked

    private void Start21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start21MouseClicked
        t20.start();
        Start21.setEnabled(false);
        Start21.setText("Reanudar ");
        Pause21.setEnabled(true);
        Stop21.setEnabled(true);
    }//GEN-LAST:event_Start21MouseClicked

    private void Start22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start22MouseClicked
        t21.start();
        Start22.setEnabled(false);
        Start22.setText("Reanudar ");
        Pause22.setEnabled(true);
        Stop22.setEnabled(true);
    }//GEN-LAST:event_Start22MouseClicked

    private void Start23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start23MouseClicked
       t22.start();
        Start23.setEnabled(false);
        Start23.setText("Reanudar ");
        Pause23.setEnabled(true);
        Stop23.setEnabled(true);
    }//GEN-LAST:event_Start23MouseClicked

    private void Start24MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Start24MouseClicked
       t23.start();
        Start24.setEnabled(false);
        Start24.setText("Reanudar ");
        Pause24.setEnabled(true);
        Stop24.setEnabled(true);
    }//GEN-LAST:event_Start24MouseClicked

    private void Pause3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause3MouseClicked
       t2.stop();
        Start3.setEnabled(true);
        Pause3.setEnabled(false);
    }//GEN-LAST:event_Pause3MouseClicked

    private void Pause4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause4MouseClicked
        t3.stop();
        Start4.setEnabled(true);
        Pause4.setEnabled(false);
    }//GEN-LAST:event_Pause4MouseClicked

    private void Pause5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause5MouseClicked
      t4.stop();
        Start5.setEnabled(true);
        Pause5.setEnabled(false);
    }//GEN-LAST:event_Pause5MouseClicked

    private void Pause6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause6MouseClicked
       t5.stop();
        Start6.setEnabled(true);
        Pause6.setEnabled(false);
    }//GEN-LAST:event_Pause6MouseClicked

    private void Pause7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause7MouseClicked
        t6.stop();
        Start7.setEnabled(true);
        Pause7.setEnabled(false);
    }//GEN-LAST:event_Pause7MouseClicked

    private void Pause8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause8MouseClicked
      t7.stop();
        Start8.setEnabled(true);
        Pause8.setEnabled(false);
    }//GEN-LAST:event_Pause8MouseClicked

    private void Pause9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause9MouseClicked
       t8.stop();
        Start9.setEnabled(true);
        Pause9.setEnabled(false);
    }//GEN-LAST:event_Pause9MouseClicked

    private void Pause10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause10MouseClicked
        t9.stop();
        Start10.setEnabled(true);
        Pause10.setEnabled(false);
    }//GEN-LAST:event_Pause10MouseClicked

    private void Pause11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause11MouseClicked
        t10.stop();
        Start11.setEnabled(true);
        Pause11.setEnabled(false);
    }//GEN-LAST:event_Pause11MouseClicked

    private void Pause12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause12MouseClicked
      t11.stop();
        Start12.setEnabled(true);
        Pause12.setEnabled(false);
    }//GEN-LAST:event_Pause12MouseClicked

    private void Pause13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause13MouseClicked
       t12.stop();
        Start13.setEnabled(true);
        Pause13.setEnabled(false);
    }//GEN-LAST:event_Pause13MouseClicked

    private void Pause14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause14MouseClicked
        t13.stop();
        Start14.setEnabled(true);
        Pause14.setEnabled(false);
    }//GEN-LAST:event_Pause14MouseClicked

    private void Pause15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause15MouseClicked
       t14.stop();
        Start15.setEnabled(true);
        Pause15.setEnabled(false);
    }//GEN-LAST:event_Pause15MouseClicked

    private void Pause16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause16MouseClicked
        t15.stop();
        Start16.setEnabled(true);
        Pause16.setEnabled(false);
    }//GEN-LAST:event_Pause16MouseClicked

    private void Pause17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause17MouseClicked
        t16.stop();
        Start17.setEnabled(true);
        Pause17.setEnabled(false);
    }//GEN-LAST:event_Pause17MouseClicked

    private void Pause18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause18MouseClicked
       t17.stop();
        Start18.setEnabled(true);
        Pause18.setEnabled(false);
    }//GEN-LAST:event_Pause18MouseClicked

    private void Pause19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause19MouseClicked
        t18.stop();
        Start19.setEnabled(true);
        Pause19.setEnabled(false);
    }//GEN-LAST:event_Pause19MouseClicked

    private void Pause20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause20MouseClicked
       t19.stop();
        Start20.setEnabled(true);
        Pause20.setEnabled(false);
    }//GEN-LAST:event_Pause20MouseClicked

    private void Pause21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause21MouseClicked
       t20.stop();
        Start21.setEnabled(true);
        Pause21.setEnabled(false);
    }//GEN-LAST:event_Pause21MouseClicked

    private void Pause22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause22MouseClicked
      t21.stop();
        Start22.setEnabled(true);
        Pause22.setEnabled(false);
    }//GEN-LAST:event_Pause22MouseClicked

    private void Pause23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause23MouseClicked
       t22.stop();
        Start23.setEnabled(true);
        Pause23.setEnabled(false);
    }//GEN-LAST:event_Pause23MouseClicked

    private void Pause24MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pause24MouseClicked
       t23.stop();
        Start24.setEnabled(true);
        Pause24.setEnabled(false);
    }//GEN-LAST:event_Pause24MouseClicked

    private void Stop3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop3MouseClicked
 if(t2.isRunning()){
            t2.stop();
            Start3.setEnabled(true);
        }
        Start3.setText("Iniciar");
        Pause3.setEnabled(false);
            Stop3.setEnabled(false);
            H[3]=0;m[3]=0;s[3]=0;cs[3]=0;
            Actualizar3();      
    }//GEN-LAST:event_Stop3MouseClicked

    private void Stop4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop4MouseClicked
         if(t3.isRunning()){
            t3.stop();
            Start4.setEnabled(true);
        }
        Start4.setText("Iniciar");
        Pause4.setEnabled(false);
            Stop4.setEnabled(false);
            H[4]=0;m[4]=0;s[4]=0;cs[4]=0;
            Actualizar4();
    }//GEN-LAST:event_Stop4MouseClicked

    private void Stop5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop5MouseClicked
        if(t4.isRunning()){
            t4.stop();
            Start5.setEnabled(true);
        }
        Start5.setText("Iniciar");
        Pause5.setEnabled(false);
            Stop5.setEnabled(false);
            H[5]=0;m[5]=0;s[5]=0;cs[5]=0;
            Actualizar5();
    }//GEN-LAST:event_Stop5MouseClicked

    private void Stop6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop6MouseClicked
        // TODO add your handling code here:
         if(t5.isRunning()){
            t5.stop();
            Start6.setEnabled(true);
        }
        Start6.setText("Iniciar");
        Pause6.setEnabled(false);
            Stop6.setEnabled(false);
            H[6]=0;m[6]=0;s[6]=0;cs[6]=0;
            Actualizar6();
    }//GEN-LAST:event_Stop6MouseClicked

    private void Stop7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop7MouseClicked
        // TODO add your handling code here:
         if(t6.isRunning()){
            t6.stop();
            Start7.setEnabled(true);
        }
        Start7.setText("Iniciar");
        Pause7.setEnabled(false);
            Stop7.setEnabled(false);
            H[7]=0;m[7]=0;s[7]=0;cs[7]=0;
            Actualizar7();
    }//GEN-LAST:event_Stop7MouseClicked

    private void Stop8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop8MouseClicked
        // TODO add your handling code here:
         if(t7.isRunning()){
            t7.stop();
            Start8.setEnabled(true);
        }
        Start8.setText("Iniciar");
        Pause8.setEnabled(false);
            Stop8.setEnabled(false);
            H[8]=0;m[8]=0;s[8]=0;cs[8]=0;
            Actualizar8();
    }//GEN-LAST:event_Stop8MouseClicked

    private void Stop9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop9MouseClicked
        // TODO add your handling code here:
         if(t8.isRunning()){
            t8.stop();
            Start9.setEnabled(true);
        }
        Start9.setText("Iniciar");
        Pause9.setEnabled(false);
            Stop9.setEnabled(false);
            H[9]=0;m[9]=0;s[9]=0;cs[9]=0;
            Actualizar9();
    }//GEN-LAST:event_Stop9MouseClicked

    private void Stop10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop10MouseClicked
        // TODO add your handling code here:
         if(t9.isRunning()){
            t9.stop();
            Start10.setEnabled(true);
        }
        Start10.setText("Iniciar");
        Pause10.setEnabled(false);
            Stop10.setEnabled(false);
            H[10]=0;m[10]=0;s[10]=0;cs[10]=0;
            Actualizar10();
    }//GEN-LAST:event_Stop10MouseClicked

    private void Stop11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop11MouseClicked
        // TODO add your handling code here:
         if(t10.isRunning()){
            t10.stop();
            Start11 .setEnabled(true);
        }
        Start11.setText("Iniciar");
        Pause11.setEnabled(false);
            Stop11.setEnabled(false);
            H[11]=0;m[11]=0;s[11]=0;cs[11]=0;
            Actualizar11();
    }//GEN-LAST:event_Stop11MouseClicked

    private void Stop12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop12MouseClicked
        // TODO add your handling code here:
         if(t11.isRunning()){
            t11.stop();
            Start12.setEnabled(true);
        }
        Start12.setText("Iniciar");
        Pause12.setEnabled(false);
            Stop12.setEnabled(false);
            H[12]=0;m[12]=0;s[12]=0;cs[12]=0;
            Actualizar12();
    }//GEN-LAST:event_Stop12MouseClicked

    private void Stop13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop13MouseClicked
        // TODO add your handling code here:
         if(t12.isRunning()){
            t12.stop();
            Start13.setEnabled(true);
        }
        Start13.setText("Iniciar");
        Pause13.setEnabled(false);
            Stop13.setEnabled(false);
            H[13]=0;m[13]=0;s[13]=0;cs[13]=0;
            Actualizar13();
    }//GEN-LAST:event_Stop13MouseClicked

    private void Stop14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop14MouseClicked
        // TODO add your handling code here:
         if(t13.isRunning()){
            t13.stop();
            Start14.setEnabled(true);
        }
        Start14.setText("Iniciar");
        Pause14.setEnabled(false);
            Stop14.setEnabled(false);
            H[14]=0;m[14]=0;s[14]=0;cs[14]=0;
            Actualizar14();
    }//GEN-LAST:event_Stop14MouseClicked

    private void Stop15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop15MouseClicked
        // TODO add your handling code here:
         if(t14.isRunning()){
            t14.stop();
            Start15.setEnabled(true);
        }
        Start15.setText("Iniciar");
        Pause15.setEnabled(false);
            Stop15.setEnabled(false);
            H[15]=0;m[15]=0;s[15]=0;cs[15]=0;
            Actualizar15();
    }//GEN-LAST:event_Stop15MouseClicked

    private void Stop16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop16MouseClicked
        // TODO add your handling code here:
         if(t15.isRunning()){
            t15.stop();
            Start16.setEnabled(true);
        }
        Start16.setText("Iniciar");
        Pause16.setEnabled(false);
            Stop16.setEnabled(false);
            H[16]=0;m[16]=0;s[16]=0;cs[16]=0;
            Actualizar16();
    }//GEN-LAST:event_Stop16MouseClicked

    private void Stop17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop17MouseClicked
        // TODO add your handling code here:
         if(t16.isRunning()){
            t16.stop();
            Start17.setEnabled(true);
        }
        Start17.setText("Iniciar");
        Pause17.setEnabled(false);
            Stop17.setEnabled(false);
            H[17]=0;m[17]=0;s[17]=0;cs[17]=0;
            Actualizar17();
    }//GEN-LAST:event_Stop17MouseClicked

    private void Stop18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop18MouseClicked
        // TODO add your handling code here:
         if(t17.isRunning()){
            t17.stop();
            Start18.setEnabled(true);
        }
        Start18.setText("Iniciar");
        Pause18.setEnabled(false);
            Stop18.setEnabled(false);
            H[18]=0;m[18]=0;s[18]=0;cs[18]=0;
            Actualizar18();
    }//GEN-LAST:event_Stop18MouseClicked

    private void Stop19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop19MouseClicked
        // TODO add your handling code here:
         if(t18.isRunning()){
            t18.stop();
            Start19.setEnabled(true);
        }
        Start19.setText("Iniciar");
        Pause19.setEnabled(false);
            Stop19.setEnabled(false);
            H[19]=0;m[19]=0;s[19]=0;cs[19]=0;
            Actualizar19();
    }//GEN-LAST:event_Stop19MouseClicked

    private void Stop20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop20MouseClicked
        // TODO add your handling code here:
         if(t19.isRunning()){
            t19.stop();
            Start20.setEnabled(true);
        }
        Start20.setText("Iniciar");
        Pause20.setEnabled(false);
            Stop20.setEnabled(false);
            H[20]=0;m[20]=0;s[20]=0;cs[20]=0;
            Actualizar20();
    }//GEN-LAST:event_Stop20MouseClicked

    private void Stop21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop21MouseClicked
        // TODO add your handling code here:
         if(t20.isRunning()){
            t20.stop();
            Start21.setEnabled(true);
        }
        Start21.setText("Iniciar");
        Pause21.setEnabled(false);
            Stop21.setEnabled(false);
            H[21]=0;m[21]=0;s[21]=0;cs[21]=0;
            Actualizar21();
    }//GEN-LAST:event_Stop21MouseClicked

    private void Stop22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop22MouseClicked
        // TODO add your handling code here:
         if(t21.isRunning()){
            t21.stop();
            Start22.setEnabled(true);
        }
        Start22.setText("Iniciar");
        Pause22.setEnabled(false);
            Stop22.setEnabled(false);
            H[22]=0;m[22]=0;s[22]=0;cs[22]=0;
            Actualizar22();
    }//GEN-LAST:event_Stop22MouseClicked

    private void Stop23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop23MouseClicked
        // TODO add your handling code here:
         if(t22.isRunning()){
            t22.stop();
            Start23.setEnabled(true);
        }
        Start23.setText("Iniciar");
        Pause23.setEnabled(false);
            Stop23.setEnabled(false);
            H[23]=0;m[23]=0;s[23]=0;cs[23]=0;
            Actualizar23();
    }//GEN-LAST:event_Stop23MouseClicked

    private void Stop24MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Stop24MouseClicked
        // TODO add your handling code here:
         if(t23.isRunning()){
            t23.stop();
            Start24.setEnabled(true);
        }
        Start24.setText("Iniciar");
        Pause24.setEnabled(false);
            Stop24.setEnabled(false);
            H[24]=0;m[24]=0;s[24]=0;cs[24]=0;
            Actualizar24();
    }//GEN-LAST:event_Stop24MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Laboratorio3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Laboratorio3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Laboratorio3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Laboratorio3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Laboratorio3().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Pause1;
    private javax.swing.JButton Pause10;
    private javax.swing.JButton Pause11;
    private javax.swing.JButton Pause12;
    private javax.swing.JButton Pause13;
    private javax.swing.JButton Pause14;
    private javax.swing.JButton Pause15;
    private javax.swing.JButton Pause16;
    private javax.swing.JButton Pause17;
    private javax.swing.JButton Pause18;
    private javax.swing.JButton Pause19;
    private javax.swing.JButton Pause2;
    private javax.swing.JButton Pause20;
    private javax.swing.JButton Pause21;
    private javax.swing.JButton Pause22;
    private javax.swing.JButton Pause23;
    private javax.swing.JButton Pause24;
    private javax.swing.JButton Pause3;
    private javax.swing.JButton Pause4;
    private javax.swing.JButton Pause5;
    private javax.swing.JButton Pause6;
    private javax.swing.JButton Pause7;
    private javax.swing.JButton Pause8;
    private javax.swing.JButton Pause9;
    private javax.swing.JLabel Reloj1;
    private javax.swing.JLabel Reloj10;
    private javax.swing.JLabel Reloj11;
    private javax.swing.JLabel Reloj12;
    private javax.swing.JLabel Reloj13;
    private javax.swing.JLabel Reloj14;
    private javax.swing.JLabel Reloj15;
    private javax.swing.JLabel Reloj16;
    private javax.swing.JLabel Reloj17;
    private javax.swing.JLabel Reloj18;
    private javax.swing.JLabel Reloj19;
    private javax.swing.JLabel Reloj2;
    private javax.swing.JLabel Reloj20;
    private javax.swing.JLabel Reloj21;
    private javax.swing.JLabel Reloj22;
    private javax.swing.JLabel Reloj23;
    private javax.swing.JLabel Reloj24;
    private javax.swing.JLabel Reloj3;
    private javax.swing.JLabel Reloj4;
    private javax.swing.JLabel Reloj5;
    private javax.swing.JLabel Reloj6;
    private javax.swing.JLabel Reloj7;
    private javax.swing.JLabel Reloj8;
    private javax.swing.JLabel Reloj9;
    private javax.swing.JButton Start1;
    private javax.swing.JButton Start10;
    private javax.swing.JButton Start11;
    private javax.swing.JButton Start12;
    private javax.swing.JButton Start13;
    private javax.swing.JButton Start14;
    private javax.swing.JButton Start15;
    private javax.swing.JButton Start16;
    private javax.swing.JButton Start17;
    private javax.swing.JButton Start18;
    private javax.swing.JButton Start19;
    private javax.swing.JButton Start2;
    private javax.swing.JButton Start20;
    private javax.swing.JButton Start21;
    private javax.swing.JButton Start22;
    private javax.swing.JButton Start23;
    private javax.swing.JButton Start24;
    private javax.swing.JButton Start3;
    private javax.swing.JButton Start4;
    private javax.swing.JButton Start5;
    private javax.swing.JButton Start6;
    private javax.swing.JButton Start7;
    private javax.swing.JButton Start8;
    private javax.swing.JButton Start9;
    private javax.swing.JButton Stop1;
    private javax.swing.JButton Stop10;
    private javax.swing.JButton Stop11;
    private javax.swing.JButton Stop12;
    private javax.swing.JButton Stop13;
    private javax.swing.JButton Stop14;
    private javax.swing.JButton Stop15;
    private javax.swing.JButton Stop16;
    private javax.swing.JButton Stop17;
    private javax.swing.JButton Stop18;
    private javax.swing.JButton Stop19;
    private javax.swing.JButton Stop2;
    private javax.swing.JButton Stop20;
    private javax.swing.JButton Stop21;
    private javax.swing.JButton Stop22;
    private javax.swing.JButton Stop23;
    private javax.swing.JButton Stop24;
    private javax.swing.JButton Stop3;
    private javax.swing.JButton Stop4;
    private javax.swing.JButton Stop5;
    private javax.swing.JButton Stop6;
    private javax.swing.JButton Stop7;
    private javax.swing.JButton Stop8;
    private javax.swing.JButton Stop9;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton100;
    private javax.swing.JButton jButton101;
    private javax.swing.JButton jButton102;
    private javax.swing.JButton jButton106;
    private javax.swing.JButton jButton107;
    private javax.swing.JButton jButton108;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton112;
    private javax.swing.JButton jButton113;
    private javax.swing.JButton jButton114;
    private javax.swing.JButton jButton118;
    private javax.swing.JButton jButton119;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton120;
    private javax.swing.JButton jButton124;
    private javax.swing.JButton jButton125;
    private javax.swing.JButton jButton126;
    private javax.swing.JButton jButton130;
    private javax.swing.JButton jButton131;
    private javax.swing.JButton jButton132;
    private javax.swing.JButton jButton136;
    private javax.swing.JButton jButton137;
    private javax.swing.JButton jButton138;
    private javax.swing.JButton jButton142;
    private javax.swing.JButton jButton143;
    private javax.swing.JButton jButton144;
    private javax.swing.JButton jButton148;
    private javax.swing.JButton jButton149;
    private javax.swing.JButton jButton150;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton260;
    private javax.swing.JButton jButton263;
    private javax.swing.JButton jButton265;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton40;
    private javax.swing.JButton jButton41;
    private javax.swing.JButton jButton42;
    private javax.swing.JButton jButton46;
    private javax.swing.JButton jButton47;
    private javax.swing.JButton jButton48;
    private javax.swing.JButton jButton52;
    private javax.swing.JButton jButton53;
    private javax.swing.JButton jButton54;
    private javax.swing.JButton jButton58;
    private javax.swing.JButton jButton59;
    private javax.swing.JButton jButton60;
    private javax.swing.JButton jButton64;
    private javax.swing.JButton jButton65;
    private javax.swing.JButton jButton66;
    private javax.swing.JButton jButton70;
    private javax.swing.JButton jButton71;
    private javax.swing.JButton jButton72;
    private javax.swing.JButton jButton76;
    private javax.swing.JButton jButton77;
    private javax.swing.JButton jButton78;
    private javax.swing.JButton jButton82;
    private javax.swing.JButton jButton83;
    private javax.swing.JButton jButton84;
    private javax.swing.JButton jButton88;
    private javax.swing.JButton jButton89;
    private javax.swing.JButton jButton90;
    private javax.swing.JButton jButton94;
    private javax.swing.JButton jButton95;
    private javax.swing.JButton jButton96;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel130;
    private javax.swing.JLabel jLabel131;
    private javax.swing.JLabel jLabel132;
    private javax.swing.JLabel jLabel133;
    private javax.swing.JLabel jLabel135;
    private javax.swing.JLabel jLabel136;
    private javax.swing.JLabel jLabel137;
    private javax.swing.JLabel jLabel138;
    private javax.swing.JLabel jLabel139;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel140;
    private javax.swing.JLabel jLabel141;
    private javax.swing.JLabel jLabel142;
    private javax.swing.JLabel jLabel143;
    private javax.swing.JLabel jLabel144;
    private javax.swing.JLabel jLabel145;
    private javax.swing.JLabel jLabel146;
    private javax.swing.JLabel jLabel148;
    private javax.swing.JLabel jLabel149;
    private javax.swing.JLabel jLabel150;
    private javax.swing.JLabel jLabel151;
    private javax.swing.JLabel jLabel152;
    private javax.swing.JLabel jLabel153;
    private javax.swing.JLabel jLabel154;
    private javax.swing.JLabel jLabel155;
    private javax.swing.JLabel jLabel156;
    private javax.swing.JLabel jLabel157;
    private javax.swing.JLabel jLabel158;
    private javax.swing.JLabel jLabel159;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel161;
    private javax.swing.JLabel jLabel162;
    private javax.swing.JLabel jLabel163;
    private javax.swing.JLabel jLabel164;
    private javax.swing.JLabel jLabel165;
    private javax.swing.JLabel jLabel166;
    private javax.swing.JLabel jLabel167;
    private javax.swing.JLabel jLabel168;
    private javax.swing.JLabel jLabel169;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel170;
    private javax.swing.JLabel jLabel171;
    private javax.swing.JLabel jLabel172;
    private javax.swing.JLabel jLabel174;
    private javax.swing.JLabel jLabel175;
    private javax.swing.JLabel jLabel176;
    private javax.swing.JLabel jLabel177;
    private javax.swing.JLabel jLabel178;
    private javax.swing.JLabel jLabel179;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel180;
    private javax.swing.JLabel jLabel181;
    private javax.swing.JLabel jLabel182;
    private javax.swing.JLabel jLabel183;
    private javax.swing.JLabel jLabel184;
    private javax.swing.JLabel jLabel185;
    private javax.swing.JLabel jLabel187;
    private javax.swing.JLabel jLabel188;
    private javax.swing.JLabel jLabel189;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel190;
    private javax.swing.JLabel jLabel191;
    private javax.swing.JLabel jLabel192;
    private javax.swing.JLabel jLabel193;
    private javax.swing.JLabel jLabel194;
    private javax.swing.JLabel jLabel195;
    private javax.swing.JLabel jLabel196;
    private javax.swing.JLabel jLabel197;
    private javax.swing.JLabel jLabel198;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel200;
    private javax.swing.JLabel jLabel201;
    private javax.swing.JLabel jLabel202;
    private javax.swing.JLabel jLabel203;
    private javax.swing.JLabel jLabel204;
    private javax.swing.JLabel jLabel205;
    private javax.swing.JLabel jLabel206;
    private javax.swing.JLabel jLabel207;
    private javax.swing.JLabel jLabel208;
    private javax.swing.JLabel jLabel209;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel210;
    private javax.swing.JLabel jLabel211;
    private javax.swing.JLabel jLabel213;
    private javax.swing.JLabel jLabel214;
    private javax.swing.JLabel jLabel215;
    private javax.swing.JLabel jLabel216;
    private javax.swing.JLabel jLabel217;
    private javax.swing.JLabel jLabel218;
    private javax.swing.JLabel jLabel219;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel220;
    private javax.swing.JLabel jLabel221;
    private javax.swing.JLabel jLabel222;
    private javax.swing.JLabel jLabel223;
    private javax.swing.JLabel jLabel224;
    private javax.swing.JLabel jLabel226;
    private javax.swing.JLabel jLabel227;
    private javax.swing.JLabel jLabel228;
    private javax.swing.JLabel jLabel229;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel230;
    private javax.swing.JLabel jLabel231;
    private javax.swing.JLabel jLabel232;
    private javax.swing.JLabel jLabel233;
    private javax.swing.JLabel jLabel234;
    private javax.swing.JLabel jLabel235;
    private javax.swing.JLabel jLabel236;
    private javax.swing.JLabel jLabel237;
    private javax.swing.JLabel jLabel239;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel240;
    private javax.swing.JLabel jLabel241;
    private javax.swing.JLabel jLabel242;
    private javax.swing.JLabel jLabel243;
    private javax.swing.JLabel jLabel244;
    private javax.swing.JLabel jLabel245;
    private javax.swing.JLabel jLabel246;
    private javax.swing.JLabel jLabel247;
    private javax.swing.JLabel jLabel248;
    private javax.swing.JLabel jLabel249;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel250;
    private javax.swing.JLabel jLabel252;
    private javax.swing.JLabel jLabel253;
    private javax.swing.JLabel jLabel254;
    private javax.swing.JLabel jLabel255;
    private javax.swing.JLabel jLabel256;
    private javax.swing.JLabel jLabel257;
    private javax.swing.JLabel jLabel258;
    private javax.swing.JLabel jLabel259;
    private javax.swing.JLabel jLabel260;
    private javax.swing.JLabel jLabel261;
    private javax.swing.JLabel jLabel262;
    private javax.swing.JLabel jLabel263;
    private javax.swing.JLabel jLabel265;
    private javax.swing.JLabel jLabel266;
    private javax.swing.JLabel jLabel267;
    private javax.swing.JLabel jLabel268;
    private javax.swing.JLabel jLabel269;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel270;
    private javax.swing.JLabel jLabel271;
    private javax.swing.JLabel jLabel272;
    private javax.swing.JLabel jLabel273;
    private javax.swing.JLabel jLabel274;
    private javax.swing.JLabel jLabel275;
    private javax.swing.JLabel jLabel276;
    private javax.swing.JLabel jLabel278;
    private javax.swing.JLabel jLabel279;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel280;
    private javax.swing.JLabel jLabel281;
    private javax.swing.JLabel jLabel282;
    private javax.swing.JLabel jLabel283;
    private javax.swing.JLabel jLabel284;
    private javax.swing.JLabel jLabel285;
    private javax.swing.JLabel jLabel286;
    private javax.swing.JLabel jLabel287;
    private javax.swing.JLabel jLabel288;
    private javax.swing.JLabel jLabel289;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel291;
    private javax.swing.JLabel jLabel292;
    private javax.swing.JLabel jLabel293;
    private javax.swing.JLabel jLabel294;
    private javax.swing.JLabel jLabel295;
    private javax.swing.JLabel jLabel296;
    private javax.swing.JLabel jLabel297;
    private javax.swing.JLabel jLabel298;
    private javax.swing.JLabel jLabel299;
    private javax.swing.JLabel jLabel300;
    private javax.swing.JLabel jLabel301;
    private javax.swing.JLabel jLabel302;
    private javax.swing.JLabel jLabel304;
    private javax.swing.JLabel jLabel305;
    private javax.swing.JLabel jLabel306;
    private javax.swing.JLabel jLabel307;
    private javax.swing.JLabel jLabel308;
    private javax.swing.JLabel jLabel309;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel310;
    private javax.swing.JLabel jLabel311;
    private javax.swing.JLabel jLabel312;
    private javax.swing.JLabel jLabel313;
    private javax.swing.JLabel jLabel314;
    private javax.swing.JLabel jLabel315;
    private javax.swing.JLabel jLabel317;
    private javax.swing.JLabel jLabel318;
    private javax.swing.JLabel jLabel319;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel320;
    private javax.swing.JLabel jLabel321;
    private javax.swing.JLabel jLabel322;
    private javax.swing.JLabel jLabel323;
    private javax.swing.JLabel jLabel324;
    private javax.swing.JLabel jLabel325;
    private javax.swing.JLabel jLabel326;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField100;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField173;
    private javax.swing.JTextField jTextField174;
    private javax.swing.JTextField jTextField175;
    private javax.swing.JTextField jTextField176;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField24;
    private javax.swing.JTextField jTextField25;
    private javax.swing.JTextField jTextField26;
    private javax.swing.JTextField jTextField27;
    private javax.swing.JTextField jTextField28;
    private javax.swing.JTextField jTextField29;
    private javax.swing.JTextField jTextField30;
    private javax.swing.JTextField jTextField31;
    private javax.swing.JTextField jTextField32;
    private javax.swing.JTextField jTextField33;
    private javax.swing.JTextField jTextField34;
    private javax.swing.JTextField jTextField35;
    private javax.swing.JTextField jTextField36;
    private javax.swing.JTextField jTextField37;
    private javax.swing.JTextField jTextField38;
    private javax.swing.JTextField jTextField39;
    private javax.swing.JTextField jTextField40;
    private javax.swing.JTextField jTextField41;
    private javax.swing.JTextField jTextField42;
    private javax.swing.JTextField jTextField43;
    private javax.swing.JTextField jTextField44;
    private javax.swing.JTextField jTextField45;
    private javax.swing.JTextField jTextField46;
    private javax.swing.JTextField jTextField47;
    private javax.swing.JTextField jTextField48;
    private javax.swing.JTextField jTextField49;
    private javax.swing.JTextField jTextField50;
    private javax.swing.JTextField jTextField51;
    private javax.swing.JTextField jTextField52;
    private javax.swing.JTextField jTextField53;
    private javax.swing.JTextField jTextField54;
    private javax.swing.JTextField jTextField55;
    private javax.swing.JTextField jTextField56;
    private javax.swing.JTextField jTextField57;
    private javax.swing.JTextField jTextField58;
    private javax.swing.JTextField jTextField59;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField60;
    private javax.swing.JTextField jTextField61;
    private javax.swing.JTextField jTextField62;
    private javax.swing.JTextField jTextField63;
    private javax.swing.JTextField jTextField64;
    private javax.swing.JTextField jTextField65;
    private javax.swing.JTextField jTextField66;
    private javax.swing.JTextField jTextField67;
    private javax.swing.JTextField jTextField68;
    private javax.swing.JTextField jTextField69;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField70;
    private javax.swing.JTextField jTextField71;
    private javax.swing.JTextField jTextField72;
    private javax.swing.JTextField jTextField73;
    private javax.swing.JTextField jTextField74;
    private javax.swing.JTextField jTextField75;
    private javax.swing.JTextField jTextField76;
    private javax.swing.JTextField jTextField77;
    private javax.swing.JTextField jTextField78;
    private javax.swing.JTextField jTextField79;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField80;
    private javax.swing.JTextField jTextField81;
    private javax.swing.JTextField jTextField82;
    private javax.swing.JTextField jTextField83;
    private javax.swing.JTextField jTextField84;
    private javax.swing.JTextField jTextField85;
    private javax.swing.JTextField jTextField86;
    private javax.swing.JTextField jTextField87;
    private javax.swing.JTextField jTextField88;
    private javax.swing.JTextField jTextField89;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JTextField jTextField90;
    private javax.swing.JTextField jTextField91;
    private javax.swing.JTextField jTextField92;
    private javax.swing.JTextField jTextField93;
    private javax.swing.JTextField jTextField94;
    private javax.swing.JTextField jTextField95;
    private javax.swing.JTextField jTextField96;
    private javax.swing.JTextField jTextField97;
    private javax.swing.JTextField jTextField98;
    private javax.swing.JTextField jTextField99;
    private javax.swing.JTextField txtUsuario1;
    // End of variables declaration//GEN-END:variables
}
