/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sumaherencia;

/**
 *
 * @author Alejandra
 */
public class sumar extends Operacion {
    
 public void opeSuma(){
     System.out. println(valor1);
     System.out. println(valor2);
        resultado=valor1+valor2;
    }
        
    
}
