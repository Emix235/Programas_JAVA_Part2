/**
 *
 * @author Emilio C
 */
public class managedUsuario {
    private usuarioBean usuario= new usuarioBean();
    
    public usuarioBean getUsuario(){
    return usuario;
    }
    public void setUsuario(usuarioBean usuario){
     this.usuario= usuario;   
    } 
    
    public String agregarUsuario(){
       setUsuario(usuario); 
       return "H1";
    }
}
