
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;


@Named(value = "bean")
@Dependent
public class bean {
 
 public String testButtonAction(){
  return "inicio.xhtml";
  }
 
  public bean(){
  } 
  
 
}
