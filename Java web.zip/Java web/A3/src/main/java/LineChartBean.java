/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.io.Serializable;
import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.LineChartModel;
import org.primefaces.model.chart.LineChartSeries;
import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;


@Named(value = "LineChartBean")
@RequestScoped
public class LineChartBean implements Serializable{
    private LineChartModel lineModel;
    private float x1, y1;
    private float x2, y2;
    private float x3, y3;
    private float x4, y4;
    private float x5, y5;

    

    public LineChartModel getLineModel() {
        return lineModel;
    }

    public void setLineModel(LineChartModel lineModel) {
        this.lineModel = lineModel;
    }
   
    public String action(){
    lineModel = new LineChartModel();
    LineChartSeries s = new  LineChartSeries();
    s.setLabel("Population");
    
    s.set(1, y1);
    s.set(2, y2);
    s.set(3,  y3);
    lineModel.addSeries(s);
    lineModel.setLegendPosition("e");
    Axis y = lineModel.getAxis(AxisType.Y);
    y.setMin(0);
    y.setMax(100);
    y.setLabel("Millions");
    
    Axis x = lineModel.getAxis(AxisType.X);
    x.setMin(0);
    x.setMax(10);
    x.setTickInterval("1");
    x.setLabel("Number of Years");
    return "inicio.xhtml";
    }
    
    public float getX1() {
        return x1;
    }

    public void setX1(float x1) {
        this.x1 = x1;
    }

    public float getY1() {
        return y1;
    }

    public void setY1(float y1) {
        this.y1 = y1;
    }

    public float getX2() {
        return x2;
    }

    public void setX2(float x2) {
        this.x2 = x2;
    }

    public float getY2() {
        return y2;
    }

    public void setY2(float y2) {
        this.y2 = y2;
    }

    public float getX3() {
        return x3;
    }

    public void setX3(float x3) {
        this.x3 = x3;
    }

    public float getY3() {
        return y3;
    }

    public void setY3(float y3) {
        this.y3 = y3;
    }

    public float getX4() {
        return x4;
    }

    public void setX4(float x4) {
        this.x4 = x4;
    }

    public float getY4() {
        return y4;
    }

    public void setY4(float y4) {
        this.y4 = y4;
    }

    public float getX5() {
        return x5;
    }

    public void setX5(float x5) {
        this.x5 = x5;
    }

    public float getY5() {
        return y5;
    }

    public void setY5(float y5) {
        this.y5 = y5;
    }

}
