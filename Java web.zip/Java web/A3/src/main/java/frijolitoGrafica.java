/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */

/**
 *
 * @author maur_
 */
public class frijolitoGrafica {

    private static int respuestaEstera;
    private static int respuestaEstera2;
    private static int respuestaEstera3;

    private String numero;
    private String numero2;
    private String numero3;

    public int getRespuestaEstera2() {
        return respuestaEstera2;
    }

    public void setRespuestaEstera2(int respuestaEstera2) {
        frijolitoGrafica.respuestaEstera2 = respuestaEstera2;
    }

    public int getRespuestaEstera3() {
        return respuestaEstera3;
    }

    public void setRespuestaEstera3(int respuestaEstera3) {
        frijolitoGrafica.respuestaEstera3 = respuestaEstera3;
    }

    public String getNumero2() {
        return numero2;
    }

    public void setNumero2(String numero2) {
        this.numero2 = numero2;
    }

    public String getNumero3() {
        return numero3;
    }

    public void setNumero3(String numero3) {
        this.numero3 = numero3;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public int getRespuestaEstera() {
        return respuestaEstera;
    }

    public void setRespuestaEstera(int respuestaEstera) {
        frijolitoGrafica.respuestaEstera = respuestaEstera;
    }

    public void almacenarInfo() {

        respuestaEstera = Integer.parseInt(this.numero);

    }

    public void almacenarInfo2() {
        respuestaEstera2 = Integer.parseInt(this.numero2);
    }

    public void almacenarInfo3() {
        respuestaEstera3 = Integer.parseInt(this.numero3);
    }

    public String dirigirA() {
        return "Grafica.xhtml";
    }

    public frijolitoGrafica() {
    }

}
