public class usuarioBean {
    private String Nombrec, genero, edad, salariob, htrabajadas, st;

    public String getSt() {
        return st;
    }

    public void setSt(String st) {
        int v1 =  Integer.parseInt(salariob);
        int v2 =  Integer.parseInt(htrabajadas);
        
        int s = v1*v2;
        st = Integer.toString(s);
        this.st = st;
    }

    public String getHtrabajadas() {
        return htrabajadas;
    }

    public void setHtrabajadas(String htrabajadas) {
        this.htrabajadas = htrabajadas;
    }

    public String getNombrec() {
        return Nombrec;
    }

    public void setNombrec(String Nombrec) {
        this.Nombrec = Nombrec;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getSalariob() {
        return salariob;
    }

    public void setSalariob(String salariob) {
        this.salariob = salariob;
    }
    
}
