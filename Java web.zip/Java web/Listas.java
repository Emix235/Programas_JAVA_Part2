/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

import javax.swing.*;
/**
 *
 * @author Roxxy
 */
public class Listas {

    /**
     * @param args the command line arguments
     */
    class Nodo {
      int info;
      Nodo sig;
   }
 
   private Nodo raiz;
    
   public Listas () {
      raiz=null;
   }
    
   public void insertar(int x) {
      Nodo nuevo;
      nuevo = new Nodo();
      nuevo.info = x;
      if (raiz==null)
      {
         nuevo.sig = null;
         raiz = nuevo;
      }
      else
      {
         nuevo.sig = raiz;
         raiz = nuevo;
      }
   }
    
   public int extraer ()
   {
      if (raiz!=null)
      {
         int informacion = raiz.info;
         raiz = raiz.sig;
         return informacion;
      }
      else
      {
         return Integer.MAX_VALUE;
      }
   }
    
   public void eliminar (int x)
   {
      if (raiz!=null){
         if(x==raiz.info)
            raiz=null;
         else if(x==raiz.info)
            raiz=raiz.sig;   
         else{
            Nodo aux=raiz;
            Nodo recorre=raiz.sig;
            while(recorre!=null && recorre.info!=x){
               aux=aux.sig;
               recorre=recorre.sig;
            }
            if(recorre!=null)
               aux.sig=recorre.sig;
         } 
      }             
   }

    
   public void imprimir(String cadena) {
      Nodo recorre=raiz;
        
      while (recorre!=null) {
         cadena+="\n"+recorre.info;
         recorre=recorre.sig;
      }
      JOptionPane.showMessageDialog(null,cadena);
   }

    public static void main(String[] args) {
        // TODO code application logic here
        Listas lista1=new Listas();
      String cadena="";
      int Valor=12;
      while (Valor!=0) {
         Valor = Integer.parseInt(JOptionPane.showInputDialog(null,
                "INGRESAR VALOR\n",JOptionPane.QUESTION_MESSAGE));
         if (Valor!=0)    
            lista1.insertar(Valor);
      }
               
      cadena+="lista de todos los elementos";
      lista1.imprimir(cadena);
           cadena="Extraemos de la lista el primero";
           lista1.extraer();
   //        lista1.imprimir(cadena);    
   //        lista1.extraer(); 
   //        lista1.imprimir(cadena);     
      Valor = Integer.parseInt(JOptionPane.showInputDialog(null,
                "INGRESAR VALOR A ELIMINAR \n",JOptionPane.QUESTION_MESSAGE));
      lista1.eliminar(Valor); 
      cadena+="\n\nlista de todos los elementos";
      lista1.imprimir(cadena);
     
   }
    
}
