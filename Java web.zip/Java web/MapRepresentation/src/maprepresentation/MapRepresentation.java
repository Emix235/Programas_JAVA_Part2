package maprepresentation;

/**
 *
 * @author Emilio C
 */
public class MapRepresentation {
    
   public static Graph getCities() {
       
       // Nodos de las ciudades
       // Creando los nodos
        Node df = new Node("DF");
        Node toluca = new Node("Toluca");
        Node cuernavaca = new Node("Cuernavaca");
        Node puebla = new Node("Puebla");
        Node tlaxcala = new Node("Tlaxcala");
       // Rutas del df
        df.addEdge(new Edge(df, toluca, 100));
        df.addEdge(new Edge(df, cuernavaca, 90));
        df.addEdge(new Edge(df, puebla, 123));
        df.addEdge(new Edge(df, tlaxcala, 230));
        
       // Rutas de Toluca
        toluca.addEdge(new Edge(toluca, cuernavaca, 150));
        toluca.addEdge(new Edge(toluca, puebla, 350));
        toluca.addEdge(new Edge(toluca, tlaxcala, 340));
        toluca.addEdge(new Edge(toluca, df, 100));
        
       // Rutas de cuernavaca
        cuernavaca.addEdge(new Edge(cuernavaca, puebla, 100));
        cuernavaca.addEdge(new Edge(cuernavaca, tlaxcala, 350));
        cuernavaca.addEdge(new Edge(cuernavaca, toluca, 350));
        cuernavaca.addEdge(new Edge(cuernavaca, df, 250));
       
       // Rutas de puebla
        puebla.addEdge(new Edge(puebla, tlaxcala, 20));
        puebla.addEdge(new Edge(puebla, cuernavaca, 320));
        puebla.addEdge(new Edge(puebla, toluca, 120));
        puebla.addEdge(new Edge(puebla, df, 200));
       
       // Rutas de tlaxcala
        tlaxcala.addEdge(new Edge(tlaxcala, puebla, 20));
        tlaxcala.addEdge(new Edge(tlaxcala, toluca, 420));
        tlaxcala.addEdge(new Edge(tlaxcala, cuernavaca, 40));
        tlaxcala.addEdge(new Edge(tlaxcala, df, 500));
        
       // Clase graph
        Graph graph = new Graph();
        graph.addNode(df);
        graph.addNode(toluca);
        graph.addNode(cuernavaca);
        graph.addNode(puebla);
        graph.addNode(tlaxcala);
        return graph;
    }
 
    public static void main(String[] args) {
        Graph graph = getCities();
        System.out.println(graph);
    }
}
