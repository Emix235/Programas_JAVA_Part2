
import java.util.Arrays;

public class usuarioBean {
    private String nombre, g, domicilio, edad;
   
    
    private String frutaF;
    private String concF;

    public String getConcF() {
           concF=Arrays.toString(ListF);
//    (Arrays.toString(ListF));
           return concF;

    }

    public void setConcF(String concF) {
        this.concF = concF;
    }
    private String[] ListF;

    public String[] getListF() {
        return ListF;
    }

    public void setListF(String[] ListF) {
        this.ListF = ListF;
    }
    
    
    
    public String getFrutaF() {
        return frutaF;
    }

    public void setFrutaF(String frutaF) {
        this.frutaF = frutaF;
    }

    public String getG() {
        return g;
    }

    public void setG(String g) {
        this.g = g;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

}
