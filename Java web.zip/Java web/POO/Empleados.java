package calcular_salarios;

import java.io.*;
import java.util.Scanner;

public class Empleados {

    String nombre, curp, domicilio, puesto, estadoCivil, trabajoAnterior, experiencia;
    int edad;

    public Empleados(String nombre, int edad, String curp, String domicilio, String puesto, String estadoCivil, String trabajoAnterior, String experiencia) {
        this.nombre = nombre;
        this.edad = edad;
        this.curp = curp;
        this.domicilio = domicilio;
        this.puesto = puesto;
        this.experiencia = experiencia;
        this.estadoCivil = estadoCivil;
        this.trabajoAnterior = trabajoAnterior;
    }


    int calcularSalario(int n) {
        return 0;
    }

    void capturarDatos() {
    Scanner leer = new Scanner(System.in);
    System.out.println("Coloque su nombre");
    nombre = leer.next();
    System.out.println("Coloque su curp");
    curp = leer.next();
    System.out.println("Coloque su domicilio");
    domicilio = leer.next(); 
    System.out.println("Coloque su puesto");
    puesto = leer.next();
    System.out.println("Coloque su Estado civil");
    estadoCivil = leer.next();
    }

    void imprimirInfo() {
        System.out.println("Nombre " + nombre);
        System.out.println("Edad " + edad);
        System.out.println("Curp " + curp);
        System.out.println("Domicilio " + domicilio);
        System.out.println("Puesto " + puesto);
        System.out.println("Experiencia " + experiencia);
        System.out.println("Estado Civil " + estadoCivil);
        System.out.println("Trabajo anterior " + trabajoAnterior);
    }

    public static void main(String y[]) {
       Empleados empleado1 = new Empleados();
       empleado1.capturarDatos();
    }

}
